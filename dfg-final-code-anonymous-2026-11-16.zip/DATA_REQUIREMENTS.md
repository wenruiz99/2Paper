# External Data Requirements

No datasets or record-level split lists are included in this ZIP.

## BPI2017

Online original dataset:
https://doi.org/10.4121/uuid:5f3067df-f10b-45da-b98b-86ae4c7a310b

The final experiment expects
`canonical_after_first_offer_final_application_outcome.csv`, with columns:
`CaseID`, `RequestedAmount`, `LoanGoal`, `ApplicationType`, `prediction_time`,
`FirstWithdrawalAmount`, `NumberOfTerms`, `CreditScore`, `MonthlyCost`,
`final_application_outcome`, `outcome_time`, `Loan_Accepted`.

This is an application-level cohort derived from the first offer and later final
application outcomes. The final notebooks do not parse the original XES archive
to construct this CSV. To reproduce the exact reported cohort, obtain the matching
prepared CSV separately; its expected SHA-256 is in `expected_cohort.json`.
The input utility preserves the historical fractional-second timestamp exclusions
and regenerates exact membership from that prepared CSV.

## Default of Credit Card Clients

Provider: https://archive.ics.uci.edu/dataset/350/default+of+credit+card+clients
DOI: https://doi.org/10.24432/C55S3H

Expected file: `UCI_Credit_Card.csv`, containing ID, the 23 published predictors
and the next-month default target. The study loader recodes published category
values and defines Accepted as non-default, Rejected as default. These are risk
proxies, not lender approval decisions. The provider publishes the data under
CC BY 4.0; retain its attribution. Different spreadsheet/CSV conversions may have
different byte hashes; the supplied hash identifies the study's exact CSV.

## LendingClub

Provider: https://www.kaggle.com/datasets/wordsforthewise/lending-club

Expected file: `canonical_lendingclub_application_sample.csv`, with columns:
`CaseID`, `ApplicationDate`, `Outcome_Accepted`, `LoanAmount`, `EmploymentLength`,
`DebtToIncome`, `RiskScore`, `IssueYear`, `IssueMonth`, `Purpose`, `State`.

The original accepted/rejected application archives are not the prepared CSV.
The study uses a deterministic, capped calendar-year/outcome sample with
incompletely harmonized source fields. Obtain the matching prepared sample
separately to reproduce the exact reported experiment. The package includes
its expected hash, not the record-level sample or the historical raw sampler.
Application dates do not establish label-availability times.

## Scope

The archive is final **analysis code**, not a self-contained data release.
Online source links establish where the underlying datasets originate; they do
not imply that the exact study-specific derived CSVs are publicly hosted at
those links. The input utility verifies byte-level input identity and regenerates
split metadata. It does not substitute a new cohort if a source differs.
