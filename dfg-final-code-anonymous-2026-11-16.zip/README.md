# Anonymous Final Code: Three-Dataset DFG Study

This is a **code-only** review package. It contains the three current notebooks
and only the Python modules needed by their final calculations. Saved notebook
outputs are cleared. Datasets, feature logs, graphs, result tables, fit caches,
paper drafts, migration scripts, historical builders and backups are excluded.
Configuration and expected input hashes are metadata, not record-level data.

## Contents

| Dataset folder | Final notebook |
| --- | --- |
| `datasets/bpi2017` | `bpi2017-with-credit-score.ipynb` |
| `datasets/credit_card` | `CreditCard-tasks1-7.ipynb` |
| `datasets/lendingclub` | `LendingClub-tasks1-7.ipynb` |

The historical notebook filenames are retained; current sections extend through
Task 8.2. The task coverage differs: BPI2017 additionally has its dataset-specific
Tasks 7.2, 7.3 and 7.5. Numbered experiment modules are final scientific analyses,
not migration/deployment scripts.

Task 6.5 uses only mean diagnostic KS entropy in bits per transition for DFG
complexity. Accuracy and trainable parameter count are shown separately.
Other task-specific scores retain their own definitions. Standard AIC/BIC use
natural-log likelihood; every KS calculation is reported in bits.

## Install

Use Python 3.13.9 as declared by the notebooks, or Python 3.12.14 to match the
recent reference execution more closely. The package versions are recorded
in `requirements-reference.txt`; this is not a complete OS/BLAS image.

```text
python -m venv .venv
.venv\Scripts\python -m pip install -r requirements-reference.txt
.venv\Scripts\python -m ipykernel install --user --name dfg-reproduction
```

On Linux/macOS use `.venv/bin/python`. A complete clean-environment full training
run is not certified by packaging; floating-point libraries can affect close
minima even with fixed seeds. The code-only integrity check needs no packages:

```text
python verify_code.py
```

## Supply Data Separately

See `DATA_REQUIREMENTS.md` for online provider links and the exact CSVs expected
by the final pipelines. **The BPI2017 and LendingClub input CSVs are derived study
cohorts, not files that can simply be renamed from the raw downloads.** No claim
is made that downloading a raw archive alone recreates those exact cohorts.

After obtaining the required prepared CSV, the included final input utility
regenerates the pinned split metadata and checks the original SHA-256 values:

```text
python prepare_inputs.py --dataset bpi2017 --input PATH_TO_BPI_STUDY_CSV
python prepare_inputs.py --dataset credit_card --input PATH_TO_UCI_CSV
python prepare_inputs.py --dataset lendingclub --input PATH_TO_LENDING_STUDY_CSV
```

The utility refuses different input data or split membership rather than silently
creating a different experiment. Expected hashes and configuration are included;
record-level inputs and membership lists are not. The raw-to-prepared cohort
construction workflow is not reconstructed by this code-only package.

## Run the Final Notebooks

```text
python run_experiments.py --dataset bpi2017
python run_experiments.py --dataset credit_card
python run_experiments.py --dataset lendingclub
```

Alternatively open a notebook with its dataset folder as the working directory.
In the packaged copies, saved-results audits/overviews are moved to the end so
they do not run before outputs exist. Task 6.5 first generates its NN fit exports
if absent, then applies the final KS-only summaries. These are execution-order
adaptations, not changes to the model settings or selection formulas. Original
workspace notebooks have not been edited by packaging.

Full execution is expensive: the notebooks train multiple ML models, calculate
SHAP, and run many resampling experiments. Start with one dataset; hours may be
needed. Runtime and peak memory have not been benchmarked for a clean install.
Executed notebooks and output folders are generated locally, not included in
this ZIP. Earlier test/validation inspection remains a research limitation;
the historical test partition must not be described as wholly untouched.

This package is prepared for anonymous review. Author/machine metadata and
saved outputs are omitted. Dataset-provider attribution is retained. No new
blanket public software or dataset license is asserted by this packaging step.
