"""Task 7.2: conditional Markov explanation codes on saved BPI 2017 logs.

No model fitting, SHAP recomputation, or test-set selection occurs here. The
combined scores are exploratory, not marginal likelihoods for the ML model.
"""
from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path
import platform

import matplotlib.pyplot as plt
import networkx as nx
import numpy as np
import pandas as pd
from scipy.special import gammaln, xlogy
from IPython.display import Image, Markdown, display


OUTPUT_DIRECTORY = "task7_2_explanation_coding_outputs"
COLORS = {"BIC": "#28688f", "BIC_plus_2_KS_path_cost": "#bc5833",
          "BIC_plus_2_mixture_code": "#277b59"}
SCORE_LABELS = {"BIC": "BIC", "BIC_plus_2_KS_path_cost": "BIC + KS path cost",
                "BIC_plus_2_mixture_code": "BIC + complete conditional code"}


def allowed_transitions(k: int) -> np.ndarray:
    """Fixed support, including unseen legal transitions; never infer from data."""
    if not isinstance(k, (int, np.integer)) or k < 1:
        raise ValueError("k must be a positive integer.")
    allowed = np.zeros((k + 2, k + 2), dtype=bool)
    allowed[0, 1:k + 1] = True
    allowed[1:k + 1, 1:k + 2] = True
    np.fill_diagonal(allowed, False)
    allowed[-1, 0] = True
    return allowed


def case_transition_counts(rankings: np.ndarray) -> np.ndarray:
    """One closed START -> permutation -> END -> START count matrix per case."""
    rankings = np.asarray(rankings)
    if rankings.ndim != 2 or rankings.shape[0] < 1 or rankings.shape[1] < 1:
        raise ValueError("Expected a nonempty cases-by-features ranking matrix.")
    m, k = rankings.shape
    if not np.array_equal(np.sort(rankings, axis=1), np.tile(np.arange(k), (m, 1))):
        raise ValueError("Every ranking must be a permutation of all selected features.")
    paths = np.column_stack([np.zeros(m, dtype=int), rankings.astype(int) + 1,
                             np.full(m, k + 1), np.zeros(m, dtype=int)])
    counts = np.zeros((m, k + 2, k + 2), dtype=np.int64)
    for step in range(k + 2):
        counts[np.arange(m), paths[:, step], paths[:, step + 1]] += 1
    return counts


def code_components(counts: np.ndarray, universe_size: int, alpha: float = 0.5):
    """Exact mixture codelength in bits, conditional on the declared code header.

    Each row has an independent symmetric Dirichlet(alpha) prior on its fixed
    allowed successors. This codes ordered paths, so no multinomial coefficient
    is included. The feature universe, case identities/order, and cohort size
    are shared side information. k and its subset are encoded explicitly.
    """
    counts = np.asarray(counts, dtype=float)
    if counts.ndim != 2 or counts.shape[0] != counts.shape[1] or counts.shape[0] < 3:
        raise ValueError("Expected a square closed-DFG count matrix.")
    if not np.isfinite(counts).all() or np.any(counts < 0) or np.any(counts != np.floor(counts)):
        raise ValueError("Transition counts must be finite nonnegative integers.")
    k = counts.shape[0] - 2
    if not isinstance(universe_size, (int, np.integer)) or universe_size < k:
        raise ValueError("The known feature universe must contain the selected subset.")
    if not np.isfinite(alpha) or alpha <= 0:
        raise ValueError("Dirichlet alpha must be positive and finite.")
    allowed = allowed_transitions(k)
    if counts[~allowed].any():
        raise ValueError("Observed edge is outside the declared transition support.")
    outgoing = counts.sum(axis=1)
    if not np.array_equal(outgoing, counts.sum(axis=0)):
        raise ValueError("The empirical DFG must be restart-closed and flow-balanced.")
    m = outgoing[0]
    if m < 1 or not np.all(outgoing == m):
        raise ValueError("Every case must visit START, each feature, and END exactly once.")
    probabilities = counts / outgoing[:, None]
    log_probabilities = np.zeros_like(probabilities)
    np.log2(probabilities, out=log_probabilities, where=probabilities > 0)
    row_path_bits = -np.sum(counts * log_probabilities, axis=1)
    row_mixture_bits = []
    for row, mask in zip(counts, allowed):
        values = row[mask]
        d = len(values)
        row_mixture_bits.append(float(
            gammaln(values.sum() + d * alpha) - gammaln(d * alpha)
            - np.sum(gammaln(values + alpha) - gammaln(alpha))
        ))
    # gammaln returns natural logarithms; probability codelengths are in bits.
    row_mixture_bits = np.asarray(row_mixture_bits) / math.log(2)
    row_redundancy = row_mixture_bits - row_path_bits
    if row_redundancy.min() < -1e-8:
        raise AssertionError("A probability mixture cannot beat the fitted path likelihood.")
    path_bits = float(row_path_bits.sum())
    mixture_bits = float(row_mixture_bits.sum())
    header_bits = math.log2(universe_size) + math.log2(math.comb(universe_size, k))
    total_bits = header_bits + mixture_bits
    weight = float(outgoing.sum())
    stationary = outgoing / weight
    residual = float(np.max(np.abs(stationary @ probabilities - stationary)))
    metrics = {
        "feature_group_count": k, "explanation_cases": int(m),
        "transition_count": int(weight), "dirichlet_alpha": float(alpha),
        "ks_entropy_bits_per_transition": path_bits / weight,
        "ks_path_cost_bits": path_bits, "ks_path_bits_per_case": path_bits / m,
        "mixture_transition_cost_bits": mixture_bits,
        "transition_learning_cost_bits": mixture_bits - path_bits,
        "feature_header_cost_bits": header_bits,
        "complete_code_cost_bits": total_bits,
        "complete_code_bits_per_case": total_bits / m,
        "stationary_residual": residual,
        "entropy_identity_residual": abs(path_bits - weight * np.dot(stationary, row_path_bits / outgoing)),
    }
    nodes = pd.DataFrame({
        "node_index": np.arange(k + 2), "outgoing_frequency": outgoing.astype(int),
        "allowed_successors": allowed.sum(axis=1), "observed_successors": (counts > 0).sum(axis=1),
        "stationary_probability": stationary,
        "local_entropy_bits": row_path_bits / outgoing,
        "path_cost_bits": row_path_bits,
        "mixture_cost_bits": row_mixture_bits,
        "transition_learning_cost_bits": row_redundancy,
    })
    return metrics, nodes


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_saved_candidates(root: Path, expected_feature_count=7, expected_first_feature="CreditScore"):
    root = Path(root)
    directory = root / "task3_outputs"
    model_path = directory / "nested_feature_group_model_dfg_measures.csv"
    ranking_path = directory / "feature_group_ranking.csv"
    models = pd.read_csv(model_path).sort_values("feature_group_count").reset_index(drop=True)
    ranking = pd.read_csv(ranking_path).sort_values("feature_rank")
    features = ranking["feature_group"].tolist()
    K = len(features)
    if not K or len(set(features)) != K or ranking.feature_rank.tolist() != list(range(1, K + 1)):
        raise ValueError("Feature ranking must contain one unique group at each rank.")
    if expected_feature_count is not None and K != expected_feature_count:
        raise ValueError(f"Expected {expected_feature_count} feature groups, found {K}.")
    if expected_first_feature is not None and features[0] != expected_first_feature:
        raise ValueError(f"Expected first-ranked feature {expected_first_feature!r}.")
    if models.feature_group_count.tolist() != list(range(1, K + 1)):
        raise ValueError("Need exactly one saved nested model for every feature count.")
    if models["test_cases_used"].astype(str).str.lower().ne("false").any():
        raise ValueError("Saved graph selection must not use test cases.")
    pure_path = root / "task7_pure_ks_bic_outputs/pure_ks_entropy_penalized_bic_results.csv"
    pure = pd.read_csv(pure_path).sort_values("feature_group_count")
    if pure.feature_group_count.tolist() != models.feature_group_count.tolist():
        raise ValueError("Task 3 and Task 7 candidate sets disagree.")
    if not np.allclose(models.BIC, pure.BIC, rtol=0, atol=1e-7):
        raise ValueError("Task 3 and Task 7 BIC values differ; refresh stale exports first.")
    hashes = {str(p.relative_to(root)): _sha256(p) for p in [model_path, ranking_path, pure_path]}
    candidates = []
    common_cases = None
    for _, model in models.iterrows():
        k = int(model.feature_group_count)
        selected = features[:k]
        if model.included_feature_groups.split(" | ") != selected:
            raise ValueError(f"Candidate k={k} does not use the declared training-derived prefix.")
        log_path = directory / f"feature_count_{k:02d}_feature_log.csv"
        log = pd.read_csv(log_path, dtype={"CaseID": str})
        required = {"CaseID", "concept:name", "feature_group", "explanation_rank"}
        if not required.issubset(log.columns) or log.CaseID.isna().any():
            raise ValueError(f"Missing case/ranking fields in {log_path.name}.")
        events = log[log.feature_group.fillna("").ne("")].copy()
        cases = events.CaseID.drop_duplicates().tolist()
        if common_cases is None:
            common_cases = cases
        elif set(cases) != set(common_cases):
            raise ValueError("All candidate graphs must describe the same explanation cases.")
        by_case = dict(tuple(events.groupby("CaseID", sort=False)))
        lookup = {feature: index for index, feature in enumerate(selected)}
        rankings = []
        for case in common_cases:
            case_events = by_case[case].sort_values("explanation_rank", kind="stable")
            if case_events.explanation_rank.tolist() != list(range(1, k + 1)):
                raise ValueError(f"Invalid or incomplete ranking for case {case}, k={k}.")
            if set(case_events.feature_group) != set(selected):
                raise ValueError(f"Feature support differs for case {case}, k={k}.")
            rankings.append([lookup[x] for x in case_events.feature_group])
        per_case = case_transition_counts(np.asarray(rankings))
        counts = per_case.sum(axis=0)
        metrics, _ = code_components(counts, K)
        if not np.isclose(metrics["ks_entropy_bits_per_transition"],
                          model.ks_entropy_bits_per_transition, rtol=0, atol=1e-9):
            raise ValueError(f"Reconstructed entropy disagrees with Task 3 at k={k}.")
        if not np.isclose(metrics["ks_entropy_bits_per_transition"],
                          pure.iloc[k - 1].ks_entropy_bits_per_transition, rtol=0, atol=1e-9):
            raise ValueError(f"Reconstructed entropy disagrees with Task 7 at k={k}.")
        activity = events.groupby("feature_group")["concept:name"].agg(lambda x: tuple(x.unique()))
        if any(len(values) != 1 for values in activity):
            raise ValueError("A feature group must have a unique activity label.")
        labels = ["START", *[activity[f][0] for f in selected], "END"]
        graph_path = directory / f"feature_count_{k:02d}_feature_only_restart_closed_dfg.graphml"
        graph = nx.read_graphml(graph_path)
        expected = {(labels[u], labels[v]): int(counts[u, v]) for u, v in zip(*np.nonzero(counts))}
        actual = {(u, v): float(data["weight"]) for u, v, data in graph.edges(data=True)}
        if expected != actual:
            raise ValueError(f"Reconstructed transitions disagree with saved GraphML at k={k}.")
        hashes.update({str(p.relative_to(root)): _sha256(p) for p in [log_path, graph_path]})
        candidates.append({"k": k, "model": model.to_dict(), "counts": counts,
                           "case_counts": per_case, "labels": labels})
    return candidates, features, common_cases, hashes


def _scores(candidates, indices, K, alpha=0.5):
    rows = []
    for candidate in candidates:
        counts = candidate["case_counts"][indices].sum(axis=0)
        metrics, _ = code_components(counts, K, alpha)
        bic = float(candidate["model"]["BIC"])
        rows.append({**metrics, "BIC": bic,
                     "BIC_plus_2_KS_path_cost": bic + 2 * math.log(2) * metrics["ks_path_cost_bits"],
                     "BIC_plus_2_mixture_code": bic + 2 * math.log(2) * metrics["complete_code_cost_bits"]})
    return pd.DataFrame(rows)


def _selected(frame, column):
    # Stable smaller-k tie-break; candidates are always in ascending feature count.
    return int(frame.loc[frame[column].idxmin(), "feature_group_count"])


def _save_figure(fig, path, show):
    fig.savefig(path, dpi=170, bbox_inches="tight", facecolor="white")
    if show:
        display(Image(filename=str(path)))
    plt.close(fig)


def _figures(results, budget_frequencies, boot_frequencies, output_dir, show):
    k = results.feature_group_count.to_numpy()
    fig, axes = plt.subplots(2, 3, figsize=(15, 8), constrained_layout=True)
    axes[0, 0].plot(k, results.ks_entropy_bits_per_transition, "o-", color="#73538b")
    axes[0, 0].set(title="KS entropy rate", ylabel="Bits per transition")
    axes[0, 1].plot(k, results.ks_path_bits_per_case, "o-", color="#bc5833", label="KS path information")
    axes[0, 1].plot(k, results.complete_code_bits_per_case, "s--", color="#277b59", label="Complete conditional code")
    axes[0, 1].set(title="Explanation information per case", ylabel="Bits per case")
    axes[0, 1].legend(fontsize=8)
    denominator = results.explanation_cases
    learning = results.transition_learning_cost_bits / denominator
    header = results.feature_header_cost_bits / denominator
    axes[0, 2].bar(k, learning, color="#277b59", label="Transition learning")
    axes[0, 2].bar(k, header, bottom=learning, color="#d5ac44", label="Feature header")
    axes[0, 2].set(title="Coding cost beyond empirical KS", ylabel="Additional bits per case")
    axes[0, 2].legend(fontsize=8)
    for axis, column in zip(axes[1], COLORS):
        delta = results[column] - results[column].min()
        choice = _selected(results, column)
        axis.plot(k, delta, "o-", color=COLORS[column])
        axis.axvline(choice, color=COLORS[column], linestyle=":", alpha=.7)
        axis.set(title=f"{SCORE_LABELS[column]}\nSelected k = {choice}", ylabel="Difference from own minimum")
    for axis in axes.flat:
        axis.set_xlabel("Number of feature groups (k)")
        axis.set_xticks(k)
        axis.grid(alpha=.2)
    fig.suptitle("Task 7.2: KS-based explanation coding costs (BPI 2017)", fontsize=14)
    _save_figure(fig, output_dir / "coding_costs_and_selection.png", show)

    fig, axes = plt.subplots(1, 2, figsize=(13, 4.8), constrained_layout=True)
    frequency = budget_frequencies.pivot(index="explanation_cases", columns="selected_k", values="frequency")
    frequency = frequency.reindex(columns=k, fill_value=0).fillna(0)
    matrix = axes[0].imshow(frequency.to_numpy(), vmin=0, vmax=1, cmap="YlGnBu", aspect="auto")
    for row, values in enumerate(frequency.to_numpy()):
        for col, value in enumerate(values):
            if value > 0:
                axes[0].text(col, row, f"{value:.1%}", ha="center", va="center",
                             color="white" if value > .55 else "black", fontsize=9)
    axes[0].set(xticks=np.arange(len(k)), xticklabels=k,
                yticks=np.arange(len(frequency)), yticklabels=frequency.index,
                xlabel="Selected feature count (k)", ylabel="Explanation cases encoded (m)",
                title="Complete-code choice by explanation budget\nPaired subsampling; fixed training BIC")
    fig.colorbar(matrix, ax=axes[0], label="Selection frequency", shrink=.8)
    for offset, column in enumerate(COLORS):
        values = boot_frequencies[boot_frequencies.criterion.eq(column)].set_index("selected_k")
        axes[1].bar(k + (offset - 1) * .24, values.frequency.reindex(k, fill_value=0),
                    width=.24, label=SCORE_LABELS[column], color=COLORS[column])
    axes[1].set(xticks=k, xlabel="Selected feature count (k)", ylabel="Selection frequency",
                ylim=(0, 1.08), title="Paired case-bootstrap sensitivity\nFixed models, SHAP rankings, and BIC")
    axes[1].legend(fontsize=8)
    axes[1].grid(axis="y", alpha=.2)
    _save_figure(fig, output_dir / "coding_budget_and_bootstrap_sensitivity.png", show)

    bic_k = _selected(results, "BIC")
    code_k = _selected(results, "BIC_plus_2_mixture_code")
    fig, axes = plt.subplots(1, 3, figsize=(14, 4), constrained_layout=True)
    for axis, column, title in zip(axes, ["validation_accuracy", "validation_roc_auc", "validation_log_loss"],
                                   ["Validation accuracy", "Validation ROC AUC", "Validation log loss"]):
        axis.plot(k, results[column], "o-", color="#444b52")
        axis.axvline(bic_k, color=COLORS["BIC"], linestyle="--", label=f"BIC: k={bic_k}")
        axis.axvline(code_k, color=COLORS["BIC_plus_2_mixture_code"], linestyle=":", label=f"Coding: k={code_k}")
        axis.set(title=title, xlabel="Number of feature groups (k)", xticks=k)
        axis.grid(alpha=.2)
        axis.legend(fontsize=8)
    fig.suptitle("Predictive consequences of the two choices (no refitting)", fontsize=13)
    _save_figure(fig, output_dir / "validation_performance_at_coding_choices.png", show)


def run_task7_2(root=".", *, bootstraps=500, subsamples=200, seed=72027, show=True):
    """Reproduce Task 7.2 using only current Task 3/7/7.1 exports."""
    if not isinstance(bootstraps, int) or not isinstance(subsamples, int) or min(bootstraps, subsamples) < 1:
        raise ValueError("Positive integer bootstrap and subsampling counts are required.")
    root = Path(root).resolve()
    candidates, features, case_ids, hashes = load_saved_candidates(root)
    K, m = len(features), len(case_ids)
    all_indices = np.arange(m)
    results = _scores(candidates, all_indices, K)
    metrics = ["included_feature_groups", "design_rank_p", "training_log_likelihood",
               "validation_accuracy", "validation_roc_auc", "validation_log_loss"]
    for column in metrics:
        results[column] = [c["model"][column] for c in candidates]
    for column in COLORS:
        results[f"delta_{column}"] = results[column] - results[column].min()
        results[f"selected_by_{column}"] = results.feature_group_count.eq(_selected(results, column))
    node_frames = []
    for candidate in candidates:
        _, nodes = code_components(candidate["counts"], K)
        nodes.insert(0, "feature_group_count", candidate["k"])
        nodes["node"] = candidate["labels"]
        node_frames.append(nodes)

    comparisons = []
    for column, label in SCORE_LABELS.items():
        selected = results.loc[results[column].idxmin()]
        comparisons.append({"criterion": label, "selected_k": int(selected.feature_group_count),
                            "selected_score": selected[column],
                            **{c: selected[c] for c in metrics}})
    for relative, column, label in [
        ("task7_pure_ks_bic_outputs/pure_ks_entropy_penalized_bic_results.csv",
         "pure_KS_BIC_default_lambda", "Task 7: pure KS, lambda=1"),
        ("task7_1_entropy_effective_dfg_bic_outputs/entropy_effective_dfg_bic_results.csv",
         "frequency_DFG_BIC_default_lambda", "Task 7.1: entropy-effective, lambda=1"),
    ]:
        path = root / relative
        old = pd.read_csv(path).sort_values("feature_group_count")
        if old.feature_group_count.tolist() != results.feature_group_count.tolist() or not np.allclose(old.BIC, results.BIC, rtol=0, atol=1e-7):
            raise ValueError(f"Stale comparison export: {relative}")
        chosen = old.loc[old[column].idxmin()]
        selected = results[results.feature_group_count.eq(chosen.feature_group_count)].iloc[0]
        comparisons.append({"criterion": label, "selected_k": int(chosen.feature_group_count),
                            "selected_score": chosen[column], **{c: selected[c] for c in metrics}})
        hashes[relative] = _sha256(path)
    comparison = pd.DataFrame(comparisons)

    rng = np.random.default_rng(seed)
    bootstrap_rows, budget_rows, alpha_rows = [], [], []
    for replicate in range(bootstraps):
        sampled = rng.integers(0, m, size=m)
        frame = _scores(candidates, sampled, K)
        for column in COLORS:
            bootstrap_rows.append({"replicate": replicate + 1, "criterion": column,
                                   "selected_k": _selected(frame, column)})
    bootstrap_replicates = pd.DataFrame(bootstrap_rows)
    bootstrap_frequencies = bootstrap_replicates.groupby(["criterion", "selected_k"]).size().rename("count").reset_index()
    bootstrap_frequencies["frequency"] = bootstrap_frequencies["count"] / bootstraps
    budgets = sorted(set([min(x, m) for x in [10, 25, 50, 100, 250, 500, m]]))
    for budget in budgets:
        repetitions = 1 if budget == m else subsamples
        for replicate in range(repetitions):
            indices = all_indices if budget == m else rng.choice(m, size=budget, replace=False)
            frame = _scores(candidates, indices, K)
            for column in COLORS:
                budget_rows.append({"explanation_cases": budget, "replicate": replicate + 1,
                                    "criterion": column, "selected_k": _selected(frame, column)})
    budget_replicates = pd.DataFrame(budget_rows)
    budget_frequencies = budget_replicates.groupby(["explanation_cases", "criterion", "selected_k"]).size().rename("count").reset_index()
    budget_frequencies["frequency"] = budget_frequencies["count"] / budget_frequencies.groupby(["explanation_cases", "criterion"])["count"].transform("sum")
    for alpha in [.1, .5, 1., 2.]:
        frame = _scores(candidates, all_indices, K, alpha)
        for row in frame.to_dict("records"):
            row["selected_by_complete_code"] = row["feature_group_count"] == _selected(frame, "BIC_plus_2_mixture_code")
            alpha_rows.append(row)
    alpha_sensitivity = pd.DataFrame(alpha_rows)
    code_budget = budget_frequencies[budget_frequencies.criterion.eq("BIC_plus_2_mixture_code")]
    budget_summary = code_budget.sort_values(["explanation_cases", "frequency", "selected_k"], ascending=[True, False, True]).drop_duplicates("explanation_cases")
    budget_summary = budget_summary.rename(columns={"selected_k": "modal_selected_k", "frequency": "modal_selection_frequency"})

    output_dir = root / OUTPUT_DIRECTORY
    output_dir.mkdir(exist_ok=True)
    exports = {
        "coding_candidate_results.csv": results,
        "node_coding_components.csv": pd.concat(node_frames, ignore_index=True),
        "selection_comparison.csv": comparison,
        "paired_case_bootstrap_replicates.csv": bootstrap_replicates,
        "paired_case_bootstrap_frequencies.csv": bootstrap_frequencies,
        "explanation_budget_replicates.csv": budget_replicates,
        "explanation_budget_selection_frequencies.csv": budget_frequencies,
        "explanation_budget_summary.csv": budget_summary,
        "dirichlet_prior_sensitivity.csv": alpha_sensitivity,
        "explanation_case_ids.csv": pd.DataFrame({"CaseID": case_ids}),
    }
    for name, frame in exports.items():
        frame.to_csv(output_dir / name, index=False)
    protocol = {
        "task": "7.2", "dataset": "BPI 2017", "python": platform.python_version(),
        "code_sha256": _sha256(Path(__file__)), "input_sha256": hashes,
        "seed": seed, "bootstrap_replicates": bootstraps, "subsample_replicates": subsamples,
        "feature_universe": features, "explanation_cases": m,
        "default_alpha": .5, "prior_sensitivity_alphas": [.1, .5, 1., 2.],
        "entropy_and_code_unit": "bits (log2)", "code_to_deviance_factor": "2 ln(2)",
        "test_cases_used": False, "models_refitted": False,
        "code_header": "Uniform k in 1..K; uniform subset given k: ln(K) + ln(binomial(K,k)).",
        "side_information": "Known feature universe; matched case IDs/order and cohort size; fixed support rule; alpha.",
        "support": "START to any selected feature; each feature to any other feature or END; END to START.",
        "path_length": "Each case contributes k+2 transitions including deterministic restart.",
        "limitations": [
            "Model-derived rankings are not independent additional evidence for BIC.",
            "Different k encode different messages; this is not ordinary MDL on one common response.",
            "Explanation cohort size is an implicit preference, not a universally justified weight.",
            "First-order paths may assign mass to sequences that are not valid full rankings.",
            "Bootstrap conditions on fitted models, SHAP rankings, feature order and training BIC.",
            "No claim that a code in bits measures human understanding or causal explanation.",
        ],
    }
    (output_dir / "coding_protocol.json").write_text(json.dumps(protocol, indent=2) + "\n", encoding="utf-8")
    if show:
        display(Markdown("**Task 7.2: selection comparison.** Validation metrics describe the consequences; they do not tune the coding rule."))
        display(comparison[["criterion", "selected_k", "validation_accuracy", "validation_roc_auc", "validation_log_loss"]])
        display(results[["feature_group_count", "explanation_cases", "transition_count", "BIC",
                         "ks_entropy_bits_per_transition", "ks_path_bits_per_case",
                         "complete_code_bits_per_case", "BIC_plus_2_KS_path_cost", "BIC_plus_2_mixture_code"]])
    _figures(results, code_budget, bootstrap_frequencies, output_dir, show)
    if show:
        display(budget_summary[["explanation_cases", "modal_selected_k", "modal_selection_frequency"]])
        display(alpha_sensitivity[alpha_sensitivity.selected_by_complete_code][[
            "dirichlet_alpha", "feature_group_count", "complete_code_cost_bits", "BIC_plus_2_mixture_code"]])
    bic_k, code_k = _selected(results, "BIC"), _selected(results, "BIC_plus_2_mixture_code")
    baseline = results[results.feature_group_count.eq(bic_k)].iloc[0]
    chosen = results[results.feature_group_count.eq(code_k)].iloc[0]
    findings = (
        f"BIC selects {bic_k} feature groups; the complete conditional code at m={m} selects {code_k}. "
        f"Relative to BIC's choice, validation accuracy changes by "
        f"{100 * (chosen.validation_accuracy - baseline.validation_accuracy):+.4f} percentage points, "
        f"ROC AUC by {chosen.validation_roc_auc - baseline.validation_roc_auc:+.5f}, and "
        f"log loss by {chosen.validation_log_loss - baseline.validation_log_loss:+.5f}. "
        "This is an observed tradeoff, not proof that the coding choice is better. "
        "The budget plot must be read alongside the selection: m controls how much explanation "
        "information is charged. Bootstrap frequencies are conditional on saved models and rankings, "
        "not probabilities that a feature count is correct."
    )
    (output_dir / "findings.txt").write_text(findings + "\n", encoding="utf-8")
    if show:
        display(Markdown("**Reading the result.** " + findings))
    return {"candidates": results, "selection": comparison, "budget_summary": budget_summary,
            "bootstrap_frequencies": bootstrap_frequencies, "prior_sensitivity": alpha_sensitivity,
            "protocol": protocol}
