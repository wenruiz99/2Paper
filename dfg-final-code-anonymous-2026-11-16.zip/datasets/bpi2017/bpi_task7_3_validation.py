"""Task 7.3: separate graph estimation from preferences and audit the tradeoff.

Only this task's output directory is written. Existing experiments are neither
rerun nor overwritten; seven reference LR fits are checked against their exports.
"""
from __future__ import annotations

from dataclasses import replace
import hashlib
import json
import math
from pathlib import Path
import platform
import warnings

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.special import xlogy
from sklearn.exceptions import ConvergenceWarning
from sklearn.metrics import roc_auc_score
from IPython.display import Image, Markdown, display

from bpi_task7_2_explanation_coding import load_saved_candidates, case_transition_counts
from multidataset_dfg_study import DFGStudy, StudyConfig, _stratified_indices


OUTPUT_DIRECTORY = "task7_3_stability_tradeoff_outputs"
COLORS = ["#767676", "#238459", "#cf7631", "#286b9b", "#9b517a", "#74752c", "#3b8b91"]
METRICS = ("accuracy", "roc_auc", "log_loss")


def cycle_entropy(counts):
    """Empirical first-order path information in bits per complete case cycle."""
    counts = np.asarray(counts, dtype=float)
    outgoing = counts.sum(axis=1)
    if not np.isfinite(counts).all() or np.any(counts < 0) or outgoing[0] <= 0:
        raise ValueError("Nonnegative finite counts and at least one case are required.")
    if not np.allclose(outgoing, outgoing[0]) or not np.allclose(outgoing, counts.sum(axis=0)):
        raise ValueError("Expected complete restart-closed feature-ranking paths.")
    probabilities = counts / outgoing[:, None]
    log_probabilities = np.zeros_like(probabilities)
    np.log2(probabilities, out=log_probabilities, where=probabilities > 0)
    return max(0.0, float(-np.sum(counts * log_probabilities) / outgoing[0]))


def pareto_mask(complexity, loss):
    """Both coordinates are minimized; equal points do not dominate each other."""
    x, y = np.asarray(complexity), np.asarray(loss)
    if x.shape != y.shape or not np.isfinite(x).all() or not np.isfinite(y).all():
        raise ValueError("Pareto coordinates must be finite aligned arrays.")
    return np.asarray([not np.any((x <= a) & (y <= b) & ((x < a) | (y < b)))
                       for a, b in zip(x, y)])


def block_indices(n, length, rng):
    """Circular moving blocks of chronological CASES, truncated to n cases."""
    if n < 1 or length < 1 or length > n:
        raise ValueError("Block length must lie between one and the number of cases.")
    starts = rng.integers(0, n, size=math.ceil(n / length))
    return ((starts[:, None] + np.arange(length)) % n).ravel()[:n]


def probability_metrics(y, probabilities):
    y, probabilities = np.asarray(y), np.asarray(probabilities, dtype=float)
    if probabilities.ndim == 1:
        probabilities = probabilities[:, None]
    if len(y) != len(probabilities) or set(np.unique(y)) != {0, 1}:
        raise ValueError("Aligned outcomes containing both classes are required.")
    if not np.isfinite(probabilities).all() or np.any((probabilities < 0) | (probabilities > 1)):
        raise ValueError("Probabilities must be finite and in [0,1].")
    clipped = np.clip(probabilities, 1e-12, 1 - 1e-12)
    return {
        "accuracy": ((probabilities >= .5) == y[:, None]).mean(axis=0),
        "roc_auc": np.asarray([roc_auc_score(y, p) for p in probabilities.T]),
        "log_loss": -(y[:, None] * np.log(clipped) + (1 - y[:, None]) * np.log1p(-clipped)).mean(axis=0),
    }


def fixed_budget_scores(bic, entropy_per_case, budget):
    if not np.isfinite(budget) or budget < 0:
        raise ValueError("Reference coding budget must be finite and nonnegative.")
    return np.asarray(bic) + 2 * budget * np.asarray(entropy_per_case)


class ExplicitSplitStudy(DFGStudy):
    """Reuse study fit/SHAP helpers on explicit partitions without writing protocol files."""

    def __init__(self, train, validation, config):
        self.config = config
        self.train_data = train.reset_index(drop=True)
        self.validation_data = validation.reset_index(drop=True)
        self.preprocessor = self._make_preprocessor(drop_first=config.one_hot_drop_first)
        self.X_train = np.asarray(self.preprocessor.fit_transform(self.train_data[config.features]), dtype=float)
        self.X_validation = np.asarray(self.preprocessor.transform(self.validation_data[config.features]), dtype=float)
        self.y_train = self.train_data[config.target_column].to_numpy(dtype=int)
        self.y_validation = self.validation_data[config.target_column].to_numpy(dtype=int)
        self.transformed_names, self.group_indices = self._transformed_group_indices(self.preprocessor)
        rng = np.random.default_rng(config.random_state)
        self.probe_indices = _stratified_indices(self.y_validation, config.explanation_cases, rng)
        self.background_indices = _stratified_indices(self.y_train, config.background_cases, rng)
        # Preserve the original helper's RNG order for exact reference reconstruction.
        self.sweep_probe_indices = _stratified_indices(self.y_validation, config.sweep_explanation_cases, rng)
        self.sweep_background_indices = _stratified_indices(self.y_train, config.sweep_background_cases, rng)
        self.ranking_indices = _stratified_indices(self.y_train, config.ranking_cases, rng)
        self.probe_case_ids = self.validation_data.iloc[self.probe_indices][config.case_id_column].to_numpy()
        self.probe_outcomes = self.y_validation[self.probe_indices]


def load_development(root):
    configuration = pd.read_csv(root / "study_protocol_configuration.csv").iloc[0]
    if configuration.dataset_key != "bpi2017_after_first_offer":
        raise ValueError("This experiment is scoped to the BPI 2017 notebook.")
    config = StudyConfig(
        dataset_key=configuration.dataset_key, dataset_title=configuration.dataset_title,
        features=json.loads(configuration.features),
        numerical_features=json.loads(configuration.numerical_features),
        categorical_features=json.loads(configuration.categorical_features),
        feature_labels=json.loads(configuration.feature_labels),
        target_column=configuration.target_column, case_id_column=configuration.case_id_column,
        time_column=configuration.time_column, split_mode="chronological",
        random_state=int(configuration.random_state), one_hot_drop_first=bool(configuration.one_hot_drop_first),
        explanation_cases=int(configuration.explanation_cases), background_cases=int(configuration.background_cases),
        ranking_cases=int(configuration.ranking_cases),
        sweep_explanation_cases=int(configuration.sweep_explanation_cases),
        sweep_background_cases=int(configuration.sweep_background_cases),
        rank_tie_relative_tolerance=float(configuration.rank_tie_relative_tolerance),
    )
    partitions = pd.read_csv(root / "study_protocol_partitions.csv").set_index("partition")
    cutoff = pd.to_datetime(partitions.loc["test", "start"], utc=True)
    validation_start = pd.to_datetime(partitions.loc["validation", "start"], utc=True)
    columns = [config.case_id_column, *config.features, config.time_column, "outcome_time", config.target_column]
    raw = pd.read_csv(root / "canonical_after_first_offer_final_application_outcome.csv", usecols=columns)
    # Use explicit historical membership, not a version-dependent parser quirk.
    membership = pd.read_csv(root / "study_cohort_membership.csv", dtype={"CaseID":str})
    if membership.CaseID.duplicated().any() or set(membership.CaseID) != set(raw.CaseID):
        raise ValueError("Pinned membership and canonical case IDs disagree.")
    contract = json.loads((root / "study_cohort_contract.json").read_text(encoding="utf-8"))
    for name, expected in [(contract["source_file"],contract["source_sha256"]),
                           ("study_cohort_membership.csv",contract["membership_sha256"])]:
        if hashlib.sha256((root / name).read_bytes()).hexdigest() != expected:
            raise ValueError("Changed cohort input: " + name)
    legacy_included = raw.CaseID.isin(membership.loc[membership.partition.ne("excluded"),"CaseID"])
    raw[config.time_column] = pd.to_datetime(raw[config.time_column], utc=True, format="ISO8601", errors="raise")
    raw["outcome_time"] = pd.to_datetime(raw.outcome_time, utc=True, format="ISO8601", errors="raise")
    if raw.CaseID.isna().any() or raw.CaseID.duplicated().any():
        raise ValueError("Canonical case IDs must be present and unique.")
    excluded_development = raw.loc[~legacy_included & raw[config.time_column].lt(cutoff),
                                   [config.case_id_column, config.time_column]].copy()
    development = raw[legacy_included & raw[config.time_column].lt(cutoff)].sort_values([config.time_column, config.case_id_column]).reset_index(drop=True)
    train = development[development[config.time_column] < validation_start].copy()
    validation = development[development[config.time_column] >= validation_start].copy()
    if len(train) != int(partitions.loc["train", "cases"]) or len(validation) != int(partitions.loc["validation", "cases"]):
        raise ValueError("Canonical cohort and saved partition manifest disagree.")
    development.attrs["legacy_timestamp_exclusions"] = excluded_development.to_dict("records")
    return development, train, validation, config, cutoff


def temporal_splits(development, time_column, cutoff, folds=5):
    """Expanding windows; labels must be observable strictly before validation starts."""
    ordered = development.sort_values([time_column, "CaseID"]).reset_index(drop=True)
    edges = np.linspace(len(ordered) // 2, len(ordered), folds + 1, dtype=int)
    starts = [ordered.iloc[i][time_column] for i in edges[:-1]]
    if len(set(starts)) != folds:
        raise ValueError("Too few distinct prediction times for the requested folds.")
    splits = []
    for index, start in enumerate(starts):
        end = starts[index + 1] if index + 1 < len(starts) else cutoff
        past = ordered[ordered[time_column] < start]
        train = past[past.outcome_time < start].copy()
        purged = past[~past.outcome_time.lt(start)].copy()
        validation = ordered[(ordered[time_column] >= start) & (ordered[time_column] < end)].copy()
        if train.empty or validation.empty:
            raise ValueError("Empty chronological training or validation partition.")
        splits.append((train, validation, purged, start, end))
    return splits


def counts_from_artifact(artifact, features, case_order=None):
    events = artifact["feature_log"]
    events = events[events.feature_group.ne("")]
    lookup = {name: i for i, name in enumerate(features)}
    grouped = dict(tuple(events.groupby("CaseID", sort=False)))
    order = list(grouped) if case_order is None else list(case_order)
    if set(order) != set(grouped):
        raise ValueError("Feature-log explanation cases do not align.")
    rankings = [[lookup[x] for x in grouped[case].sort_values("explanation_rank").feature_group] for case in order]
    return case_transition_counts(np.asarray(rankings))


def _fit_checked(study, groups, *, tolerance=1e-4):
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        artifact = study._fit_nested_groups(groups, solver_tolerance=tolerance)
    if any(issubclass(w.category, ConvergenceWarning) for w in caught):
        raise RuntimeError("Unpenalized LR did not converge; no selection results have been accepted.")
    return artifact, [str(w.message) for w in caught]


def reconstruct_reference(train, validation, config, candidates, feature_order, case_ids, output):
    study = ExplicitSplitStudy(train, validation, config)
    if set(study.probe_case_ids) != set(case_ids):
        raise ValueError("Reconstructed explanation cohort differs from Task 3.")
    probabilities, checks = [], []
    for candidate in candidates:
        k = candidate["k"]
        artifact, fit_warnings = _fit_checked(study, feature_order[:k])
        metrics = probability_metrics(study.y_validation, artifact["validation_probabilities"])
        old = candidate["model"]
        bic_difference = float(artifact["BIC"] - old["BIC"])
        if abs(bic_difference) > 1e-6:
            raise ValueError(f"Reference BIC failed reproduction at k={k}: {bic_difference}")
        for metric in METRICS:
            if not np.isclose(metrics[metric][0], old[f"validation_{metric}"], atol=1e-9, rtol=0):
                raise ValueError(f"Reference {metric} failed reproduction at k={k}.")
        case_counts = counts_from_artifact(artifact, feature_order[:k], case_ids)
        if not np.array_equal(case_counts, candidate["case_counts"]):
            raise ValueError(f"Reference per-case feature rankings changed at k={k}.")
        checks.append({"feature_group_count": k, "BIC_difference": bic_difference,
                       "case_rankings_identical": True, "fit_warnings": " | ".join(fit_warnings)})
        probabilities.append(artifact["validation_probabilities"])
    predictions = validation[["CaseID", config.time_column, config.target_column]].reset_index(drop=True).copy()
    for k, values in enumerate(probabilities, start=1):
        predictions[f"accepted_probability_k_{k}"] = values
    predictions.to_csv(output / "verified_reference_validation_probabilities.csv", index=False)
    pd.DataFrame(checks).to_csv(output / "reference_reconstruction_checks.csv", index=False)
    return np.column_stack(probabilities)


def estimation_experiment(candidates, budgets, reference_budget, repetitions, rng):
    m_max, K = len(candidates[0]["case_counts"]), len(candidates)
    bic = np.asarray([c["model"]["BIC"] for c in candidates])
    sizes = sorted(set(min(x, m_max) for x in [10, 25, 50, 100, 250, 500, m_max]))
    rows, selections = [], []
    for m in sizes:
        for replicate in range(1 if m == m_max else repetitions):
            indices = np.arange(m_max) if m == m_max else rng.choice(m_max, m, replace=False)
            entropy = np.asarray([cycle_entropy(c["case_counts"][indices].sum(axis=0)) for c in candidates])
            scores = fixed_budget_scores(bic, entropy, reference_budget)
            selections.append({"estimation_cases_m": m, "replicate": replicate + 1,
                               "fixed_budget_M": reference_budget, "selected_k": int(scores.argmin() + 1)})
            rows.extend({"estimation_cases_m": m, "replicate": replicate + 1, "feature_group_count": k,
                         "entropy_bits_per_case": value} for k, value in enumerate(entropy, start=1))
    samples = pd.DataFrame(rows)
    summary = samples.groupby(["estimation_cases_m", "feature_group_count"]).entropy_bits_per_case.agg(
        mean="mean", p025=lambda x: x.quantile(.025), p975=lambda x: x.quantile(.975), repetitions="size"
    ).reset_index()
    selection = pd.DataFrame(selections)
    frequencies = selection.groupby(["estimation_cases_m", "selected_k"]).size().rename("count").reset_index()
    frequencies["frequency"] = frequencies["count"] / frequencies.groupby("estimation_cases_m")["count"].transform("sum")
    full_entropy = np.asarray([cycle_entropy(c["counts"]) for c in candidates])
    # Match only the zero-to-full penalty span; interior counts use no DFG information.
    count_cost = np.arange(K) / (K - 1) * full_entropy[-1]
    comparisons = []
    for budget in budgets:
        for method, cost in [("KS per-case information", full_entropy), ("Range-matched feature count", count_cost)]:
            scores = fixed_budget_scores(bic, cost, budget)
            selected = int(scores.argmin() + 1)
            comparisons.extend({"reference_budget_M": budget, "criterion": method,
                                "feature_group_count": k, "complexity_bits_equivalent": cost[k - 1],
                                "score": scores[k - 1], "selected": k == selected,
                                "selected_k": selected} for k in range(1, K + 1))
    return samples, summary, selection, frequencies, pd.DataFrame(comparisons)


def paired_bootstrap(y, probabilities, replicates, block_length, rng, candidates=None, probe_positions=None):
    rows, differences = [], []
    for replicate in range(replicates):
        indices = block_indices(len(y), block_length, rng)
        metrics = probability_metrics(y[indices], probabilities[indices])
        if candidates is not None:
            weights = np.bincount(indices, minlength=len(y))[probe_positions]
            if weights.sum() == 0:
                raise ValueError("A bootstrap contains no explained cases.")
            entropy = np.asarray([cycle_entropy(np.tensordot(weights, c["case_counts"], axes=(0, 0))) for c in candidates])
            pareto = pareto_mask(entropy, metrics["log_loss"])
            rows.extend({"replicate": replicate + 1, "block_length_cases": block_length,
                         "feature_group_count": k + 1, "entropy_bits_per_case": entropy[k],
                         "pareto": bool(pareto[k]), **{name: values[k] for name, values in metrics.items()}}
                        for k in range(probabilities.shape[1]))
        for metric in METRICS:
            # A two-column input is explicitly [k=2, k=4]; otherwise use the full path.
            left, right = (0, 1) if probabilities.shape[1] == 2 else (1, 3)
            differences.append({"replicate": replicate + 1, "block_length_cases": block_length,
                                "metric": metric, "difference_k2_minus_k4": float(metrics[metric][left] - metrics[metric][right])})
    return pd.DataFrame(rows), pd.DataFrame(differences)


def difference_intervals(replicates, point_metrics):
    rows = []
    for (length, metric), group in replicates.groupby(["block_length_cases", "metric"]):
        values = group.difference_k2_minus_k4
        lo, hi = values.quantile([.025, .975])
        point = float(point_metrics[metric][0] - point_metrics[metric][1])
        rows.append({"block_length_cases": length, "metric": metric,
                     "difference_k2_minus_k4": point, "p025": lo, "p975": hi,
                     "replicates": len(values), "interval_excludes_zero": bool(lo > 0 or hi < 0),
                     "negative_favors_k2": metric == "log_loss"})
    return pd.DataFrame(rows)


def chronological_refits(development, config, cutoff, output, folds, bootstraps, rng):
    measures, ranks, manifest, predictions, intervals, memberships = [], [], [], [], [], []
    for fold, (train, validation, purged, start, end) in enumerate(temporal_splits(development, config.time_column, cutoff, folds), start=1):
        print(f"Task 7.3: chronological fold {fold}/{folds}, {len(train)} eligible training cases, {len(validation)} validation cases.", flush=True)
        fold_dir = output / f"fold_{fold}"
        fold_dir.mkdir(exist_ok=True)
        fold_config = replace(config, random_state=config.random_state + fold)
        study = ExplicitSplitStudy(train, validation, fold_config)
        full, _ = _fit_checked(study, config.features, tolerance=1e-8)
        train_shap = study._linear_grouped_shap(full["model"], full["indices"],
                                               study.X_train[study.ranking_indices], study.X_train[study.background_indices])
        importance = np.abs(train_shap).mean(axis=0)
        order = sorted(config.features, key=lambda f: (-importance[config.features.index(f)], config.features.index(f)))
        for rank, feature in enumerate(order, start=1):
            ranks.append({"fold": fold, "rank": rank, "feature_group": feature,
                          "training_mean_absolute_grouped_shap": importance[config.features.index(feature)]})
        probs = []
        previous_likelihood = -np.inf
        for k in range(1, len(order) + 1):
            artifact, fit_warnings = _fit_checked(study, order[:k], tolerance=1e-8)
            if artifact["training_log_likelihood"] < previous_likelihood - 1e-4:
                raise RuntimeError(f"Nested training likelihood decreased in fold {fold}, k={k}.")
            previous_likelihood = artifact["training_log_likelihood"]
            values = artifact["validation_probabilities"]
            probs.append(values)
            case_counts = counts_from_artifact(artifact, order[:k])
            entropy = cycle_entropy(case_counts.sum(axis=0))
            metrics = probability_metrics(study.y_validation, values)
            artifact["feature_log"].to_csv(fold_dir / f"feature_count_{k:02d}_feature_log.csv", index=False)
            study._write_graph(artifact["analysis_closed_graph"], fold_dir / f"feature_count_{k:02d}_feature_only_closed_dfg.graphml")
            measures.append({"fold": fold, "feature_group_count": k,
                             "included_feature_groups": " | ".join(order[:k]), "BIC": artifact["BIC"],
                             "design_rank_p": artifact["design_rank_p"], "training_log_likelihood": artifact["training_log_likelihood"],
                             "entropy_bits_per_case": entropy, "ks_entropy_bits_per_transition": entropy / (k + 2),
                             "explanation_cases": len(case_counts), "fit_warnings": " | ".join(fit_warnings),
                             "solver_tolerance": 1e-8, "solver_iterations": int(artifact["model"].n_iter_[0]),
                             **{f"validation_{name}": metric[0] for name, metric in metrics.items()}})
        probabilities = np.column_stack(probs)
        prediction = validation[["CaseID", config.time_column, config.target_column]].reset_index(drop=True).copy()
        prediction.insert(0, "fold", fold)
        for k in range(1, len(order) + 1):
            prediction[f"accepted_probability_k_{k}"] = probabilities[:, k - 1]
        predictions.append(prediction)
        length = math.ceil(math.sqrt(len(validation)))
        _, differences = paired_bootstrap(study.y_validation, probabilities[:, [1, 3]], bootstraps, length, rng)
        differences.insert(0, "fold", fold)
        differences.to_csv(fold_dir / "paired_k2_k4_bootstrap_replicates.csv", index=False)
        ci = difference_intervals(differences, probability_metrics(study.y_validation, probabilities[:, [1, 3]]))
        ci.insert(0, "fold", fold)
        intervals.append(ci)
        manifest.append({"fold": fold, "training_cases": len(train), "purged_unavailable_labels": len(purged),
                         "validation_cases": len(validation), "validation_start": start, "validation_end_exclusive": end,
                         "latest_training_prediction": train[config.time_column].max(),
                         "latest_training_outcome": train.outcome_time.max(),
                         "preprocessing_fit_cases": len(train), "ranking_cases": len(study.ranking_indices),
                         "all_training_labels_known_before_validation": bool(train.outcome_time.max() < start),
                         "test_cases_used": False})
        for role, frame in [("train", train), ("validation", validation), ("purged_label_unavailable", purged)]:
            membership = frame[["CaseID", config.time_column, "outcome_time"]].copy()
            membership.insert(0, "role", role)
            membership.insert(0, "fold", fold)
            memberships.append(membership)
    return (pd.DataFrame(measures), pd.DataFrame(ranks), pd.DataFrame(manifest),
            pd.concat(predictions, ignore_index=True), pd.concat(intervals, ignore_index=True),
            pd.concat(memberships, ignore_index=True))


def _figure(fig, output, name, show):
    fig.savefig(output / name, dpi=170, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    if show:
        display(Image(filename=str(output / name)))


def make_figures(point, estimation, frequencies, preference, pair_ci, primary_length, fold_results, fold_ci, output, show):
    fig, axes = plt.subplots(1, 2, figsize=(13, 4.7), constrained_layout=True)
    for k, group in estimation.groupby("feature_group_count"):
        axes[0].plot(group.estimation_cases_m, group["mean"], "o-", color=COLORS[k-1], label=f"k={k}")
        axes[0].fill_between(group.estimation_cases_m, group.p025, group.p975, color=COLORS[k-1], alpha=.12)
    axes[0].set(xscale="log", xlabel="Cases used to estimate entropy (m)", ylabel="First-order information (bits per case)",
                title="Entropy estimation, not total coding cost\nShading: 95% subsampling range")
    axes[0].legend(ncols=2, fontsize=8)
    axes[0].text(.03, .06, "k=1 and k=2 coincide at zero", transform=axes[0].transAxes, fontsize=8)
    matrix = frequencies.pivot(index="estimation_cases_m", columns="selected_k", values="frequency").reindex(columns=range(1,8)).fillna(0)
    axes[1].imshow(matrix, aspect="auto", cmap="YlGnBu", vmin=0, vmax=1)
    for row, values in enumerate(matrix.to_numpy()):
        for col, value in enumerate(values):
            if value:
                axes[1].text(col, row, f"{value:.1%}", ha="center", va="center", color="white" if value>.55 else "black", fontsize=9)
    axes[1].set(xticks=range(7), xticklabels=range(1,8), yticks=range(len(matrix)), yticklabels=matrix.index,
                xlabel="Selected feature count (k)", ylabel="Entropy-estimation cases (m)",
                title="Selection with coding strength held fixed\nReference budget M = 500")
    _figure(fig, output, "estimation_size_with_fixed_budget.png", show)

    fig, axes = plt.subplots(1, 2, figsize=(13, 4.5), constrained_layout=True)
    selections = preference[preference.selected]
    styles = {"KS per-case information": ("#277b59", "-", "o", "#277b59"),
              "Range-matched feature count": ("#c07035", "--", "s", "none")}
    for name, group in selections.groupby("criterion", sort=False):
        color, line, marker, fill = styles[name]
        axes[0].step(group.reference_budget_M, group.selected_k, where="post", label=name,
                     color=color, linestyle=line)
        axes[0].plot(group.reference_budget_M, group.selected_k, linestyle="none", marker=marker,
                     color=color, markerfacecolor=fill, markersize=5)
    axes[0].set(xscale="symlog", xlabel="Reference coding budget (M), fixed entropy estimate", ylabel="Selected feature count",
                yticks=range(1,8), title="Choices on the tested budget grid\nPreference strength changes the objective")
    axes[0].legend(fontsize=8)
    axes[1].plot(point.feature_group_count, point.entropy_bits_per_case, "o-", label="KS per-case information", color="#277b59")
    axes[1].plot(point.feature_group_count, point.count_only_cost, "s--", label="Range-matched count-only baseline", color="#c07035")
    axes[1].set(xlabel="Feature count (k)", ylabel="Bits per case / matched diagnostic scale", xticks=range(1,8), title="Does KS add more than a preference for fewer features?")
    axes[1].legend(fontsize=8)
    for axis in axes:
        axis.grid(alpha=.2)
    _figure(fig, output, "preference_strength_and_count_baseline.png", show)

    fig, axes = plt.subplots(1, 2, figsize=(13, 5), constrained_layout=True)
    for axis, xname, xlo, xhi, xlabel in [
        (axes[0], "entropy_bits_per_case", "entropy_bits_per_case_p025", "entropy_bits_per_case_p975", "KS-based information (bits per case)"),
        (axes[1], "feature_group_count", None, None, "Feature count (k)"),
    ]:
        for row in point.itertuples():
            k = row.feature_group_count
            x = getattr(row, xname)
            # Percentile endpoints need not bracket the original point estimate.
            axis.vlines(x, row.log_loss_p025, row.log_loss_p975, color=COLORS[k-1], alpha=.6)
            if xlo:
                axis.hlines(row.log_loss, getattr(row, xlo), getattr(row, xhi), color=COLORS[k-1], alpha=.6)
            axis.scatter(x, row.log_loss, color=COLORS[k-1], s=55, marker="o" if row.pareto else "x")
            axis.annotate(f"k={k}", (x, row.log_loss), xytext=(5, 7 if k % 2 else -14), textcoords="offset points", fontsize=9)
        efficient = point[point.pareto].sort_values(xname)
        axis.plot(efficient[xname], efficient.log_loss, "--", color="#888", linewidth=.9)
        axis.set(xlabel=xlabel, ylabel="Validation log loss (lower is better)")
        axis.grid(alpha=.2)
    axes[0].set_title("Performance versus KS information\nPaired chronological-block bootstrap ranges")
    axes[1].set_title("The same models versus feature count\nCircles: empirical KS/loss Pareto set")
    _figure(fig, output, "performance_complexity_pareto.png", show)

    fig, axes = plt.subplots(1, 3, figsize=(14, 4.5), constrained_layout=True)
    for axis, metric in zip(axes, METRICS):
        rows = pair_ci[pair_ci.metric.eq(metric)].sort_values("block_length_cases")
        axis.axvline(0, color="#999", linestyle=":")
        for index, row in enumerate(rows.itertuples()):
            axis.hlines(index, row.p025, row.p975, color="#286b9b", linewidth=2)
            axis.scatter(row.difference_k2_minus_k4, index, color="#286b9b")
        axis.set(yticks=range(len(rows)), yticklabels=[f"Block {x}" for x in rows.block_length_cases],
                 xlabel="k=2 minus k=4", title=metric.replace("_", " ").title())
        axis.grid(alpha=.2)
    fig.suptitle(f"Paired predictive differences: 95% percentile intervals (primary block = {primary_length} cases)", fontsize=12)
    _figure(fig, output, "paired_predictive_difference_intervals.png", show)

    fig, axes = plt.subplots(2, 2, figsize=(12, 8), constrained_layout=True)
    for axis, metric in zip(axes.flat, METRICS):
        rows = fold_ci[fold_ci.metric.eq(metric)].sort_values("fold")
        axis.axhline(0, color="#999", linestyle=":")
        axis.vlines(rows.fold, rows.p025, rows.p975, color="#286b9b")
        axis.plot(rows.fold, rows.difference_k2_minus_k4, "o-", color="#286b9b")
        axis.set(xlabel="Chronological fold", xticks=rows.fold, ylabel="k=2 minus k=4", title=metric.replace("_", " ").title())
        axis.grid(alpha=.2)
    fold_entropy = fold_results.pivot(index="fold", columns="feature_group_count", values="entropy_bits_per_case")
    axes[1, 1].axhline(0, color="#999", linestyle=":")
    axes[1, 1].plot(fold_entropy.index, fold_entropy[2] - fold_entropy[4], "o-", color="#238459")
    axes[1, 1].set(xlabel="Chronological fold", xticks=fold_entropy.index,
                   ylabel="k=2 minus k=4 (bits per case)", title="KS-based information: point differences")
    axes[1, 1].grid(alpha=.2)
    fig.suptitle("Chronological refits: fold-specific training preprocessing and feature order\nTraining labels unavailable at validation start are excluded", fontsize=12)
    _figure(fig, output, "chronological_refit_differences.png", show)


def run_task7_3(root=".", *, estimation_repeats=200, bootstraps=500, fold_bootstraps=300, seed=73027, show=True):
    root = Path(root).resolve()
    for value in [estimation_repeats, bootstraps, fold_bootstraps]:
        if not isinstance(value, int) or value < 1:
            raise ValueError("Resampling counts must be positive integers.")
    output = root / OUTPUT_DIRECTORY
    output.mkdir(exist_ok=True)
    candidates, feature_order, case_ids, hashes = load_saved_candidates(root)
    development, train, validation, config, cutoff = load_development(root)
    pd.DataFrame(development.attrs["legacy_timestamp_exclusions"]).to_csv(output / "legacy_development_timestamp_exclusions.csv", index=False)
    print("Task 7.3: reconstructing and verifying the seven current LR predictions.", flush=True)
    probabilities = reconstruct_reference(train, validation, config, candidates, feature_order, case_ids, output)
    y = validation[config.target_column].to_numpy(dtype=int)
    index_lookup = {case: i for i, case in enumerate(validation.CaseID)}
    probe_positions = np.asarray([index_lookup[case] for case in case_ids])
    rng = np.random.default_rng(seed)
    budgets = [0, 1, 2, 5, 10, 15, 20, 25, 50, 100, 250, 500, 1000]
    estimates, estimate_summary, fixed_selections, fixed_frequencies, preference = estimation_experiment(candidates, budgets, 500, estimation_repeats, rng)
    primary_length = math.ceil(math.sqrt(len(y)))
    print("Task 7.3: paired chronological-block uncertainty and feature-count controls.", flush=True)
    bootstrap, primary_differences = paired_bootstrap(y, probabilities, bootstraps, primary_length, rng, candidates, probe_positions)
    differences = [primary_differences]
    for length in sorted({1, max(2, primary_length // 2), min(len(y), 2 * primary_length)}):
        _, frame = paired_bootstrap(y, probabilities[:, [1, 3]], bootstraps, length, rng)
        differences.append(frame)
    all_differences = pd.concat(differences, ignore_index=True)
    pair_ci = difference_intervals(all_differences, probability_metrics(y, probabilities[:, [1, 3]]))
    point = pd.DataFrame({"feature_group_count": range(1, len(candidates) + 1),
                          "entropy_bits_per_case": [cycle_entropy(c["counts"]) for c in candidates],
                          "BIC": [c["model"]["BIC"] for c in candidates],
                          **probability_metrics(y, probabilities)})
    point["count_only_cost"] = np.arange(len(point)) / (len(point) - 1) * point.entropy_bits_per_case.iloc[-1]
    point["pareto"] = pareto_mask(point.entropy_bits_per_case, point.log_loss)
    for column in ["entropy_bits_per_case", *METRICS]:
        quantiles = bootstrap.groupby("feature_group_count")[column].quantile([.025, .975]).unstack()
        point[f"{column}_p025"] = quantiles[.025].to_numpy()
        point[f"{column}_p975"] = quantiles[.975].to_numpy()
    point["pareto_bootstrap_frequency"] = bootstrap.groupby("feature_group_count").pareto.mean().to_numpy()
    fold_results, fold_ranks, fold_manifest, fold_predictions, fold_ci, membership = chronological_refits(
        development, config, cutoff, output, 5, fold_bootstraps, rng)
    exports = {
        "entropy_estimation_subsamples.csv": estimates, "entropy_estimation_summary.csv": estimate_summary,
        "fixed_budget_selection_replicates.csv": fixed_selections, "fixed_budget_selection_frequencies.csv": fixed_frequencies,
        "reference_budget_and_count_baseline.csv": preference,
        "paired_tradeoff_bootstrap_replicates.csv": bootstrap,
        "paired_predictive_difference_replicates.csv": all_differences, "paired_predictive_difference_intervals.csv": pair_ci,
        "performance_complexity_pareto.csv": point, "chronological_fold_results.csv": fold_results,
        "chronological_feature_orders.csv": fold_ranks, "chronological_fold_manifest.csv": fold_manifest,
        "chronological_validation_probabilities.csv": fold_predictions,
        "chronological_difference_intervals.csv": fold_ci, "chronological_case_membership.csv": membership,
    }
    for name, frame in exports.items():
        frame.to_csv(output / name, index=False)
    for relative in ["canonical_after_first_offer_final_application_outcome.csv", "study_protocol_configuration.csv",
                     "study_protocol_partitions.csv", "study_cohort_membership.csv", "study_cohort_contract.json",
                     "bpi_task7_2_explanation_coding.py", "multidataset_dfg_study.py"]:
        hashes[relative] = hashlib.sha256((root / relative).read_bytes()).hexdigest()
    protocol = {
        "task": "7.3", "python": platform.python_version(), "seed": seed,
        "source_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(), "input_sha256": hashes,
        "reference_training_cases": len(train), "reference_validation_cases": len(validation),
        "reference_explanation_cases": len(case_ids), "fixed_reference_budget_M": 500,
        "reference_budgets": budgets, "estimation_repeats": estimation_repeats, "bootstrap_replicates": bootstraps,
        "primary_block_length_cases": primary_length, "fold_bootstraps": fold_bootstraps,
        "chronological_folds": 5, "legacy_test_start": str(cutoff), "test_cases_used": False,
        "baseline_probability_source": "Reconstructed and verified current Task 3 models; legacy Task 6.3.1 probability CSV is not used.",
        "entropy_scope": "First-order restart-closed feature-only empirical entropy in bits per case; not full mixture-code rescaling.",
        "preference_scope": "Fixed M separates estimation from preference; no universal or optimal M is asserted.",
        "baseline_scope": "Count-only interior penalties, scaled to the full-feature entropy endpoint; diagnostic, not theoretical BIC.",
        "chronological_scope": "Expanding chronological refits of fixed k=1..7, excluding unavailable training labels; not nested evaluation of an optimized composite selection rule.",
        "fold_ranking": "Training-cohort full unpenalized LR mean absolute grouped SHAP; original feature position breaks exact ties (no L1 tie-break sweep).",
        "solver_tolerance": "Reference reproduces legacy 1e-4; new chronological fits use 1e-8 and check nondecreasing nested training likelihood.",
        "bootstrap_scope": "Paired case/block resampling conditional on fitted models and SHAP; percentile ranges are pointwise and exploratory, not equivalence tests.",
        "temporal_caveat": "Circular blocks are a local-dependence sensitivity approximation; stationarity and optimal block length are not established.",
        "historical_caveat": "Legacy test results were previously inspected; no claim of pristine held-out confirmation.",
        "cohort_caveat": "Retains the saved cohort: 21 valid development cases were excluded by legacy fractional-second timestamp parsing. They are listed separately. A full-cohort rerun is a separate protocol revision.",
    }
    (output / "analysis_protocol.json").write_text(json.dumps(protocol, indent=2) + "\n", encoding="utf-8")
    if show:
        display(Markdown("**Task 7.3: paired predictive differences.** Differences are k=2 minus k=4. Negative log-loss differences favor k=2; positive accuracy/AUC differences favor k=2."))
        display(pair_ci[pair_ci.block_length_cases.eq(primary_length)])
        display(point[["feature_group_count", "entropy_bits_per_case", "accuracy", "roc_auc", "log_loss", "pareto", "pareto_bootstrap_frequency"]])
    make_figures(point, estimate_summary, fixed_frequencies, preference, pair_ci, primary_length, fold_results, fold_ci, output, show)
    if show:
        display(preference[preference.selected][["reference_budget_M", "criterion", "selected_k"]])
        display(fold_manifest[["fold", "training_cases", "purged_unavailable_labels", "validation_cases", "latest_training_outcome", "validation_start", "all_training_labels_known_before_validation"]])
        display(fold_ci[["fold", "metric", "difference_k2_minus_k4", "p025", "p975"]])
    ks_choice = preference[(preference.reference_budget_M == 500) & preference.criterion.eq("KS per-case information") & preference.selected].selected_k.iloc[0]
    count_choice = preference[(preference.reference_budget_M == 500) & preference.criterion.eq("Range-matched feature count") & preference.selected].selected_k.iloc[0]
    auc_worse = int((fold_ci[fold_ci.metric.eq("roc_auc")].difference_k2_minus_k4 < 0).sum())
    loss_worse = int((fold_ci[fold_ci.metric.eq("log_loss")].difference_k2_minus_k4 > 0).sum())
    findings = (
        f"At the fixed illustrative budget M=500, KS selects k={ks_choice} and the range-matched count-only baseline selects k={count_choice}. "
        f"Across five chronological refits, k=2 has lower ROC AUC than k=4 in {auc_worse}/5 folds and higher log loss in {loss_worse}/5 folds. "
        "Agreement with the count-only baseline does not demonstrate a unique contribution from KS. "
        "No acceptable performance-loss threshold was set and no universally best feature count is declared. "
        "The reference paired intervals condition on the reconstructed fitted models; chronological refits use fold-specific feature identities "
        "and stricter label-availability filtering. These are exploratory diagnostics, not a nested validation of a tuned selection policy."
    )
    (output / "findings.txt").write_text(findings + "\n", encoding="utf-8")
    if show:
        display(Markdown("**Interpretation.** " + findings))
    return {"pareto": point, "paired_intervals": pair_ci, "fixed_budget_frequencies": fixed_frequencies,
            "preference_path": preference, "fold_results": fold_results, "fold_intervals": fold_ci,
            "protocol": protocol}
