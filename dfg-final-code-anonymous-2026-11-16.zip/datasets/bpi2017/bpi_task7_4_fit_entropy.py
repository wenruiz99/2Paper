"""Compare BIC + (-2 log likelihood) * KS with saved BPI criteria.

Reads existing fits and feature logs; writes only Task 7.4 outputs. All augmented
scores are exploratory preferences, not derived marginal-likelihood criteria.
"""
from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path
import platform

import matplotlib.pyplot as plt
from matplotlib.ticker import PercentFormatter
import numpy as np
import pandas as pd
from IPython.display import Markdown, display

from bpi_task7_2_explanation_coding import (
    load_saved_candidates, code_components, _save_figure,
)
from multidataset_dfg_extensions import _exact_lower_envelope


OUTPUT_DIRECTORY = "task7_4_fit_entropy_outputs"
LABELS = {
    "bic": "BIC",
    "additive": "BIC + h",
    "product": "BIC + D h",
    "path": "BIC + KS path cost",
    "mixture": "BIC + complete code",
    "count": "BIC + count-only penalty",
}
COLORS = {"bic": "#28688f", "additive": "#797979", "product": "#bd4f36",
          "path": "#278160", "mixture": "#86649a", "count": "#a57b16"}
METRICS = ("validation_accuracy", "validation_roc_auc", "validation_log_loss")


def product_score(bic, deviance, entropy, multiplier=1.0):
    """Keep the BIC fit term intact; h is in bits per transition."""
    bic, deviance, entropy = [np.asarray(x, dtype=float) for x in (bic, deviance, entropy)]
    if bic.shape != deviance.shape or bic.shape != entropy.shape:
        raise ValueError("BIC, deviance, and entropy must have identical shapes.")
    if not all(np.isfinite(x).all() for x in (bic, deviance, entropy)):
        raise ValueError("All score components must be finite.")
    if np.any(deviance < 0) or np.any(entropy < 0):
        raise ValueError("Binary deviance and entropy must be nonnegative.")
    if not np.isfinite(multiplier) or multiplier < 0:
        raise ValueError("The multiplier must be finite and nonnegative.")
    return bic + multiplier * deviance * entropy


def score_candidates(frame, training_cases, explanation_cases):
    """Construct explicitly named scores on one complete, ordered nested path."""
    frame = frame.sort_values("feature_group_count").reset_index(drop=True).copy()
    k = frame.feature_group_count.to_numpy(dtype=int)
    if k.tolist() != list(range(1, len(frame) + 1)) or len(k) < 2:
        raise ValueError("Expected the complete nested feature path, starting at one.")
    if training_cases < 2 or explanation_cases < 1:
        raise ValueError("Positive cohort sizes are required.")
    d = -2 * frame.training_log_likelihood.to_numpy(dtype=float)
    h = frame.ks_entropy_bits_per_transition.to_numpy(dtype=float)
    bic = frame.BIC.to_numpy(dtype=float)
    parameter = frame.design_rank_p.to_numpy(dtype=float) * math.log(training_cases)
    if not np.allclose(bic, d + parameter, rtol=0, atol=1e-7):
        raise ValueError("BIC does not match the saved likelihood, rank, and training size.")
    frame["training_deviance"] = d
    frame["parameter_penalty"] = parameter
    frame["product_penalty"] = d * h
    frame["implicit_entropy_weight"] = d
    frame["mean_training_deviance"] = d / training_cases
    # Match the full-feature product penalty, but use no intermediate DFGs.
    frame["count_only_penalty"] = d[-1] * h[-1] * (k - 1) / (k[-1] - 1)
    scores = {
        "bic": bic,
        "additive": bic + h,
        "product": product_score(bic, d, h),
        "path": bic + 2 * math.log(2) * explanation_cases * (k + 2) * h,
        "count": bic + frame.count_only_penalty.to_numpy(),
    }
    if "complete_code_cost_bits" in frame:
        scores["mixture"] = bic + 2 * math.log(2) * frame.complete_code_cost_bits.to_numpy()
    for method in LABELS:
        if method not in scores:
            continue
        values = scores[method]
        frame[f"score_{method}"] = values
        frame[f"delta_{method}"] = values - values.min()
    return frame


def selection_summary(frame):
    baseline = frame.iloc[np.argmin(frame.score_bic.to_numpy())]
    rows = []
    for method, label in LABELS.items():
        if f"score_{method}" not in frame:
            continue
        chosen = frame.iloc[np.argmin(frame[f"score_{method}"].to_numpy())]
        row = {"criterion": label, "method": method,
               "selected_k": int(chosen.feature_group_count),
               "included_feature_groups": chosen.included_feature_groups,
               "selected_score": chosen[f"score_{method}"],
               "ks_bits_per_transition": chosen.ks_entropy_bits_per_transition,
               "BIC_choice_k": int(baseline.feature_group_count)}
        row.update({name: chosen[name] for name in METRICS})
        row["accuracy_difference_percentage_points"] = 100 * (
            chosen.validation_accuracy - baseline.validation_accuracy)
        row["auc_difference"] = chosen.validation_roc_auc - baseline.validation_roc_auc
        row["log_loss_difference"] = chosen.validation_log_loss - baseline.validation_log_loss
        rows.append(row)
    return pd.DataFrame(rows)


def sensitivity(frame, n):
    bic = frame.BIC.to_numpy()
    d = frame.training_deviance.to_numpy()
    h = frame.ks_entropy_bits_per_transition.to_numpy()
    k = frame.feature_group_count.to_numpy()
    slopes = {"Product D h": d * h, "Additive h": h, "Mean-fit (D/n) h": d * h / n}
    intervals, path = [], []
    grid = np.unique(np.r_[0., np.geomspace(1e-5, 1e3, 241), 1.])
    for label, slope in slopes.items():
        envelope = _exact_lower_envelope(bic, slope, k).rename(columns={
            "lambda_lower": "multiplier_lower", "lambda_upper": "multiplier_upper"})
        envelope.insert(0, "penalty", label)
        intervals.append(envelope)
        for a in grid:
            path.append({"penalty": label, "multiplier": a,
                         "selected_k": int(k[np.argmin(bic + a * slope)])})
    reference = product_score(bic, d, h)
    scenarios = {
        "Primary: h in bits, coefficient 1": reference,
        "Mean-fit penalty (D/n) h: different formula": product_score(bic, d / n, h),
        "Entire score divided by n: same selection": reference / n,
    }
    units = pd.DataFrame([
        {"scenario": name, "selected_k": int(k[np.argmin(values)]),
         "score_at_selected_k": float(values.min())}
        for name, values in scenarios.items()
    ])
    if not np.allclose(reference / n, scenarios["Entire score divided by n: same selection"]):
        raise AssertionError("Whole-score normalization changed the score identity.")
    return pd.concat(intervals, ignore_index=True), pd.DataFrame(path), units


def bootstrap_graphs(candidates, frame, n, m, repeats, seed):
    if not isinstance(repeats, int) or repeats < 1:
        raise ValueError("At least one bootstrap replicate is required.")
    rng = np.random.default_rng(seed)
    rows = []
    for replicate in range(1, repeats + 1):
        indices = rng.integers(0, m, m)
        sample = frame.copy()
        for index, candidate in enumerate(candidates):
            metrics, _ = code_components(candidate["case_counts"][indices].sum(axis=0), len(candidates))
            sample.loc[index, "ks_entropy_bits_per_transition"] = metrics["ks_entropy_bits_per_transition"]
            sample.loc[index, "complete_code_cost_bits"] = metrics["complete_code_cost_bits"]
        sample = score_candidates(sample, n, m)
        for method in LABELS:
            chosen = int(sample.iloc[np.argmin(sample[f"score_{method}"].to_numpy())].feature_group_count)
            rows.append({"bootstrap_id": replicate, "method": method, "selected_k": chosen})
    draws = pd.DataFrame(rows)
    frequencies = pd.DataFrame([
        {"criterion": LABELS[method], "method": method, "feature_group_count": k,
         "selection_frequency": float((draws.loc[draws.method.eq(method), "selected_k"] == k).mean()),
         "bootstrap_replicates": repeats}
        for method in LABELS for k in frame.feature_group_count
    ])
    return draws, frequencies


def chronological_comparison(folds, manifests):
    if sorted(folds.fold.unique()) != sorted(manifests.fold.unique()) or manifests.fold.duplicated().any():
        raise ValueError("Chronological fold identifiers do not align.")
    if manifests.test_cases_used.astype(str).str.lower().ne("false").any():
        raise ValueError("Chronological comparison must not use test cases.")
    if manifests.all_training_labels_known_before_validation.astype(str).str.lower().ne("true").any():
        raise ValueError("Chronological training contains unavailable labels.")
    results, scores = [], []
    for fold, group in folds.groupby("fold", sort=True):
        group = group.copy()
        if not np.allclose(group.entropy_bits_per_case,
                           (group.feature_group_count + 2) * group.ks_entropy_bits_per_transition):
            raise ValueError("Chronological rate/per-case entropy identity failed.")
        m_values = group.explanation_cases.unique()
        if len(m_values) != 1:
            raise ValueError("All candidates in a fold need matched explanation sizes.")
        n = int(manifests.set_index("fold").loc[fold, "training_cases"])
        table = score_candidates(group, n, int(m_values[0]))
        summary = selection_summary(table)
        summary.insert(0, "fold", int(fold))
        results.append(summary)
        scores.append(table)
    return pd.concat(results, ignore_index=True), pd.concat(scores, ignore_index=True)


def figures(frame, summary, path, frequency, folds, out, show,
            feature_symbol="k", parameter_symbol="p"):
    k = frame.feature_group_count.to_numpy()
    ticks = k if len(k) <= 10 else np.unique(np.r_[k[0], k[3::3][k[3::3] < k[-1] - 1], k[-1]])
    selected_counts = set(summary.selected_k.astype(int))
    annotated = set(k) if len(k) <= 10 else {k[0], k[-1]} | selected_counts
    with plt.rc_context({"font.size": 10, "axes.spines.top": False, "axes.spines.right": False}):
        fig, axes = plt.subplots(2, 2, figsize=(12, 8), constrained_layout=True)
        for ax, column, title, ylabel in zip(axes.flat,
                ["training_deviance", "parameter_penalty", "ks_entropy_bits_per_transition", "product_penalty"],
                ["Predictive fit term D = -2 ln(fitted likelihood)", f"Parameter penalty {parameter_symbol} ln(n)",
                 "KS entropy h", "New additional penalty D h"],
                ["D", "Penalty", "Bits per transition", "Additional score"]):
            ax.plot(k, frame[column], "o-", color=COLORS["product"] if column == "product_penalty" else COLORS["bic"])
            for x, y in zip(k, frame[column]):
                if x not in annotated:
                    continue
                ax.annotate(f"{y:,.3f}" if column.startswith("ks_") else f"{y:,.1f}",
                            (x, y), xytext=(0, 8), textcoords="offset points", ha="center", fontsize=8)
            ax.set(title=title, xlabel=f"Feature groups ({feature_symbol})", ylabel=ylabel, xticks=ticks)
            ax.margins(y=.2, x=.1)
            ax.grid(alpha=.2)
        fig.suptitle("Task 7.4: components of BIC + D h", fontsize=14)
        _save_figure(fig, out / "score_components.png", show)

        fig, axes = plt.subplots(2, 3, figsize=(14, 8), constrained_layout=True)
        for ax, method in zip(axes.flat, LABELS):
            values = frame[f"delta_{method}"]
            selected = int(summary.loc[summary.method.eq(method), "selected_k"].iloc[0])
            ax.plot(k, values, "o-", color=COLORS[method])
            ax.axvline(selected, color="#555555", linestyle=":", alpha=.6)
            ax.set(title=f"{LABELS[method]}\nSelected {feature_symbol} = {selected}", xlabel=f"Feature groups ({feature_symbol})",
                   ylabel="Score minus this criterion's minimum", xticks=ticks)
            ax.grid(alpha=.2)
        fig.suptitle("Separate score scales; lower is preferred within each criterion", fontsize=14)
        _save_figure(fig, out / "criterion_comparison.png", show)

        bic_k = int(summary.loc[summary.method.eq("bic"), "selected_k"].iloc[0])
        product_k = int(summary.loc[summary.method.eq("product"), "selected_k"].iloc[0])
        fig, axes = plt.subplots(1, 3, figsize=(14, 4.5), constrained_layout=True)
        for ax, metric, title in zip(axes, METRICS, ["Validation accuracy", "Validation ROC AUC", "Validation log loss"]):
            ax.plot(k, frame[metric], "o-", color="#333333")
            for chosen, color, label, linestyle in [(bic_k, COLORS["bic"], "BIC", "--"),
                                                    (product_k, COLORS["product"], "BIC + D h", ":")]:
                value = float(frame.loc[frame.feature_group_count.eq(chosen), metric].iloc[0])
                text = f"{100 * value:.3f}%" if metric.endswith("accuracy") else f"{value:.4f}"
                ax.axvline(chosen, color=color, linestyle=linestyle, label=f"{label}: {feature_symbol}={chosen}, {text}")
            if metric.endswith("accuracy"):
                ax.yaxis.set_major_formatter(PercentFormatter(1, decimals=1))
            ax.set(title=title, xlabel=f"Feature groups ({feature_symbol})", xticks=ticks)
            ax.legend(fontsize=8, loc="best")
            ax.grid(alpha=.2)
        fig.suptitle("Observed validation consequences, not independent confirmation", fontsize=14)
        _save_figure(fig, out / "validation_consequences.png", show)

        fig, axes = plt.subplots(1, 2, figsize=(14, 5), constrained_layout=True,
                                 gridspec_kw={"width_ratios": [1, 1.4] if len(k) > 10 else [1, 1]})
        for (label, group), color, style in zip(path.groupby("penalty", sort=False),
                                              [COLORS["product"], COLORS["bic"], COLORS["path"]], ["-", "--", ":"]):
            axes[0].step(group.multiplier, group.selected_k, where="post", label=label, color=color, linestyle=style)
        axes[0].axvline(1, color="#777777", linestyle="-.", label="Stated coefficient = 1")
        axes[0].set(xscale="symlog", xlabel="Penalty multiplier a (displayed grid)", ylabel=f"Selected {feature_symbol}",
                    yticks=ticks, title="BIC + a times the stated penalty")
        axes[0].set_xscale("symlog", linthresh=1e-5)
        maximum = max(1e3, float(path.multiplier.max()))
        axes[0].set_xlim(0, maximum)
        axes[0].set_xticks([0, *[10.**power for power in range(-3, int(math.log10(maximum)) + 1)]])
        axes[0].legend(fontsize=8)
        axes[0].grid(alpha=.2)
        matrix = frequency.pivot(index="method", columns="feature_group_count", values="selection_frequency").reindex(LABELS)
        axes[1].imshow(matrix, vmin=0, vmax=1, cmap="Blues", aspect="auto")
        axes[1].set(xticks=np.arange(len(k)), xticklabels=k, yticks=np.arange(len(LABELS)),
                    yticklabels=list(LABELS.values()), xlabel=f"Selected feature groups ({feature_symbol})",
                    title="Graph-only bootstrap selection frequency")
        for row in range(len(LABELS)):
            for col in range(len(k)):
                value = matrix.iloc[row, col]
                if len(k) > 10 and value == 0:
                    continue
                axes[1].text(col, row, f"{value:.0%}", ha="center", va="center",
                             color="white" if value > .5 else "#222222", fontsize=8 if len(k) <= 10 else 7)
        if len(k) > 10:
            axes[1].tick_params(axis="x", labelsize=8)
            axes[1].set_title("Graph-only bootstrap selection frequency\nBlank cells = 0%", fontsize=10)
        _save_figure(fig, out / "sensitivity_and_bootstrap.png", show)

        if folds is None:
            return

        fig, axes = plt.subplots(1, 3, figsize=(14, 4.8), constrained_layout=True)
        for method, style in [("bic", "--"), ("product", "-"), ("count", ":")]:
            group = folds[folds.method.eq(method)]
            axes[0].plot(group.fold, group.selected_k, marker="o", linestyle=style,
                         color=COLORS[method], label=LABELS[method], alpha=.8)
        axes[0].set(title="Choices on saved chronological refits", ylabel="Selected k", yticks=k)
        axes[0].legend(fontsize=8)
        group = folds[folds.method.eq("product")]
        for ax, column, title, ylabel in zip(axes[1:],
                ["accuracy_difference_percentage_points", "auc_difference"],
                ["Product choice minus BIC choice", "Product choice minus BIC choice"],
                ["Accuracy difference (percentage points)", "ROC AUC difference"]):
            ax.axhline(0, color="#777777", linewidth=1)
            ax.plot(group.fold, group[column], "o-", color=COLORS["product"])
            ax.set(title=title, ylabel=ylabel)
            for x, y in zip(group.fold, group[column]):
                ax.annotate(f"{y:+.4f}", (x, y), xytext=(0, 8), textcoords="offset points", ha="center", fontsize=8)
            ax.margins(x=.15, y=.25)
        for ax in axes:
            ax.set(xlabel="Chronological fold", xticks=group.fold)
            ax.grid(alpha=.2)
        fig.suptitle("Reused Task 7.3 fits; descriptive comparisons, not nested policy validation", fontsize=13)
        _save_figure(fig, out / "chronological_comparison.png", show)


def run_task7_4(root=".", bootstraps=500, seed=74027, show=True):
    root = Path(root).resolve()
    candidates, features, cases, hashes = load_saved_candidates(root)
    files = {
        "partitions": "study_protocol_partitions.csv",
        "coding": "task7_2_explanation_coding_outputs/coding_candidate_results.csv",
        "folds": "task7_3_stability_tradeoff_outputs/chronological_fold_results.csv",
        "manifests": "task7_3_stability_tradeoff_outputs/chronological_fold_manifest.csv",
    }
    saved = {}
    for key, relative in files.items():
        saved[key] = pd.read_csv(root / relative)
        hashes[relative] = hashlib.sha256((root / relative).read_bytes()).hexdigest()
    n = int(saved["partitions"].set_index("partition").loc["train", "cases"])
    m = len(cases)
    frame = pd.DataFrame([c["model"] for c in candidates])
    for index, candidate in enumerate(candidates):
        metrics, _ = code_components(candidate["counts"], len(features))
        for name in ["ks_entropy_bits_per_transition", "complete_code_cost_bits"]:
            frame.loc[index, name] = metrics[name]
    reference = saved["coding"].sort_values("feature_group_count")
    if reference.feature_group_count.tolist() != frame.feature_group_count.tolist():
        raise ValueError("Task 7.2 candidate identities differ.")
    for name in ["BIC", "training_log_likelihood", "design_rank_p", "ks_entropy_bits_per_transition",
                 "complete_code_cost_bits", *METRICS]:
        if not np.allclose(reference[name], frame[name], rtol=0, atol=1e-8):
            raise ValueError(f"Task 7.2 reference mismatch: {name}")
    frame = score_candidates(frame, n, m)
    for method, column in [("path", "BIC_plus_2_KS_path_cost"), ("mixture", "BIC_plus_2_mixture_code")]:
        if not np.allclose(frame[f"score_{method}"], reference[column], rtol=0, atol=1e-7):
            raise ValueError(f"Task 7.2 criterion mismatch: {method}")
    summary = selection_summary(frame)
    intervals, path, units = sensitivity(frame, n)
    draws, frequency = bootstrap_graphs(candidates, frame, n, m, bootstraps, seed)
    folds, fold_scores = chronological_comparison(saved["folds"], saved["manifests"])
    outputs = {
        "candidate_scores.csv": frame, "selection_comparison.csv": summary,
        "exact_multiplier_intervals.csv": intervals, "multiplier_selection_path.csv": path,
        "unit_and_scale_sensitivity.csv": units,
        "graph_bootstrap_selections.csv": draws, "graph_bootstrap_frequencies.csv": frequency,
        "chronological_selection_comparison.csv": folds, "chronological_candidate_scores.csv": fold_scores,
    }
    out = root / OUTPUT_DIRECTORY
    out.mkdir(exist_ok=True)
    for name, data in outputs.items():
        data.to_csv(out / name, index=False)
    figures(frame, summary, path, frequency, folds, out, show)
    if any(hashlib.sha256((root / name).read_bytes()).hexdigest() != digest for name, digest in hashes.items()):
        raise AssertionError("A source artifact changed during the analysis.")
    protocol = {
        "task": "7.4", "primary_formula": "BIC + (-2 * training_log_likelihood) * KS_bits_per_transition",
        "training_cases": n, "explanation_cases": m, "candidate_feature_counts": list(range(1, len(features) + 1)),
        "bootstraps": bootstraps, "seed": seed, "python": platform.python_version(),
        "input_sha256": hashes, "implementation_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "test_predictions_read": False, "models_retrained": False,
        "checks": ["Saved BIC equals D + p ln(n)", "Reconstructed feature logs equal saved graph counts and KS",
                   "Task 7.2 scores and validation metrics reproduced", "Inputs unchanged after execution"],
        "limits": [
            "Primary coefficient is one with entropy in bits; it is not estimated or claimed optimal.",
            "Minimum score wins; exact numeric ties use smaller k.",
            "Exact intervals describe open intervals between crossings; boundary ties use the stated rule.",
            "Graph bootstrap resamples 500 paired explanation cases with replacement, fixing models, feature order and training likelihood.",
            "No retraining or temporal-dependence uncertainty is included in the graph bootstrap.",
            "Chronological fits are reused; fold validation graphs enter the score, so this is not independent policy evaluation.",
            "Historical validation and test inspection preclude claiming pristine confirmatory evidence.",
            "The count-only control matches the full-feature product penalty and ignores intermediate DFGs.",
            "KS describes empirical first-order transition uncertainty, not predictive correctness or measured human interpretability.",
        ],
    }
    (out / "analysis_protocol.json").write_text(json.dumps(protocol, indent=2) + "\n", encoding="utf-8")
    chosen = summary.set_index("method").loc["product"]
    findings = (
        f"BIC selects k={int(chosen.BIC_choice_k)}; BIC + D h selects k={int(chosen.selected_k)}. "
        f"Validation accuracy difference: {chosen.accuracy_difference_percentage_points:+.6f} percentage points; "
        f"ROC AUC difference: {chosen.auc_difference:+.6f}; log-loss difference: {chosen.log_loss_difference:+.6f}. "
        "These describe a simplicity-performance tradeoff, not a proven improvement. "
        "Zero KS leaves the entire BIC intact in this formula."
    )
    (out / "findings.txt").write_text(findings + "\n", encoding="utf-8")
    if show:
        display(Markdown("**Task 7.4 findings.** " + findings))
        display(summary[["criterion", "selected_k", *METRICS, "accuracy_difference_percentage_points", "auc_difference", "log_loss_difference"]].round(6))
        display(frame[["feature_group_count", "BIC", "training_deviance", "parameter_penalty", "ks_entropy_bits_per_transition", "product_penalty", "score_product"]].round(6))
        display(intervals)
        display(units.round(6))
        display(frequency.pivot(index="criterion", columns="feature_group_count", values="selection_frequency").round(3))
        display(folds[["fold", "criterion", "selected_k", *METRICS]].round(6))
    return outputs
