"""Exploratory centrality additions to BIC on saved BPI nested candidates."""
from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path
import platform

import matplotlib.pyplot as plt
from matplotlib.ticker import PercentFormatter
import networkx as nx
import numpy as np
import pandas as pd
from IPython.display import Markdown, display

from bpi_task7_2_explanation_coding import load_saved_candidates, _save_figure

OUTPUT_DIRECTORY = "task7_5_centrality_outputs"
CENTRALITIES = {"closeness": "Outward closeness", "betweenness": "Betweenness",
               "eigenvector": "Undirected eigenvector"}
SAVED_COLUMNS = {"closeness": "mean_out_closeness", "betweenness": "mean_betweenness",
                 "eigenvector": "mean_undirected_eigenvector"}
METRICS = ("validation_accuracy", "validation_roc_auc", "validation_log_loss")
GRAPH_METRICS = ("open_dfg_nodes", "open_dfg_edges", "open_dfg_density", "ks_entropy_bits_per_transition")
COLORS = {"closeness": "#28688f", "betweenness": "#b05b32", "eigenvector": "#288068"}


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def node_centralities(graph):
    """Match the existing open_graph_measures centrality definitions exactly."""
    if not isinstance(graph, nx.DiGraph) or graph.is_multigraph() or len(graph) < 3:
        raise ValueError("Expected a simple directed ranking graph with boundary nodes.")
    graph = graph.copy()
    for u, v, data in graph.edges(data=True):
        weight = float(data.get("weight", np.nan))
        if not np.isfinite(weight) or weight <= 0 or u == v:
            raise ValueError("Every edge needs a positive finite frequency and distinct endpoints.")
    for source in graph:
        edges = list(graph.out_edges(source, data=True))
        total = sum(float(data["weight"]) for _, _, data in edges)
        for _, _, data in edges:
            probability = float(data["weight"]) / total
            data["inverse_probability_distance"] = 1.0 / max(probability, 1e-15)
    close = nx.closeness_centrality(graph.reverse(copy=False), distance="inverse_probability_distance")
    between = nx.betweenness_centrality(graph, weight="inverse_probability_distance", normalized=True)
    undirected = nx.Graph()
    undirected.add_nodes_from(graph)
    for u, v, data in graph.edges(data=True):
        existing = undirected.get_edge_data(u, v, {}).get("weight", 0.0)
        undirected.add_edge(u, v, weight=existing + float(data["weight"]))
    eigen = nx.eigenvector_centrality(undirected, weight="weight", max_iter=5000)
    values = pd.DataFrame({"node": list(graph), "closeness": [close[u] for u in graph],
                           "betweenness": [between[u] for u in graph],
                           "eigenvector": [eigen[u] for u in graph]})
    if not np.isfinite(values[list(CENTRALITIES)]).all().all():
        raise ValueError("Centrality computation produced nonfinite values.")
    return values


def score_candidates(frame, training_cases):
    """Return six scores per aggregation; no tuning or cross-candidate rescaling."""
    frame = frame.sort_values("feature_group_count").reset_index(drop=True)
    if frame.feature_group_count.tolist() != list(range(1, len(frame) + 1)):
        raise ValueError("Need a complete nested feature-count path.")
    if training_cases < 2:
        raise ValueError("Need at least two training cases.")
    deviance = -2 * frame.training_log_likelihood.to_numpy(float)
    parameter_penalty = frame.design_rank_p.to_numpy(float) * math.log(training_cases)
    if (not np.isfinite(deviance).all() or np.any(deviance < 0)
            or not np.allclose(frame.BIC, deviance + parameter_penalty, rtol=0, atol=1e-7)
            or not np.allclose(frame.AIC, deviance + 2 * frame.design_rank_p, rtol=0, atol=1e-7)):
        raise ValueError("Saved AIC/BIC do not match training likelihood and parameter count.")
    rows = []
    for aggregation in ("feature_nodes", "all_nodes"):
        for measure in CENTRALITIES:
            values = frame[f"{aggregation}_{measure}"].to_numpy(float)
            if not np.isfinite(values).all() or np.any(values < 0):
                raise ValueError("Centrality values must be finite and nonnegative.")
            for weighting in ("unit", "deviance"):
                weights = np.ones(len(frame)) if weighting == "unit" else deviance
                scores = frame.BIC.to_numpy() + weights * values
                for index, model in frame.iterrows():
                    rows.append({
                        "feature_group_count": int(model.feature_group_count),
                        "included_feature_groups": model.included_feature_groups,
                        "aggregation": aggregation, "centrality": measure, "weighting": weighting,
                        "parameter_count_k": int(model.design_rank_p), "BIC": model.BIC,
                        "training_deviance_D": deviance[index], "centrality_value": values[index],
                        "weight_d": weights[index], "added_penalty": weights[index] * values[index],
                        "score": scores[index], "delta_score": scores[index] - scores.min(),
                        **{metric: model[metric] for metric in METRICS},
                    })
    return pd.DataFrame(rows)


def selection_summary(scores, frame):
    baseline = frame.sort_values("feature_group_count").iloc[np.argmin(frame.sort_values("feature_group_count").BIC)]
    rows = []
    for aggregation in ("feature_nodes", "all_nodes"):
        subset = scores[scores.aggregation.eq(aggregation)]
        choices = [("BIC", "none", "none", baseline, float(baseline.BIC), 0.0)]
        for (measure, weighting), group in subset.groupby(["centrality", "weighting"], sort=False):
            chosen = group.sort_values("feature_group_count").sort_values("score", kind="stable").iloc[0]
            weight_name = "d=1" if weighting == "unit" else "d=D"
            label = f"{CENTRALITIES[measure]}, {weight_name}"
            choices.append((label, measure, weighting, chosen, chosen.score, chosen.added_penalty))
        for label, measure, weighting, chosen, score, penalty in choices:
            model = frame.loc[frame.feature_group_count.eq(chosen.feature_group_count)].iloc[0]
            rows.append({"aggregation": aggregation, "criterion": label, "centrality": measure,
                         "weighting": weighting, "selected_g": int(chosen.feature_group_count),
                         "included_feature_groups": chosen.included_feature_groups,
                         "selected_score": score, "added_penalty": penalty,
                         "BIC_selected_g": int(baseline.feature_group_count),
                         **{metric: chosen[metric] for metric in METRICS},
                         **{metric: model[metric] for metric in GRAPH_METRICS},
                         "accuracy_difference_percentage_points": 100 * (chosen.validation_accuracy - baseline.validation_accuracy),
                         "auc_difference": chosen.validation_roc_auc - baseline.validation_roc_auc,
                         "log_loss_difference": chosen.validation_log_loss - baseline.validation_log_loss})
    return pd.DataFrame(rows)


def make_figures(frame, scores, summary, out, show):
    g = frame.feature_group_count.to_numpy()
    primary = scores[scores.aggregation.eq("feature_nodes")]
    selected = summary[summary.aggregation.eq("feature_nodes")].reset_index(drop=True)
    with plt.rc_context({"font.size": 10, "axes.spines.top": False, "axes.spines.right": False}):
        fig, axes = plt.subplots(1, 3, figsize=(14, 4.6), constrained_layout=True)
        for ax, (measure, title) in zip(axes, CENTRALITIES.items()):
            ax.plot(g, frame[f"feature_nodes_{measure}"], "o-", color=COLORS[measure], label="Feature-node mean (primary)")
            ax.plot(g, frame[f"all_nodes_{measure}"], "s--", color="#707070", label="All-node mean (sensitivity)")
            for x, y in zip(g, frame[f"feature_nodes_{measure}"]):
                ax.annotate(f"{y:.3f}", (x, y), xytext=(0, 9), textcoords="offset points", ha="center", fontsize=8)
            ax.set(title=title, xlabel="Feature groups (g)", ylabel="Mean centrality", xticks=g)
            ax.margins(y=.2)
            ax.legend(fontsize=8)
            ax.grid(alpha=.2)
        fig.suptitle("Task 7.5: centrality values are structural proxies, not validated comprehension costs", fontsize=13)
        _save_figure(fig, out / "centrality_by_feature_count.png", show)

        fig, axes = plt.subplots(2, 3, figsize=(14, 8), constrained_layout=True)
        bic_delta = frame.BIC - frame.BIC.min()
        for row, weighting in enumerate(("unit", "deviance")):
            for col, (measure, title) in enumerate(CENTRALITIES.items()):
                group = primary[primary.centrality.eq(measure) & primary.weighting.eq(weighting)]
                chosen = int(group.loc[group.score.idxmin(), "feature_group_count"])
                ax = axes[row, col]
                ax.plot(g, bic_delta, "o--", color="#777777", markerfacecolor="white", markersize=8, label="BIC difference")
                ax.plot(g, group.delta_score, "D-", color=COLORS[measure], markersize=4, label="Augmented-score difference")
                ax.axvline(chosen, color=COLORS[measure], linestyle=":", alpha=.6)
                weight_label = "1" if weighting == "unit" else "D"
                ax.set(title=f"{title}: d = {weight_label}\nSelected g = {chosen}",
                       xlabel="Feature groups (g)", ylabel="Score minus its own minimum", xticks=g)
                ax.legend(fontsize=8)
                ax.grid(alpha=.2)
        fig.suptitle("Six candidate criteria; near-overlap with BIC is expected when d = 1", fontsize=13)
        _save_figure(fig, out / "six_criterion_comparison.png", show)

        fig, axes = plt.subplots(2, 3, figsize=(14, 7.5), constrained_layout=True)
        for row, weighting in enumerate(("unit", "deviance")):
            for col, (measure, title) in enumerate(CENTRALITIES.items()):
                ax = axes[row, col]
                group = primary[primary.centrality.eq(measure) & primary.weighting.eq(weighting)]
                ax.plot(g, group.added_penalty, "o-", color=COLORS[measure])
                for x, y in zip(g, group.added_penalty):
                    ax.annotate(f"{y:.3f}" if weighting == "unit" else f"{y:,.0f}", (x, y),
                                xytext=(0, 8), textcoords="offset points", ha="center", fontsize=8)
                ax.set(title=f"{title}: d = {'1' if weighting == 'unit' else 'D'}",
                       xlabel="Feature groups (g)", ylabel="Additional penalty d C", xticks=g)
                ax.margins(y=.25)
                ax.grid(alpha=.2)
        fig.suptitle("Additional penalties on separate vertical scales; no min-max rescaling", fontsize=13)
        _save_figure(fig, out / "penalty_magnitudes.png", show)

        fig, axes = plt.subplots(1, 3, figsize=(15, 5.5), constrained_layout=True)
        y = np.arange(len(selected))
        labels = [f"{row.criterion} (g={row.selected_g})" for row in selected.itertuples()]
        for ax, metric, title in zip(axes, METRICS, ("Validation accuracy", "Validation ROC AUC", "Validation log loss")):
            for index, record in selected.iterrows():
                color = COLORS.get(record.centrality, "#555555")
                ax.scatter(record[metric], index, color=color, marker="s" if record.weighting == "deviance" else "o", s=42)
                value = f"{record[metric]:.3%}" if metric.endswith("accuracy") else f"{record[metric]:.4f}"
                ax.annotate(value, (record[metric], index), xytext=(7, 0), textcoords="offset points", va="center", fontsize=9)
            ax.axvline(selected.iloc[0][metric], color="#777777", linestyle="--", alpha=.6)
            ax.set(title=title, yticks=y, yticklabels=labels if metric == METRICS[0] else [""] * len(y))
            ax.invert_yaxis()
            spread = max(float(selected[metric].max() - selected[metric].min()), .005)
            ax.set_xlim(float(selected[metric].min()) - .2 * spread, float(selected[metric].max()) + .65 * spread)
            if metric.endswith("accuracy"):
                ax.xaxis.set_major_formatter(PercentFormatter(1, decimals=1))
            ax.grid(axis="x", alpha=.2)
        fig.suptitle("Observed validation consequences of each selected model; not independent policy validation", fontsize=13)
        _save_figure(fig, out / "selected_validation_performance.png", show)


def run_task7_5(root=".", show=True):
    root = Path(root).resolve()
    candidates, features, cases, hashes = load_saved_candidates(root)
    partition_path = root / "study_protocol_partitions.csv"
    hashes[partition_path.name] = sha256(partition_path)
    n = int(pd.read_csv(partition_path).set_index("partition").loc["train", "cases"])
    frame = pd.DataFrame([candidate["model"] for candidate in candidates])
    node_tables = []
    for index, candidate in enumerate(candidates):
        g = candidate["k"]
        path = root / f"task3_outputs/feature_count_{g:02d}_feature_only_open_dfg.graphml"
        graph = nx.read_graphml(path)
        hashes[str(path.relative_to(root))] = sha256(path)
        counts = candidate["counts"].copy()
        counts[-1, 0] = 0
        labels = candidate["labels"]
        expected = {(labels[u], labels[v]): float(counts[u, v]) for u, v in zip(*np.nonzero(counts))}
        actual = {(u, v): float(data["weight"]) for u, v, data in graph.edges(data=True)}
        if set(graph) != set(labels) or actual != expected:
            raise ValueError(f"Open graph disagrees with saved feature logs at g={g}.")
        values = node_centralities(graph)
        values.insert(0, "feature_group_count", g)
        values["node_type"] = np.where(values.node.isin(labels[1:-1]), "feature", "boundary")
        values["feature_group"] = values.node.map(dict(zip(labels[1:-1], features[:g])))
        node_tables.append(values)
        feature_values = values[values.node_type.eq("feature")]
        if len(feature_values) != g:
            raise ValueError("Feature-node identities do not match the nested model.")
        for measure in CENTRALITIES:
            all_mean = float(values[measure].mean())
            if not np.isclose(all_mean, frame.loc[index, SAVED_COLUMNS[measure]], atol=1e-8, rtol=0):
                raise ValueError(f"Centrality disagrees with Task 3: {measure}, g={g}.")
            frame.loc[index, f"all_nodes_{measure}"] = all_mean
            frame.loc[index, f"feature_nodes_{measure}"] = float(feature_values[measure].mean())
    scores = score_candidates(frame, n)
    summary = selection_summary(scores, frame)
    sensitivity = summary.pivot(index=["centrality", "weighting"], columns="aggregation", values="selected_g").reset_index()
    sensitivity["same_selection"] = sensitivity.feature_nodes.eq(sensitivity.all_nodes)
    outputs = {"candidate_centralities.csv": frame, "node_centralities.csv": pd.concat(node_tables, ignore_index=True),
               "candidate_scores.csv": scores, "selection_comparison.csv": summary,
               "aggregation_sensitivity.csv": sensitivity}
    out = root / OUTPUT_DIRECTORY
    out.mkdir(exist_ok=True)
    for name, table in outputs.items():
        table.to_csv(out / name, index=False)
    make_figures(frame, scores, summary, out, show)
    if any(sha256(root / name) != digest for name, digest in hashes.items()):
        raise AssertionError("An existing source artifact changed during execution.")
    primary = summary[summary.aggregation.eq("feature_nodes")]
    finding = "; ".join(f"{row.criterion}: g={row.selected_g}" for row in primary.itertuples())
    finding += (
        ". Lower centrality can favour more feature groups, not fewer. "
        "The selected-graph table reports size, density, and restart-closed KS as descriptive checks; "
        "these checks do not enter the six scores. These are centrality-based selections, "
        "not validated rankings of graph understandability."
    )
    (out / "findings.txt").write_text(finding + "\n", encoding="utf-8")
    protocol = {
        "task": "7.5", "dataset": "BPI 2017", "training_cases": n, "explanation_cases": len(cases),
        "AIC": "2k - 2 ln(L_hat)", "BIC": "k ln(n) - 2 ln(L_hat)",
        "criterion": "BIC_g + d_g * C_g", "weights": ["1", "-2 ln(L_hat_g)"],
        "primary_aggregation": "Mean over feature nodes; START/END remain in graph calculations",
        "sensitivity_aggregation": "Mean over all nodes, matching existing Task 3 centrality columns",
        "graphs": "Feature-only open START-to-END weighted DFGs; no END-to-START restart edge",
        "distance": "1 / max(outgoing transition probability, 1e-15)",
        "closeness": "Directed outward, NetworkX reachable-fraction correction enabled",
        "betweenness": "Directed, normalized, all source-target pairs, endpoints excluded",
        "eigenvector": "Undirected reciprocal-frequency sum, Euclidean norm 1, NetworkX tol 1e-6, max_iter 5000",
        "selection": "Minimum score; exact numeric ties use smaller g; no score tuning",
        "models_retrained": False, "test_predictions_read": False, "new_bootstraps": False,
        "python": platform.python_version(), "networkx": nx.__version__,
        "input_sha256": hashes,
        "implementation_sha256": {name: sha256(Path(__file__).with_name(name)) for name in
                                  (Path(__file__).name, "bpi_task7_2_explanation_coding.py")},
        "checks": ["Every saved open graph equals the feature-log reconstruction",
                   "All-node centrality averages reproduce Task 3",
                   "AIC/BIC reproduce training likelihood and design rank", "Inputs remain unchanged"],
        "limits": ["Exploratory penalized scores, not derived Bayesian information criteria",
                   "Higher centrality need not mean greater complexity or worse human comprehension",
                   "Eigenvector centrality loses direction and its mean depends on graph size and normalization",
                   "Feature-only averaging does not remove all size dependence",
                   "Inverse-probability shortest paths are not observed path counts or maximum-probability paths",
                   "No human comprehension evaluation, retraining, uncertainty estimation, or untouched-test claim",
                   "Graph selection uses existing validation explanation cases; performance is descriptive"],
    }
    (out / "analysis_protocol.json").write_text(json.dumps(protocol, indent=2) + "\n", encoding="utf-8")
    if show:
        display(Markdown("**Task 7.5 findings.** " + finding))
        tables = [
            ("Primary selections and validation consequences", "selection_comparison.csv",
             primary[["criterion", "selected_g", *METRICS, "accuracy_difference_percentage_points", "auc_difference", "log_loss_difference"]].round(6)),
            ("Mean centralities", "candidate_centralities.csv",
             frame[["feature_group_count", *[f"{scope}_{measure}" for measure in CENTRALITIES for scope in ("feature_nodes", "all_nodes")]]].round(6)),
            ("Six criteria: complete score breakdown", "candidate_scores.csv",
             scores[scores.aggregation.eq("feature_nodes")][["feature_group_count", "centrality", "weighting", "BIC", "weight_d", "centrality_value", "added_penalty", "score", "delta_score"]].round(6)),
            ("Boundary-node sensitivity: selected feature counts", "aggregation_sensitivity.csv", sensitivity),
            ("Selected DFG profiles: KS is from the corresponding restart-closed graph", "selection_comparison.csv",
             primary[["criterion", "selected_g", *GRAPH_METRICS]].round(6)),
        ]
        for title, name, table in tables:
            display(Markdown(f"**{title}.** [Download CSV]({OUTPUT_DIRECTORY}/{name})"))
            with pd.option_context("display.max_rows", 100, "display.max_columns", 20):
                display(table)
    return outputs
