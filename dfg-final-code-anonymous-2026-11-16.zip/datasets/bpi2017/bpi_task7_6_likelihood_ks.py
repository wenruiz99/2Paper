"""Training-only calibration of negative log likelihood plus lambda times KS."""
from __future__ import annotations

from dataclasses import replace
import hashlib
import json
import math
from pathlib import Path
import platform

import matplotlib.pyplot as plt
from matplotlib.ticker import PercentFormatter
import numpy as np
import pandas as pd
from IPython.display import Markdown, display

from bpi_task7_3_validation import (
    load_development, temporal_splits, ExplicitSplitStudy, _fit_checked,
    counts_from_artifact, cycle_entropy, probability_metrics,
)
from bpi_task7_2_explanation_coding import _save_figure
from multidataset_dfg_extensions import _exact_lower_envelope

OUTPUT_DIRECTORY = "task7_6_likelihood_ks_outputs"
FIT_VERSION = "training-only-ks-chronological-v1"
METRICS = ("accuracy", "roc_auc", "log_loss")


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def objective(log_likelihood, entropy, weight):
    likelihood, h = np.asarray(log_likelihood, float), np.asarray(entropy, float)
    if likelihood.shape != h.shape or not np.isfinite(likelihood).all() or not np.isfinite(h).all():
        raise ValueError("Aligned finite log likelihood and KS values are required.")
    if np.any(likelihood > 1e-9) or np.any(h < 0) or not np.isfinite(weight) or weight < 0:
        raise ValueError("Binary log likelihood must be nonpositive; KS and lambda nonnegative.")
    return -likelihood + weight * h


def select_count(frame, alpha):
    ordered = frame.sort_values("feature_group_count")
    sizes = ordered.training_cases.unique()
    if len(sizes) != 1 or sizes[0] <= 0:
        raise ValueError("Candidates must share a positive training cohort size.")
    scores = objective(ordered.training_log_likelihood, ordered.ks_bits, float(sizes[0]) * alpha)
    return ordered.iloc[int(np.argmin(scores))]


def envelope(frame):
    ordered = frame.sort_values("feature_group_count")
    return _exact_lower_envelope(
        -ordered.training_log_likelihood.to_numpy() / ordered.training_cases.to_numpy(),
        ordered.ks_bits.to_numpy(), ordered.feature_group_count.to_numpy(),
    ).rename(columns={"lambda_lower": "alpha_lower", "lambda_upper": "alpha_upper"})


def calibrate(folds):
    """Evaluate all constant-selection intervals, using only inner-fold outcomes."""
    if folds.fold.nunique() < 2 or folds.duplicated(["fold", "feature_group_count"]).any():
        raise ValueError("At least two folds with unique candidates are required.")
    boundaries = {0.0}
    for _, group in folds.groupby("fold"):
        if group.feature_group_count.sort_values().tolist() != list(range(1, len(group) + 1)):
            raise ValueError("Every fold needs the complete feature-count path.")
        if not np.isfinite(group.validation_log_loss).all():
            raise ValueError("Validation log losses must be finite.")
        segments = envelope(group)
        boundaries.update(float(x) for x in segments.alpha_lower if x > 0)
    bounds = sorted(boundaries)
    policies = [(0.0, 0.0, 0.0, "zero")]
    for i, lower in enumerate(bounds):
        upper = bounds[i + 1] if i + 1 < len(bounds) else np.inf
        representative = (lower + upper) / 2 if np.isfinite(upper) else (2 * lower if lower > 0 else 1.0)
        policies.append((lower, upper, representative, "open_interval"))
    rows, selections = [], []
    for policy_id, (lower, upper, alpha, kind) in enumerate(policies):
        chosen = [select_count(group, alpha) for _, group in folds.groupby("fold", sort=True)]
        losses = np.asarray([row.validation_log_loss for row in chosen])
        rows.append({"policy_id": policy_id, "interval_kind": kind, "alpha_lower": lower,
                     "alpha_upper": upper, "alpha": alpha, "mean_log_loss": losses.mean(),
                     "log_loss_se": losses.std(ddof=1) / math.sqrt(len(losses)),
                     "mean_ks_bits": np.mean([row.ks_bits for row in chosen]),
                     "mean_feature_groups": np.mean([row.feature_group_count for row in chosen]),
                     "fold_selected_groups": " | ".join(str(int(row.feature_group_count)) for row in chosen)})
        selections.extend({"policy_id": policy_id, "alpha": alpha, "fold": int(row.fold),
                           "selected_g": int(row.feature_group_count), "training_cases": int(row.training_cases),
                           "lambda_fold": alpha * row.training_cases, "ks_bits": row.ks_bits,
                           **{f"validation_{m}": row[f"validation_{m}"] for m in METRICS}} for row in chosen)
    table = pd.DataFrame(rows)
    best = table.sort_values(["mean_log_loss", "mean_ks_bits", "mean_feature_groups", "alpha"], kind="stable").iloc[0]
    threshold = float(best.mean_log_loss + best.log_loss_se)
    table["within_one_se"] = table.mean_log_loss.le(threshold + 1e-12)
    primary = table[table.within_one_se].sort_values(
        ["mean_ks_bits", "mean_feature_groups", "mean_log_loss", "alpha"], kind="stable").iloc[0]
    table["minimum_loss_choice"] = table.policy_id.eq(best.policy_id)
    table["one_se_ks_choice"] = table.policy_id.eq(primary.policy_id)
    fold_table = pd.DataFrame(selections)
    losses = fold_table.pivot(index="policy_id", columns="fold", values="validation_log_loss")
    differences = losses.subtract(losses.loc[int(best.policy_id)], axis="columns")
    table["mean_excess_loss_vs_best"] = table.policy_id.map(differences.mean(axis=1))
    table["paired_excess_loss_se"] = table.policy_id.map(differences.std(axis=1, ddof=1) / math.sqrt(folds.fold.nunique()))
    choice = {"minimum_loss_policy_id": int(best.policy_id), "one_se_policy_id": int(primary.policy_id),
              "minimum_loss_alpha": float(best.alpha), "one_se_alpha": float(primary.alpha),
              "one_se_threshold": threshold, "best_mean_log_loss": float(best.mean_log_loss),
              "best_log_loss_se": float(best.log_loss_se)}
    return table, fold_table, choice


def fit_path(train, assessment, config, directory, seed, fold):
    """Fit preprocessing, ordering and explanation graphs exclusively on train."""
    directory.mkdir(parents=True, exist_ok=True)
    cfg = replace(config, random_state=seed)
    study = ExplicitSplitStudy(train, train, cfg)
    full, _ = _fit_checked(study, cfg.features, tolerance=1e-8)
    shap = study._linear_grouped_shap(full["model"], full["indices"],
                                     study.X_train[study.ranking_indices], study.X_train[study.background_indices])
    importance = np.abs(shap).mean(axis=0)
    order = sorted(cfg.features, key=lambda f: (-importance[cfg.features.index(f)], cfg.features.index(f)))
    pd.DataFrame({"feature_rank": range(1, len(order) + 1), "feature_group": order,
                  "training_mean_absolute_grouped_shap": [importance[cfg.features.index(f)] for f in order]}).to_csv(
                      directory / "feature_order.csv", index=False)
    assessed_X = np.asarray(study.preprocessor.transform(assessment[cfg.features]), float)
    y = assessment[cfg.target_column].to_numpy(int)
    prediction = assessment[[cfg.case_id_column, cfg.time_column, cfg.target_column]].reset_index(drop=True).copy()
    pd.DataFrame({"CaseID": study.probe_case_ids}).to_csv(directory / "training_explanation_case_ids.csv", index=False)
    rows, previous = [], -np.inf
    for g in range(1, len(order) + 1):
        artifact, warnings = _fit_checked(study, order[:g], tolerance=1e-8)
        ll = artifact["training_log_likelihood"]
        if ll < previous - 1e-4:
            raise RuntimeError("Nested training likelihood decreased beyond numerical tolerance.")
        previous = ll
        counts = counts_from_artifact(artifact, order[:g], study.probe_case_ids)
        h = cycle_entropy(counts.sum(axis=0)) / (g + 2)
        probabilities = artifact["model"].predict_proba(assessed_X[:, artifact["indices"]])[:, 1]
        metrics = probability_metrics(y, probabilities)
        prediction[f"accepted_probability_g_{g}"] = probabilities
        artifact["feature_log"].to_csv(directory / f"feature_count_{g:02d}_training_feature_log.csv", index=False)
        study._write_graph(artifact["analysis_closed_graph"], directory / f"feature_count_{g:02d}_closed_dfg.graphml")
        rows.append({"fold": fold, "feature_group_count": g, "included_feature_groups": " | ".join(order[:g]),
                     "training_cases": len(train), "assessment_cases": len(assessment), "training_log_likelihood": ll,
                     "mean_training_nll": -ll / len(train), "ks_bits": h,
                     "parameter_count_k": artifact["design_rank_p"], "explanation_cases": len(counts),
                     "open_dfg_nodes": artifact["analysis_graph"].number_of_nodes(),
                     "open_dfg_edges": artifact["analysis_graph"].number_of_edges(),
                     "solver_tolerance": 1e-8, "solver_iterations": int(artifact["model"].n_iter_[0]),
                     "fit_warnings": " | ".join(warnings),
                     **{f"validation_{m}": float(metrics[m][0]) for m in METRICS}})
    prediction.to_csv(directory / "assessment_probabilities.csv", index=False)
    result = pd.DataFrame(rows)
    result.to_csv(directory / "candidate_results.csv", index=False)
    return result


def cached_fit(key, directory, compute):
    manifest = directory / "fit_cache.json"
    if manifest.exists():
        saved = json.loads(manifest.read_text())
        if saved["key"] == key and all((directory / name).exists() and sha256(directory / name) == digest
                                       for name, digest in saved["files"].items()):
            print(f"Reusing verified fits: {directory.name}", flush=True)
            return pd.read_csv(directory / "candidate_results.csv")
        raise ValueError(f"Changed cached fit inputs/outputs in {directory}; inspect before refitting.")
    result = compute()
    files = {str(p.relative_to(directory)): sha256(p) for p in directory.iterdir() if p.is_file()}
    manifest.write_text(json.dumps({"key": key, "files": files}, indent=2), encoding="utf-8")
    return result


def plot_results(calibration, folds, final, choices, selected, out, show):
    n = int(final.training_cases.iloc[0])
    x = calibration.alpha.to_numpy() * n
    chosen_lambda = choices["one_se_alpha"] * n
    best_lambda = choices["minimum_loss_alpha"] * n
    colors = {"minimum": "#28688f", "one_se": "#288068"}
    with plt.rc_context({"font.size": 10, "axes.spines.top": False, "axes.spines.right": False}):
        fig, axes = plt.subplots(1, 2, figsize=(13, 4.8), constrained_layout=True)
        axes[0].errorbar(x, calibration.mean_log_loss, yerr=calibration.log_loss_se, fmt="o-", color="#444444", capsize=3)
        axes[0].axhline(choices["one_se_threshold"], color="#b36732", linestyle=":", label="Minimum mean + its fold SE")
        axes[0].set(title="Inner chronological validation log loss", ylabel="Mean log loss with fold SE")
        axes[1].plot(x, calibration.mean_ks_bits, "o-", color="#555555")
        axes[1].set(title="KS of the models selected inside each fold", ylabel="Mean training-graph KS (bits/transition)")
        for ax in axes:
            ax.axvline(best_lambda, color=colors["minimum"], linestyle="--", label=f"Minimum loss: lambda={best_lambda:.3g}")
            ax.axvline(chosen_lambda, color=colors["one_se"], linestyle=":", label=f"One-SE KS: lambda={chosen_lambda:.3g}")
            ax.set_xscale("symlog", linthresh=.01)
            ax.set_xlim(0, max(1.0, float(x.max()) * 1.4))
            ax.set_xlabel("Lambda on final-training-size scale (n_final * alpha)")
            ax.legend(fontsize=8)
            ax.grid(alpha=.2)
        fig.suptitle("Task 7.6: calibrating the weight inside training; SE is a heuristic with dependent time folds", fontsize=12)
        _save_figure(fig, out / "lambda_calibration.png", show)

        fig, ax = plt.subplots(figsize=(11, 5), constrained_layout=True)
        xmax = max(float(x.max()), chosen_lambda * 1.5, 1)
        for fold, group in folds.groupby("fold"):
            env = envelope(group)
            xx = np.r_[env.alpha_lower.to_numpy() * n, xmax]
            yy = np.r_[env.selected_feature_group_count, env.selected_feature_group_count.iloc[-1]]
            ax.step(xx, yy, where="post", linestyle="--", alpha=.65, label=f"Inner fold {int(fold)}")
        env = envelope(final)
        ax.step(np.r_[env.alpha_lower.to_numpy() * n, max(xmax, env.alpha_lower.max() * n * 1.1)],
                np.r_[env.selected_feature_group_count, env.selected_feature_group_count.iloc[-1]],
                where="post", color="#222222", linewidth=2.5, label="Final training fit")
        ax.axvline(chosen_lambda, color=colors["one_se"], linestyle=":", label="Calibrated one-SE weight")
        ax.set(xscale="symlog", xlabel="Lambda on final-training-size scale", ylabel="Selected feature groups (g)",
               yticks=range(1, 8), title="Exact selection intervals; boundary ties choose the smaller g")
        ax.set_xscale("symlog", linthresh=.01)
        ax.set_xlim(0, max(xmax, float(env.alpha_lower.max()) * n) * 1.2)
        ax.legend(fontsize=9, ncols=2)
        ax.grid(alpha=.2)
        _save_figure(fig, out / "feature_count_selection_path.png", show)

        fig, axes = plt.subplots(2, 2, figsize=(12, 8), constrained_layout=True)
        g = final.feature_group_count
        nll = -final.training_log_likelihood
        penalty = chosen_lambda * final.ks_bits
        for ax, values, title, ylabel in zip(axes.flat[:3], [nll, final.ks_bits, penalty],
                ["Training negative log likelihood", "Training explanation-graph KS", "KS penalty at calibrated one-SE lambda"],
                ["-ln(fitted likelihood)", "Bits per transition", "lambda * KS"]):
            ax.plot(g, values, "o-", color="#28688f")
            for a, b in zip(g, values):
                ax.annotate(f"{b:.3f}" if "KS" in title and "penalty" not in title else f"{b:,.1f}",
                            (a, b), xytext=(0, 9), textcoords="offset points", ha="center", fontsize=8)
            ax.set(title=title, ylabel=ylabel)
            ax.margins(y=.25)
        for label, weight, color, style in [("lambda=0", 0, "#777777", "--"),
                ("Minimum-loss weight", best_lambda, colors["minimum"], "-"),
                ("One-SE KS weight", chosen_lambda, colors["one_se"], ":")]:
            values = objective(final.training_log_likelihood, final.ks_bits, weight)
            axes[1, 1].plot(g, values - values.min(), "o", linestyle=style, color=color, label=label)
        axes[1, 1].set(title="New objective relative to its own minimum", ylabel="Score difference")
        axes[1, 1].legend(fontsize=8)
        for ax in axes.flat:
            ax.set(xlabel="Feature groups (g)", xticks=g)
            ax.grid(alpha=.2)
        fig.suptitle("No BIC, parameter-count penalty, or factor of two in the new objective", fontsize=13)
        _save_figure(fig, out / "objective_components.png", show)

        fig, axes = plt.subplots(1, 3, figsize=(14, 4.8), constrained_layout=True)
        primary_g = int(selected.loc[selected.rule.eq("One-SE KS preference"), "selected_g"].iloc[0])
        for ax, metric, title in zip(axes, METRICS, ("Outer validation accuracy", "Outer validation ROC AUC", "Outer validation log loss")):
            ax.plot(final.ks_bits, final[f"validation_{metric}"], "o-", color="#777777")
            for row in final.itertuples():
                offsets = {5: (-22, 20), 6: (8, 8), 7: (-8, -22)}
                ax.annotate(f"g={row.feature_group_count}", (row.ks_bits, getattr(row, f"validation_{metric}")),
                            xytext=offsets.get(row.feature_group_count, (5, 7)),
                            textcoords="offset points", fontsize=8)
            row = final[final.feature_group_count.eq(primary_g)].iloc[0]
            ax.scatter([row.ks_bits], [row[f"validation_{metric}"]], s=130, facecolors="none",
                       edgecolors=colors["one_se"], linewidths=2, label=f"One-SE choice: g={primary_g}")
            ax.set(title=title, xlabel="Training-graph KS (bits per transition)")
            if metric == "accuracy":
                ax.yaxis.set_major_formatter(PercentFormatter(1, decimals=1))
            ax.margins(x=.2, y=.2)
            ax.set_xlim(-.04, float(final.ks_bits.max()) * 1.2)
            ax.legend(fontsize=8)
            ax.grid(alpha=.2)
        fig.suptitle("Outer validation evaluated after weight calibration; legacy inspection still limits confirmation", fontsize=12)
        _save_figure(fig, out / "validation_complexity_tradeoff.png", show)


def run_task7_6(root=".", show=True, seed=76031, inner_folds=4):
    root = Path(root).resolve()
    out = root / OUTPUT_DIRECTORY
    out.mkdir(exist_ok=True)
    input_names = ["canonical_after_first_offer_final_application_outcome.csv", "study_protocol_configuration.csv",
                   "study_protocol_partitions.csv", "study_cohort_membership.csv", "study_cohort_contract.json"]
    hashes = {name: sha256(root / name) for name in input_names}
    implementation_names = ["bpi_task7_3_validation.py", "bpi_task7_2_explanation_coding.py", "multidataset_dfg_study.py"]
    fit_key = {"version": FIT_VERSION, "seed": seed, "inner_folds": inner_folds, "input_sha256": hashes,
               "fit_dependencies": {name: sha256(root / name) for name in implementation_names}}
    _, original_train, validation, config, _ = load_development(root)
    boundary = validation[config.time_column].min()
    eligible = original_train[original_train.outcome_time.lt(boundary)].copy()
    purged_final = original_train[~original_train.outcome_time.lt(boundary)].copy()
    n = len(eligible)
    memberships, manifests, results, category_rows = [], [], [], []
    splits = temporal_splits(eligible, config.time_column, boundary, folds=inner_folds)
    for fold, (train, heldout, purged, start, end) in enumerate(splits, 1):
        print(f"Task 7.6 inner fold {fold}/{inner_folds}: train={len(train)}, validation={len(heldout)}", flush=True)
        directory = out / f"inner_fold_{fold}"
        key = {**fit_key, "fold": fold}
        result = cached_fit(key, directory, lambda: fit_path(train, heldout, config, directory, seed + fold, fold))
        for feature in config.categorical_features:
            unknown = heldout[feature].notna() & ~heldout[feature].astype(str).isin(train[feature].dropna().astype(str))
            category_rows.append({"partition": f"inner_fold_{fold}", "feature_group": feature,
                                  "assessment_cases": len(heldout), "unseen_category_cases": int(unknown.sum())})
        results.append(result)
        manifests.append({"fold": fold, "training_cases": len(train), "validation_cases": len(heldout),
                          "purged_unavailable_labels": len(purged), "validation_start": start,
                          "validation_end_exclusive": end, "latest_training_outcome": train.outcome_time.max(),
                          "all_training_labels_known": bool(train.outcome_time.max() < start),
                          "all_inner_cases_within_original_training": bool(set(train.CaseID) | set(heldout.CaseID) <= set(original_train.CaseID)),
                          "outer_validation_cases_used": False, "test_cases_used": False})
        for role, data in (("train", train), ("inner_validation", heldout), ("purged", purged)):
            members = data[["CaseID", config.time_column, "outcome_time"]].copy()
            members.insert(0, "role", role)
            members.insert(0, "fold", fold)
            memberships.append(members)
    folds = pd.concat(results, ignore_index=True)
    manifest = pd.DataFrame(manifests)
    calibration, fold_choices, choices = calibrate(folds)
    calibration["lambda_final_scale"] = calibration.alpha * n
    calibration["lambda_lower_final_scale"] = calibration.alpha_lower * n
    calibration["lambda_upper_final_scale"] = calibration.alpha_upper * n
    # Lock preference weights before any outer-validation model prediction is calculated.
    lock = {**choices, "final_training_cases": n, "lambda_minimum_loss": n * choices["minimum_loss_alpha"],
            "lambda_one_se": n * choices["one_se_alpha"], "outer_validation_used_for_calibration": False,
            "calibration_data_sha256": hashlib.sha256(folds.to_csv(index=False).encode()).hexdigest()}
    (out / "lambda_selection_locked.json").write_text(json.dumps(lock, indent=2), encoding="utf-8")
    print(f"Weights locked: minimum-loss lambda={lock['lambda_minimum_loss']:.6g}, one-SE lambda={lock['lambda_one_se']:.6g}", flush=True)
    final_dir = out / "final_training"
    final = cached_fit({**fit_key, "fold": "final"}, final_dir,
                       lambda: fit_path(eligible, validation, config, final_dir, seed, 0))
    for feature in config.categorical_features:
        unknown = validation[feature].notna() & ~validation[feature].astype(str).isin(eligible[feature].dropna().astype(str))
        category_rows.append({"partition": "outer_validation", "feature_group": feature,
                              "assessment_cases": len(validation), "unseen_category_cases": int(unknown.sum())})
    selected_rows = []
    for label, weight in (("No KS penalty", 0.), ("Unit KS weight", 1.),
                          ("Minimum inner log loss", lock["lambda_minimum_loss"]),
                          ("One-SE KS preference", lock["lambda_one_se"])):
        chosen = select_count(final, weight / n)
        selected_rows.append({"rule": label, "lambda": weight, "alpha": weight / n,
                              "selected_g": int(chosen.feature_group_count), "included_feature_groups": chosen.included_feature_groups,
                              "negative_log_likelihood": -chosen.training_log_likelihood, "ks_bits": chosen.ks_bits,
                              "ks_penalty": weight * chosen.ks_bits,
                              "objective": -chosen.training_log_likelihood + weight * chosen.ks_bits,
                              "open_dfg_nodes": chosen.open_dfg_nodes, "open_dfg_edges": chosen.open_dfg_edges,
                              **{f"validation_{m}": chosen[f"validation_{m}"] for m in METRICS}})
    selected = pd.DataFrame(selected_rows)
    leave_out = []
    for fold in sorted(folds.fold.unique()):
        _, _, omitted_choice = calibrate(folds[folds.fold.ne(fold)])
        alpha = omitted_choice["one_se_alpha"]
        leave_out.append({"omitted_fold": int(fold), "one_se_alpha": alpha, "lambda_final_scale": alpha * n,
                          "final_training_selected_g": int(select_count(final, alpha).feature_group_count),
                          "one_se_threshold": omitted_choice["one_se_threshold"]})
    sensitivity = pd.DataFrame(leave_out)
    final["score_one_se"] = objective(final.training_log_likelihood, final.ks_bits, lock["lambda_one_se"])
    final["score_minimum_loss"] = objective(final.training_log_likelihood, final.ks_bits, lock["lambda_minimum_loss"])
    final_envelope = envelope(final)
    final_envelope["lambda_lower"] = final_envelope.alpha_lower * n
    final_envelope["lambda_upper"] = final_envelope.alpha_upper * n
    outputs = {"inner_candidate_results.csv": folds, "inner_fold_manifest.csv": manifest,
               "inner_fold_membership.csv": pd.concat(memberships, ignore_index=True),
               "lambda_calibration.csv": calibration, "calibration_fold_choices.csv": fold_choices,
               "final_candidate_results.csv": final, "selection_comparison.csv": selected,
               "leave_one_fold_out_sensitivity.csv": sensitivity, "final_exact_lambda_intervals.csv": final_envelope}
    outputs["assessment_category_audit.csv"] = pd.DataFrame(category_rows)
    for name, table in outputs.items():
        table.to_csv(out / name, index=False)
    purged_final[["CaseID", config.time_column, "outcome_time"]].to_csv(out / "final_purged_unavailable_labels.csv", index=False)
    eligible[["CaseID", config.time_column, "outcome_time"]].to_csv(out / "final_training_membership.csv", index=False)
    plot_results(calibration, folds, final, choices, selected, out, show)
    primary = selected[selected.rule.eq("One-SE KS preference")].iloc[0]
    interval = calibration[calibration.one_se_ks_choice].iloc[0]
    findings = (f"Training-only calibration selects representative lambda={primary['lambda']:.6g} "
                f"(alpha={primary.alpha:.6g}); final feature count g={int(primary.selected_g)}. "
                f"The inner-fold policy is unchanged for alpha in ({interval.alpha_lower:.6g}, {interval.alpha_upper:.6g}), "
                f"equivalently lambda in ({n * interval.alpha_lower:.6g}, {n * interval.alpha_upper:.6g}) on the final-training scale, "
                f"apart from boundary ties. The minimum-log-loss representative is lambda={lock['lambda_minimum_loss']:.6g}. "
                f"Outer validation: accuracy={primary.validation_accuracy:.3%}, AUC={primary.validation_roc_auc:.4f}, "
                f"log loss={primary.validation_log_loss:.4f}. Final training uses {n} label-available cases, "
                f"excluding {len(purged_final)} original training cases with later outcomes. "
                f"{int(calibration.within_one_se.sum())}/{len(calibration)} tested policies meet the one-SE allowance. "
                "The interval, not its arbitrary representative, is the identified result. "
                "This is a calibrated preference under a declared heuristic, not a uniquely optimal or universal lambda.")
    (out / "findings.txt").write_text(findings + "\n", encoding="utf-8")
    if any(sha256(root / name) != digest for name, digest in hashes.items()):
        raise AssertionError("Source data changed during Task 7.6.")
    protocol = {"task": "7.6", "criterion": "-ln(L_hat_g) + lambda * KS_g_bits_per_transition",
                "no_bic_or_parameter_penalty": True, "calibration": "Four expanding chronological inner folds; equal-fold mean log loss",
                "graph_estimation": "500 stratified training explanation cases per fit; common across g, background 100 training cases",
                "feature_order": "Within-fit training mean absolute grouped linear SHAP on 1000 cases; original order breaks ties",
                "transfer": "Tune alpha=lambda/n_train, apply lambda_fold=alpha*n_fold and lambda_final=alpha*n_final",
                "selection_rule": "Minimum inner mean KS among policies within best mean log loss + its fold SE; ties by mean g, mean loss, then alpha",
                "minimum_loss_reference": "Lowest mean inner log loss, ties by mean KS, mean g, then alpha",
                "lambda_representative": "Arithmetic midpoint of each finite open interval; twice positive lower bound for unbounded tail (1 if lower=0); zero explicit",
                "boundary_convention": "Exact positive crossings are reported, not separately calibrated; score ties select smaller g",
                "one_se_caveat": "SD(fold mean losses)/sqrt(folds); heuristic, not a confidence interval under overlapping time folds",
                "outer_validation_cases": len(validation), "original_training_cases": len(original_train),
                "final_training_cases": n, "final_purged_labels": len(purged_final), "seed": seed, "inner_folds": inner_folds,
                "test_cases_used": False, "outer_validation_used_to_tune_lambda": False,
                "training_refits": True, "python": platform.python_version(), "input_sha256": hashes,
                "implementation_sha256": {name: sha256(root / name) for name in [Path(__file__).name, *implementation_names]},
                "limits": ["New purged training cohort and training-based graphs differ from Tasks 7.4/7.5; do not attribute all differences to formula",
                           "A finite candidate path identifies coefficient ranges, not a unique scientific constant",
                           "KS is first-order routing uncertainty, not a validated human-comprehension cost",
                           "Zero entropy can occur for multiple feature counts; this score has no parameter-count term",
                           "One-SE preference and fold-omission sensitivity are exploratory, not formal noninferiority or independent stability estimates",
                           "Historical validation/test inspection remains; no pristine holdout claim",
                           "The existing fixed cohort includes its documented historical exclusions",
                           "SHAP and entropy sampling uncertainty is not quantified in this task"]}
    protocol["categorical_encoding_audit"] = "Unseen assessment categories retain the existing handle_unknown=ignore encoding; counts exported separately, not used for calibration."
    (out / "analysis_protocol.json").write_text(json.dumps(protocol, indent=2), encoding="utf-8")
    if show:
        display(Markdown("**Task 7.6 findings.** " + findings))
        tables = [("Calibrated choices and outer-validation results", "selection_comparison.csv", selected),
                  ("Chronological calibration folds", "inner_fold_manifest.csv", manifest),
                  ("Lambda intervals and inner-validation tradeoffs", "lambda_calibration.csv", calibration),
                  ("Final candidate scores and complexity", "final_candidate_results.csv",
                   final[["feature_group_count", "included_feature_groups", "training_log_likelihood", "ks_bits",
                          "open_dfg_nodes", "open_dfg_edges", "score_one_se", "score_minimum_loss", *[f"validation_{m}" for m in METRICS]]]),
                  ("Sensitivity to omitting a calibration fold", "leave_one_fold_out_sensitivity.csv", sensitivity)]
        for title, name, table in tables:
            display(Markdown(f"**{title}.** [Download CSV]({OUTPUT_DIRECTORY}/{name})"))
            with pd.option_context("display.max_rows", 120, "display.max_columns", 25):
                shown = table.copy()
                numeric = shown.select_dtypes(include="number").columns
                shown[numeric] = shown[numeric].round(6)
                display(shown)
    print(findings, flush=True)
    return outputs


if __name__ == "__main__":
    run_task7_6(show=False)
