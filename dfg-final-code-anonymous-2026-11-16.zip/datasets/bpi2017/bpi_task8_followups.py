"""Matched, training-only tests of BIC-style graph replacements."""
import json
from dataclasses import replace
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from IPython.display import Markdown, display

from bpi_task7_2_explanation_coding import _save_figure, load_saved_candidates
from bpi_task7_3_validation import (
    ExplicitSplitStudy, _fit_checked, counts_from_artifact, cycle_entropy,
    load_development, probability_metrics, temporal_splits,
)
from bpi_task7_6_likelihood_ks import sha256
from bpi_task8_ks_replacement import score_candidates
from multidataset_task7_7 import INPUT, MEASURES, load_candidates

OUT81 = "task8_1_robustness_outputs"
OUT82 = "task8_2_graph_replacement_outputs"
METRICS = ["validation_accuracy", "validation_roc_auc", "validation_log_loss"]
RULES81 = {"BIC": "BIC", "KS": "KS replacement", "Full": "Full feature set"}
PROXIES = {
    "feature_group_count": "Feature groups",
    "edge_count": "Edge count", "edge_surplus": "Excess edges",
    "density": "Density", "reachable_diameter": "Reachable diameter",
    "closeness": "Closeness", "betweenness": "Betweenness",
    "eigenvector": "Eigenvector", "l1_distance_full": "L1 distance to full",
}
RULES82 = {**RULES81, **PROXIES}
COLORS = {"BIC": "#28688f", "KS": "#278068", "Full": "#777777"}


def evaluate_rules(frame, proxies=()):
    """Minimize fit-plus-penalty within each fold; assessment never enters the score."""
    scores, selections = [], []
    for fold, part in frame.groupby("fold", sort=True):
        part = score_candidates(part)
        n = int(part.training_cases.iloc[0])
        definitions = {"BIC": part.parameter_count_k, "KS": part.ks_bits,
                       **{name: part[name] for name in proxies}}
        for rule, proxy in definitions.items():
            if not np.isfinite(proxy).all() or (proxy < 0).any():
                raise ValueError(f"Invalid replacement values for {rule}")
            path = part.assign(rule=rule, replacement_value=proxy, penalty=proxy * np.log(n))
            path["score"] = path.training_deviance + path.penalty
            path["delta_score"] = path.score - path.score.min()
            ranked = path.sort_values(["score", "feature_group_count"])
            choice = ranked.iloc[0].to_dict()
            choice["runner_up_gap"] = ranked.score.iloc[1] - ranked.score.iloc[0]
            scores.append(path)
            selections.append(choice)
        # The full model is a fixed baseline, even when training fits are tied.
        selections.append({**part.iloc[-1].to_dict(), "rule": "Full", "penalty": 0.,
                           "score": part.training_deviance.iloc[-1]})
    return pd.concat(scores, ignore_index=True), pd.DataFrame(selections)


def verified_inputs(root):
    folds, final, _, hashes, protocol = load_candidates(root)
    _, train, assessment, config, _ = load_development(root)
    boundary = assessment[config.time_column].min()
    eligible = train[train.outcome_time.lt(boundary)].copy()
    splits = temporal_splits(eligible, config.time_column, boundary, folds=protocol["inner_folds"])
    members_path = root / INPUT / "inner_fold_membership.csv"
    final_path = root / INPUT / "final_training_membership.csv"
    members = pd.read_csv(members_path)
    hashes.update({str(p.relative_to(root)): sha256(p) for p in [members_path, final_path]})
    cohorts = [(i, a, b, start) for i, (a, b, _, start, _) in enumerate(splits, 1)]
    cohorts.append((0, eligible, assessment, boundary))
    candidates = pd.concat([folds, final], ignore_index=True)
    audit = []
    for fold, past, future, start in cohorts:
        directory = root / INPUT / (f"inner_fold_{fold}" if fold else "final_training")
        probes = pd.read_csv(directory / "training_explanation_case_ids.csv").CaseID
        pred = pd.read_csv(directory / "assessment_probabilities.csv")
        training_ids = (members.loc[members.fold.eq(fold) & members.role.eq("train"), "CaseID"]
                        if fold else pd.read_csv(final_path).CaseID)
        expected = future.set_index("CaseID")[config.target_column]
        if (not training_ids.is_unique or set(training_ids) != set(past.CaseID)
                or not probes.is_unique or not set(probes) <= set(training_ids)
                or not pred.CaseID.is_unique or set(pred.CaseID) != set(expected.index)
                or set(training_ids) & set(pred.CaseID)
                or not past.outcome_time.lt(start).all()):
            raise ValueError(f"Invalid training/assessment membership in period {fold}")
        y = expected.loc[pred.CaseID].to_numpy()
        np.testing.assert_array_equal(y, pred[config.target_column])
        for row in candidates[candidates.fold.eq(fold)].itertuples():
            g = row.feature_group_count
            if (row.training_cases, row.assessment_cases, row.explanation_cases) != (len(past), len(future), len(probes)):
                raise ValueError(f"Unexpected cohort counts in period {fold}, g={g}")
            values = probability_metrics(y, pred[f"accepted_probability_g_{g}"])
            np.testing.assert_allclose([values[m.removeprefix("validation_")][0] for m in METRICS],
                                       [getattr(row, m) for m in METRICS], atol=1e-10, rtol=0)
        audit.append(dict(fold=fold, training_cases=len(past), assessment_cases=len(future),
                          latest_training_outcome=past.outcome_time.max(), assessment_start=start,
                          training_explanation_cases=len(probes)))
    candidates["bits_per_closed_case"] = candidates.ks_bits * (candidates.feature_group_count + 2)
    return candidates, pd.DataFrame(audit), hashes, (train, eligible, assessment, config, protocol["seed"])


def legacy_precision(root, train, assessment, config):
    saved, order, cases, hashes = load_saved_candidates(root)
    study = ExplicitSplitStudy(train, assessment, config)
    rows, paths = [], {}
    for tolerance in [1e-4, 1e-10]:
        paths[tolerance] = []
        for candidate in saved:
            g = candidate["k"]
            fitted, _ = _fit_checked(study, order[:g], tolerance=tolerance)
            counts = counts_from_artifact(fitted, order[:g], cases)
            paths[tolerance].append(counts)
            if tolerance == 1e-4:
                np.testing.assert_allclose(fitted["BIC"], candidate["model"]["BIC"], atol=1e-6, rtol=0)
                np.testing.assert_array_equal(counts, candidate["case_counts"])
            ll = fitted["training_log_likelihood"]
            h = cycle_entropy(counts.sum(axis=0)) / (g + 2)
            rows.append(dict(tolerance=tolerance, feature_group_count=g, training_deviance=-2*ll,
                             ks_bits=h, ks_penalty=h*np.log(len(train)), score=-2*ll+h*np.log(len(train)),
                             changed_rankings=np.any(counts != candidate["case_counts"], axis=(1, 2)).sum()))
    result = pd.DataFrame(rows)
    result["delta_score"] = result.score - result.groupby("tolerance").score.transform("min")
    legacy_penalty = result[result.tolerance.eq(1e-4)].set_index("feature_group_count").ks_penalty
    result["score_with_original_graph"] = result.training_deviance + result.feature_group_count.map(legacy_penalty)
    return result, paths[1e-10], hashes


def training_count_pool(root, eligible, config, seed, final, size=2000):
    """Expand the explanation cohort without changing the fitted candidate path."""
    study = ExplicitSplitStudy(eligible, eligible, replace(config, random_state=seed))
    directory = root / INPUT / "final_training"
    order = pd.read_csv(directory / "feature_order.csv").feature_group.tolist()
    pool = np.random.default_rng(81001).choice(len(eligible), size=size, replace=False)
    case_ids = study.train_data.iloc[pool].CaseID.to_numpy()
    arrays = []
    for row in final.sort_values("feature_group_count").itertuples():
        g = row.feature_group_count
        fitted, _ = _fit_checked(study, order[:g], tolerance=1e-8)
        np.testing.assert_allclose(fitted["training_log_likelihood"], row.training_log_likelihood, atol=1e-6, rtol=0)
        saved_log = pd.read_csv(directory / f"feature_count_{g:02d}_training_feature_log.csv", keep_default_na=False)
        probe_ids = study.probe_case_ids
        baseline = counts_from_artifact(fitted, order[:g], probe_ids)
        np.testing.assert_array_equal(baseline, counts_from_artifact({"feature_log": saved_log}, order[:g], probe_ids))
        np.testing.assert_allclose(cycle_entropy(baseline.sum(axis=0))/(g+2), row.ks_bits, atol=1e-10, rtol=0)
        shap = study._linear_grouped_shap(fitted["model"], fitted["indices"], study.X_train[pool],
                                         study.X_train[study.background_indices])
        log, *_ = study._feature_log_and_traces(case_ids, study.y_train[pool], shap, included_features=order[:g])
        arrays.append(counts_from_artifact({"feature_log": log}, order[:g], case_ids))
    return arrays, case_ids


def resample_scores(counts, deviance, n, size, repeats, replace_cases, rng):
    """Resample the same complete case rankings for all candidates."""
    if len(counts) != 7 or len({len(c) for c in counts}) != 1 or repeats < 1:
        raise ValueError("Expected seven aligned BPI candidate paths and at least one draw.")
    rows = []
    for iteration in range(repeats):
        draw = rng.choice(len(counts[0]), size=size, replace=replace_cases)
        h = np.array([cycle_entropy(c[draw].sum(axis=0))/c.shape[1] for c in counts])
        values = deviance + h*np.log(n)
        rows.append({"draw": iteration + 1, "explanation_cases": size,
                     "selected_g": int(np.argmin(values)) + 1, "score_g7_minus_g6": values[6]-values[5]})
    return pd.DataFrame(rows)


def period_label(fold):
    return "Final validation" if fold == 0 else f"Fold {fold}"


def report(root, output, exports, hashes, protocol):
    if any(sha256(root/name) != digest for name, digest in hashes.items()):
        raise ValueError("An earlier analysis artifact changed.")
    for name, frame in exports.items():
        frame.to_csv(output/f"{name}.csv", index=False)
    protocol["input_sha256"] = hashes
    protocol["implementation_sha256"] = {Path(__file__).name: sha256(Path(__file__))}
    protocol["test_cases_used"] = False
    (output/"analysis_protocol.json").write_text(json.dumps(protocol, indent=2), encoding="utf-8")


def show_table(title, frame, columns):
    display(Markdown(f"**{title}**"))
    display(frame[columns].round(6))


def run_task8_1(root=".", show=True, repeats=400):
    root = Path(root).resolve()
    out = root / OUT81
    out.mkdir(exist_ok=True)
    data, audit, hashes, (train, eligible, assessment, config, seed) = verified_inputs(root)
    scores, selected = evaluate_rules(data)
    precision, legacy_counts, legacy_hashes = legacy_precision(root, train, assessment, config)
    hashes.update(legacy_hashes)
    final = data[data.fold.eq(0)].sort_values("feature_group_count")
    arrays, pool_ids = training_count_pool(root, eligible, config, seed, final)
    rng = np.random.default_rng(81002)
    samples = pd.concat([
        resample_scores(arrays, -2*final.training_log_likelihood.to_numpy(), len(eligible),
                        size, repeats if size < len(pool_ids) else 1, False, rng)
        for size in (100, 250, 500, 1000, len(pool_ids))
    ], ignore_index=True)
    tight = precision[precision.tolerance.eq(1e-10)]
    bootstrap = resample_scores(legacy_counts, tight.training_deviance.to_numpy(), len(train),
                                len(legacy_counts[0]), repeats, True, rng)
    sampling = (samples.groupby(["explanation_cases", "selected_g"]).size()
                .rename("draws_selecting_g").reset_index())
    sampling["fraction"] = sampling.draws_selecting_g / sampling.groupby("explanation_cases").draws_selecting_g.transform("sum")
    summary = pd.concat([selected[selected.fold.eq(0)], selected[selected.fold.ne(0)]])
    exports = dict(candidate_scores=scores, period_selections=summary, cohort_audit=audit,
                   legacy_precision=precision, legacy_paired_bootstrap=bootstrap,
                   explanation_size_draws=samples, explanation_size_frequencies=sampling,
                   explanation_pool_cases=pd.DataFrame({"CaseID": pool_ids}))
    report(root, out, exports, hashes, {"task": "8.1", "formula": "-2 ln(L_hat) + KS_bits ln(n)",
           "repeats": repeats, "seeds": [81001, 81002], "coefficient_tuned": False,
           "legacy_precision": "Original fit/probe cohort retained; solver tolerance tightened from 1e-4 to 1e-10",
           "resampling": "Paired whole cases; fixed models, ranking order and background; conditional sensitivity, not temporal uncertainty"})
    plot81(summary, sampling, precision, bootstrap, out, show)
    if show:
        final_choices = summary[summary.fold.eq(0)].set_index("rule").feature_group_count
        legacy_delta = tight.set_index("feature_group_count").score
        old_g = int(precision[precision.tolerance.eq(1e-4)].sort_values(["score", "feature_group_count"]).iloc[0].feature_group_count)
        tight_g = int(legacy_delta.idxmin())
        tight_share = bootstrap.selected_g.eq(tight_g).mean()
        low, high = bootstrap.score_g7_minus_g6.quantile([.025, .975])
        display(Markdown(
            f"**Result.** The training-only final comparison selects **{final_choices['BIC']}** groups with BIC "
            f"and **{final_choices['KS']}** with KS replacement. On the original cohort, tightening the solver "
            f"moves the minimum from **{old_g} to {tight_g} groups**; the tighter-fit winner is selected in "
            f"**{tight_share:.1%}** of the paired graph-bootstrap draws. The tighter-fit seven-minus-six score "
            f"difference is **{legacy_delta[7]-legacy_delta[6]:.5f}**. "
            f"The central 95% of paired legacy graph-bootstrap differences spans **[{low:.5f}, {high:.5f}]** "
            f"(conditional on those tighter fits)."
        ))
        cols = ["fold", "rule", "feature_group_count", "edge_count", "ks_bits", "bits_per_closed_case", *METRICS]
        show_table("Selections and assessment results (fold 0 = final validation)", summary, cols)
        show_table("Legacy solver audit: same candidates and explanation cases", precision, list(precision.columns))
    return exports


def plot81(selected, sampling, precision, bootstrap, out, show):
    periods = sorted(selected.fold.unique(), key=lambda f: f or 99)
    fig, axes = plt.subplots(1, 3, figsize=(14, 4.5), layout="constrained")
    for rule, label in RULES81.items():
        frame = selected[selected.rule.eq(rule)].set_index("fold").loc[periods]
        for ax, metric in zip(axes, ["feature_group_count", "validation_log_loss", "edge_count"]):
            ax.plot(range(len(periods)), frame[metric], "o-", label=label, color=COLORS[rule])
    for ax, title in zip(axes, ["Selected feature groups", "Next-period log loss", "Training DFG edges"]):
        ax.set(title=title, xticks=range(len(periods)), xticklabels=[period_label(f) for f in periods])
        ax.tick_params(axis="x", rotation=25)
        ax.grid(alpha=.2)
    axes[0].legend(fontsize=8)
    _save_figure(fig, out/"chronological_comparison.png", show)
    fig, axes = plt.subplots(1, 2, figsize=(12, 4.5), layout="constrained")
    grid = sampling.pivot(index="explanation_cases", columns="selected_g", values="fraction").fillna(0)
    grid.plot.bar(stacked=True, ax=axes[0], rot=0, colormap="cividis")
    axes[0].set(title="Training-only explanation sample sensitivity", xlabel="Explanation cases",
                ylabel="Fraction of draws")
    axes[0].legend(title="Selected groups")
    axes[1].hist(bootstrap.score_g7_minus_g6, bins=25, color="#28688f")
    axes[1].axvline(0, color="#aa4c32", linestyle="--")
    for tolerance, group in precision.groupby("tolerance"):
        delta = group.set_index("feature_group_count").score
        axes[1].axvline(delta[7]-delta[6], label=f"Point estimate, tol={tolerance:g}",
                        linestyle=":" if tolerance == 1e-4 else "-", color=COLORS["Full" if tolerance == 1e-4 else "KS"])
    axes[1].set(title="Legacy case bootstrap (fixed tighter fits)", xlabel="Score(7 groups) minus score(6 groups)",
                ylabel="Resamples")
    axes[1].legend(fontsize=8)
    _save_figure(fig, out/"score_stability.png", show)


def run_task8_2(root=".", show=True):
    root = Path(root).resolve()
    out = root / OUT82
    out.mkdir(exist_ok=True)
    data, audit, hashes, _ = verified_inputs(root)
    scores, selected = evaluate_rules(data, PROXIES)
    baseline = selected[selected.rule.eq("BIC")].set_index("fold")
    for metric in [*METRICS, "edge_count", "ks_bits"]:
        selected[f"{metric}_minus_BIC"] = selected[metric] - selected.fold.map(baseline[metric])
    folds = selected[selected.fold.ne(0)]
    means = folds.groupby("rule", sort=False)[["feature_group_count", *METRICS, "ks_bits", "edge_count"]].mean().reset_index()
    final = selected[selected.fold.eq(0)].copy()
    spans = (scores[scores.fold.eq(0)].groupby("rule").penalty.agg(["min", "max"])
             .assign(penalty_span=lambda t: t["max"]-t["min"]).reset_index())
    exports = dict(candidate_scores=scores, period_selections=selected, final_comparison=final,
                   fold_mean_comparison=means, final_penalty_ranges=spans, cohort_audit=audit)
    report(root, out, exports, hashes, {"task": "8.2", "formula": "-2 ln(L_hat) + raw_proxy ln(n)",
           "coefficient_tuned": False, "rescaled": False, "similarity_role": "Fidelity control, not a simplicity measure",
           "proxy_definitions": {key: MEASURES[key] for key in PROXIES if key in MEASURES},
           "limitations": "Raw scales differ. Compare resulting models, not absolute scores across formulas."})
    plot82(selected, spans, out, show)
    if show:
        baseline_row = final[final.rule.eq("BIC")].iloc[0]
        simpler = final[final.edge_count.lt(baseline_row.edge_count)].rule.map(RULES82)
        display(Markdown(
            "**Graph-size comparison.** Rules selecting fewer edges than ordinary BIC: "
            + (", ".join(simpler) if len(simpler) else "none")
            + " (final split). In the earlier folds, the raw edge-count rule selects fewer edges than BIC in "
            + f"{folds[folds.rule.eq('edge_count')].edge_count_minus_BIC.lt(0).sum()} of "
            + f"{folds.fold.nunique()} periods. Check the assessment metrics before interpreting fewer edges "
            + "as a useful tradeoff."
        ))
        show_table("Final training selections and subsequent validation", final,
                   ["rule", "feature_group_count", "replacement_value", "penalty", "edge_count", "ks_bits", *METRICS])
        show_table("Mean across four chronological assessment folds", means, list(means.columns))
        show_table("Penalty range across candidate counts (final training)", spans, list(spans.columns))
    return exports


def plot82(selected, spans, out, show):
    rules = list(RULES82)
    periods = sorted(selected.fold.unique(), key=lambda f: f or 99)
    table = selected.pivot(index="rule", columns="fold", values="feature_group_count").loc[rules, periods]
    fig, axes = plt.subplots(1, 2, figsize=(13, 6.2), layout="constrained")
    matrix = table.to_numpy()
    axes[0].imshow(matrix, cmap="cividis", aspect="auto", vmin=1, vmax=7)
    for (i, j), g in np.ndenumerate(matrix):
        axes[0].text(j, i, f"{g:g}", ha="center", va="center", color="white" if g <= 4 else "black")
    axes[0].set(title="Selected feature groups", yticks=range(len(rules)), yticklabels=[RULES82[r] for r in rules],
                xticks=range(len(periods)), xticklabels=[period_label(f) for f in periods])
    axes[0].tick_params(axis="x", rotation=25)
    spans = spans.set_index("rule").reindex([r for r in rules if r != "Full"])
    axes[1].barh([RULES82[r] for r in spans.index], spans.penalty_span, color="#278068")
    axes[1].invert_yaxis()
    axes[1].set(xscale="symlog", xlabel="Maximum minus minimum penalty (symlog)", title="Raw penalty scale, final training")
    axes[1].grid(axis="x", alpha=.2)
    _save_figure(fig, out/"selection_and_penalty_scale.png", show)
    final = selected[selected.fold.eq(0)].set_index("rule").loc[rules]
    fig, axes = plt.subplots(1, 3, figsize=(14, 6), layout="constrained", sharey=True)
    for ax, metric, title in zip(axes, METRICS, ["Accuracy", "ROC AUC", "Log loss"]):
        delta = final[f"{metric}_minus_BIC"] * (100 if metric == METRICS[0] else 1)
        ax.barh([RULES82[r] for r in rules], delta, color=["#28688f" if r == "KS" else "#7b888b" for r in rules])
        ax.set(title=title, xlabel="Difference from BIC" + (" (percentage points)" if metric == METRICS[0] else ""))
        ax.axvline(0, color="#333333", linewidth=.8)
        ax.grid(axis="x", alpha=.2)
    axes[0].invert_yaxis()
    fig.suptitle("Final validation after selection on training data")
    _save_figure(fig, out/"validation_differences.png", show)


def write_task8_followup_manifest(study, show=True):
    from bpi_task8_ks_replacement import write_task8_manifest
    frame = write_task8_manifest(study, show=False)
    position = next((i for i, task in enumerate(frame.task) if task == "Final test report"), len(frame))
    rows = [{"task": task, "output_directory": folder, "primary_file": name,
             "available": (study.root/folder/name).exists()}
            for task, folder, name in [("Task 8.1", OUT81, "period_selections.csv"),
                                       ("Task 8.2", OUT82, "final_comparison.csv")]]
    frame = pd.concat([frame.iloc[:position], pd.DataFrame(rows), frame.iloc[position:]], ignore_index=True)
    frame.to_csv(study.root/"tasks_1_to_8_output_manifest.csv", index=False)
    if show:
        display(frame)
    return frame
