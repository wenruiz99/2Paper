"""Replace the parameter count in BIC by KS entropy, without tuning a weight."""
import json
import math
from pathlib import Path
import platform

import matplotlib.pyplot as plt
from matplotlib.ticker import PercentFormatter
import networkx as nx
import numpy as np
import pandas as pd
from IPython.display import Markdown, display

from bpi_task7_2_explanation_coding import load_saved_candidates, code_components, _save_figure
from bpi_task7_6_likelihood_ks import sha256

OUTPUT = 'task8_ks_replacement_outputs'
SOURCES = {'original': 'Original Task 3 fits (main comparison)',
           'training_graph': 'Task 7.6 fits (separate sensitivity)'}
CRITERIA = {'BIC': 'Ordinary BIC', 'KS_replacement_bits': 'KS replacement (bits)',
            'deviance_only': 'No complexity penalty'}
COLORS = {'BIC': '#28688f', 'KS_replacement_bits': '#288068', 'deviance_only': '#888888'}
METRICS = ['validation_accuracy', 'validation_roc_auc', 'validation_log_loss']


def score_candidates(frame):
    frame = frame.sort_values('feature_group_count').reset_index(drop=True).copy()
    if frame.feature_group_count.tolist() != list(range(1, len(frame)+1)):
        raise ValueError('A complete nested candidate path is required.')
    n = frame.training_cases.to_numpy(float)
    k = frame.parameter_count_k.to_numpy(float)
    ell = frame.training_log_likelihood.to_numpy(float)
    h = frame.ks_bits.to_numpy(float)
    if (not all(np.isfinite(x).all() for x in [n, k, ell, h]) or len(set(n)) != 1
            or (n <= 1).any() or (k < 1).any() or (k != np.floor(k)).any()
            or (ell > 0).any() or (h < 0).any()):
        raise ValueError('Need a common training size, valid parameter ranks, log likelihoods and nonnegative KS.')
    frame['log_n'] = np.log(n)
    frame['training_deviance'] = -2*ell
    frame['bic_parameter_penalty'] = k*np.log(n)
    frame['ks_penalty_bits'] = h*np.log(n)
    frame['BIC'] = frame.training_deviance + frame.bic_parameter_penalty
    frame['KS_replacement_bits'] = frame.training_deviance + frame.ks_penalty_bits
    frame['deviance_only'] = frame.training_deviance
    frame['half_score_identity'] = -ell + 0.5*h*np.log(n)
    for key in CRITERIA:
        frame['delta_' + key] = frame[key] - frame[key].min()
    return frame


def selection_summary(frame, source):
    rows = []
    for key, label in CRITERIA.items():
        ordered = frame.sort_values('feature_group_count').sort_values(key, kind='stable')
        row, runner_up = ordered.iloc[0], ordered.iloc[1]
        penalty = row[key] - row.training_deviance
        rows.append({'source': source, 'criterion': key, 'label': label, 'selected_g': int(row.feature_group_count),
            'included_feature_groups': row.included_feature_groups, 'parameter_count_k': int(row.parameter_count_k),
            'training_cases_n': int(row.training_cases), 'ks_bits': row.ks_bits,
            'training_deviance': row.training_deviance, 'complexity_penalty': penalty, 'selected_score': row[key],
            'runner_up_g': int(runner_up.feature_group_count), 'runner_up_gap': runner_up[key] - row[key],
            'open_dfg_nodes': row.open_dfg_nodes, 'open_dfg_edges': row.open_dfg_edges,
            **{m: row[m] for m in METRICS}})
    return pd.DataFrame(rows)


def marginal_table(frame, source):
    g = frame.feature_group_count.to_numpy()
    fit_gain = -np.diff(frame.training_deviance)
    table = pd.DataFrame({'source': source, 'from_g': g[:-1], 'to_g': g[1:], 'deviance_improvement': fit_gain,
        'extra_parameter_count': np.diff(frame.parameter_count_k), 'extra_ks_bits': np.diff(frame.ks_bits),
        'extra_BIC_penalty': np.diff(frame.bic_parameter_penalty),
        'extra_KS_penalty_bits': np.diff(frame.ks_penalty_bits)})
    table['BIC_score_change'] = table.extra_BIC_penalty - fit_gain
    table['KS_score_change_bits'] = table.extra_KS_penalty_bits - fit_gain
    return table


def load_inputs(root):
    candidates, _, case_ids, hashes = load_saved_candidates(root)
    partition_path = root / 'study_protocol_partitions.csv'
    hashes[partition_path.name] = sha256(partition_path)
    partitions = pd.read_csv(partition_path).set_index('partition')
    n = int(partitions.loc['train', 'cases'])
    rows = []
    for candidate in candidates:
        row = candidate['model']
        entropy, _ = code_components(candidate['counts'], len(candidates))
        rows.append({'feature_group_count': candidate['k'], 'included_feature_groups': row['included_feature_groups'],
            'training_cases': n, 'parameter_count_k': row['design_rank_p'], 'training_log_likelihood': row['training_log_likelihood'],
            'ks_bits': entropy['ks_entropy_bits_per_transition'], 'explanation_cases': len(case_ids),
            'open_dfg_nodes': row['open_dfg_nodes'], 'open_dfg_edges': row['open_dfg_edges'],
            'saved_BIC': row['BIC'], **{m: row[m] for m in METRICS}})
    original = score_candidates(pd.DataFrame(rows))
    if not np.allclose(original.BIC, original.saved_BIC, atol=1e-7, rtol=0):
        raise ValueError('Original BIC must reproduce Task 3.')
    directory = root / 'task7_6_likelihood_ks_outputs'
    protocol_path = directory / 'analysis_protocol.json'
    hashes[str(protocol_path.relative_to(root))] = sha256(protocol_path)
    protocol = json.loads(protocol_path.read_text())
    for name, digest in protocol['input_sha256'].items():
        if sha256(root / name) != digest:
            raise ValueError('Changed Task 7.6 source: '+name)
        hashes[name] = digest
    cache_path = directory / 'final_training/fit_cache.json'
    hashes[str(cache_path.relative_to(root))] = sha256(cache_path)
    cache = json.loads(cache_path.read_text())
    for name, digest in cache['files'].items():
        path = cache_path.parent / name
        if sha256(path) != digest:
            raise ValueError('Changed Task 7.6 fit artifact: '+name)
        hashes[str(path.relative_to(root))] = digest
    training = pd.read_csv(cache_path.parent / 'candidate_results.csv')
    for row in training.itertuples():
        graph = nx.read_graphml(cache_path.parent / f'feature_count_{row.feature_group_count:02d}_closed_dfg.graphml')
        counts = nx.to_numpy_array(graph, weight='weight')
        mass = counts.sum(axis=1)
        if not np.allclose(mass, row.explanation_cases) or not np.allclose(mass, counts.sum(axis=0)):
            raise ValueError('Training graph is not a complete restart-closed ranking graph.')
        probabilities = counts/mass[:, None]
        positive = probabilities > 0
        h = -np.sum(probabilities[positive]*np.log2(probabilities[positive]))/len(graph)
        if not np.isclose(h, row.ks_bits, rtol=0, atol=1e-10):
            raise ValueError('Training graph entropy differs from Task 7.6.')
    training = score_candidates(training)
    return {'original': original, 'training_graph': training}, hashes


def make_figures(frames, selected, marginals, out, show):
    with plt.rc_context({'font.size': 10, 'axes.spines.top': False, 'axes.spines.right': False}):
        primary = frames['original']
        fig, axes = plt.subplots(1, 3, figsize=(14, 4.8), constrained_layout=True)
        g = primary.feature_group_count
        axes[0].plot(g, primary.parameter_count_k, 's-', color=COLORS['BIC'], label='Parameter count k')
        axes[0].plot(g, primary.ks_bits, 'o-', color=COLORS['KS_replacement_bits'], label='KS (bits/transition)')
        axes[0].set(title='The quantity being replaced', ylabel='Parameter count or entropy value')
        axes[0].legend(fontsize=8)
        axes[1].plot(g, primary.bic_parameter_penalty, 's-', color=COLORS['BIC'], label='k ln(n)')
        axes[1].plot(g, primary.ks_penalty_bits, 'o-', color=COLORS['KS_replacement_bits'], label='h_bits ln(n)')
        axes[1].set(title=f'Complexity penalty, n={int(primary.training_cases.iloc[0]):,}', ylabel='Penalty added to deviance')
        axes[1].legend(fontsize=8)
        axes[2].plot(g, primary.training_deviance, 'o-', color='#555555')
        axes[2].set(title='Same training fit term for all criteria', ylabel='-2 ln(fitted likelihood)')
        for ax in axes:
            ax.set(xlabel='Feature groups (g)', xticks=g)
            ax.grid(alpha=.2)
        fig.suptitle('Task 8: replace k with KS, rather than add a third term', fontsize=13)
        _save_figure(fig, out/'replacement_components.png', show)

        fig, axes = plt.subplots(2, 2, figsize=(13, 9), constrained_layout=True)
        for index, (source, frame) in enumerate(frames.items()):
            for col in range(2):
                ax = axes[index, col]
                subset = frame if col == 0 else frame[frame.feature_group_count.ge(4)]
                for criterion, label in CRITERIA.items():
                    if criterion == 'deviance_only':
                        continue
                    ax.plot(subset.feature_group_count, subset['delta_'+criterion],
                            marker={'BIC':'s', 'KS_replacement_bits':'o'}[criterion],
                            linestyle='--' if criterion == 'KS_replacement_bits' else '-',
                            color=COLORS[criterion], label=label, markersize=4)
                if col == 0:
                    ax.set_yscale('symlog', linthresh=1)
                else:
                    ax.set_yscale('symlog', linthresh=.01)
                ax.set(title=SOURCES[source]+('\nAll candidates' if col == 0 else '\nDetail: g=4 to 7'),
                       xlabel='Feature groups (g)', ylabel='Score minus its own minimum', xticks=subset.feature_group_count)
                ax.legend(fontsize=8)
                ax.grid(alpha=.2)
        fig.suptitle('Separate score minima; symmetric-log axes retain small differences near zero', fontsize=13)
        _save_figure(fig, out/'criterion_differences.png', show)

        fig, axes = plt.subplots(2, 2, figsize=(13, 8), constrained_layout=True)
        for i, source in enumerate(frames):
            table = marginals[marginals.source.eq(source)]
            x = np.arange(len(table))
            axes[i, 0].bar(x-.22, table.deviance_improvement, .22, label='Fit improvement', color='#666666')
            axes[i, 0].bar(x, table.extra_BIC_penalty, .22, label='Additional BIC penalty', color=COLORS['BIC'])
            axes[i, 0].bar(x+.22, table.extra_KS_penalty_bits, .22, label='Additional KS penalty', color=COLORS['KS_replacement_bits'])
            axes[i, 0].set_yscale('symlog', linthresh=1)
            axes[i, 0].set(title=SOURCES[source], xticks=x, xticklabels=[f'{a} to {b}' for a, b in zip(table.from_g, table.to_g)],
                           xlabel='Adding a feature group', ylabel='Marginal change (symlog)')
            axes[i, 0].legend(fontsize=8)
            last = table[table.to_g.ge(5)]
            for col, label, color in [('BIC_score_change','BIC',COLORS['BIC']),
                                      ('KS_score_change_bits','KS replacement, bits',COLORS['KS_replacement_bits'])]:
                axes[i, 1].plot(last.to_g, last[col], 'o-', label=label, color=color)
            axes[i, 1].set_yscale('symlog', linthresh=.01)
            axes[i, 1].axhline(0, color='#888888', linewidth=.8)
            axes[i, 1].set(title='Negative score change favours adding the group', xlabel='New feature-group count',
                           ylabel='New score minus previous score', xticks=last.to_g)
            axes[i, 1].legend(fontsize=8)
        for ax in axes.flat:
            ax.grid(alpha=.2)
        _save_figure(fig, out/'marginal_fit_vs_penalty.png', show)

        fig, axes = plt.subplots(2, 3, figsize=(14, 7), constrained_layout=True)
        for index, (source, frame) in enumerate(frames.items()):
            chosen = selected[selected.source.eq(source) & selected.criterion.ne('deviance_only')]
            for ax, metric, title in zip(axes[index], METRICS, ['Accuracy', 'ROC AUC', 'Log loss']):
                ax.plot(frame.feature_group_count, frame[metric], 'o-', color='#999999', markersize=4, label='All candidates')
                for row in chosen.itertuples():
                    size = {'BIC':110, 'KS_replacement_bits':80}[row.criterion]
                    ax.scatter(row.selected_g, getattr(row, metric), s=size, facecolors='none', edgecolors=COLORS[row.criterion],
                               linewidths=2, label=f'{row.label}: g={row.selected_g}')
                ax.set(title=title+(' (original fits)' if index == 0 else ' (Task 7.6 fits)'), xlabel='Feature groups (g)', xticks=frame.feature_group_count)
                if metric == 'validation_accuracy':
                    ax.yaxis.set_major_formatter(PercentFormatter(1, decimals=1))
                ax.grid(alpha=.2)
                ax.legend(fontsize=7, loc='upper center', bbox_to_anchor=(.5, -.19))
        fig.suptitle('Saved validation performance: descriptive comparison, not fresh independent evaluation', fontsize=12)
        _save_figure(fig, out/'validation_comparison.png', show)


def run_task8(root='.', show=True):
    root = Path(root).resolve()
    out = root/OUTPUT
    out.mkdir(exist_ok=True)
    frames, hashes = load_inputs(root)
    selected = pd.concat([selection_summary(frame, source) for source, frame in frames.items()], ignore_index=True)
    marginals = pd.concat([marginal_table(frame, source) for source, frame in frames.items()], ignore_index=True)
    all_rows = pd.concat([frame.assign(source=source) for source, frame in frames.items()], ignore_index=True)
    unit_check = all_rows[['source', 'feature_group_count', 'ks_bits',
                           'KS_replacement_bits', 'half_score_identity']].copy()
    unit_check['score_identity_residual'] = 2*unit_check.half_score_identity - unit_check.KS_replacement_bits
    if not np.allclose(unit_check.score_identity_residual, 0., atol=1e-9, rtol=0):
        raise AssertionError('Half-score identity failed.')
    source_audit = pd.DataFrame([{'source': source, 'training_cases_n': int(frame.training_cases.iloc[0]),
        'explanation_cases': int(frame.explanation_cases.iloc[0]),
        'explanation_partition': 'validation (legacy)' if source == 'original' else 'training',
        'label_availability_purged': source != 'original',
        'separate_model_family': True, 'new_training_or_test_predictions': False} for source, frame in frames.items()])
    outputs = {'candidate_scores.csv': all_rows, 'selection_comparison.csv': selected,
               'marginal_fit_and_penalty.csv': marginals, 'score_identity_checks.csv': unit_check,
               'source_cohort_audit.csv': source_audit}
    for name, frame in outputs.items():
        frame.to_csv(out/name, index=False)
    main = selected[selected.source.eq('original')].set_index('criterion')
    sensitivity = selected[selected.source.eq('training_graph')].set_index('criterion')
    findings = (f"Original Task 3 fits: ordinary BIC chooses g={int(main.loc['BIC','selected_g'])}; "
        f"KS replacement in bits chooses g={int(main.loc['KS_replacement_bits','selected_g'])}, "
        f"with runner-up g={int(main.loc['KS_replacement_bits','runner_up_g'])} only "
        f"{main.loc['KS_replacement_bits','runner_up_gap']:.6f} score units higher. "
        f"Separately, Task 7.6 training-graph fits choose g={int(sensitivity.loc['BIC','selected_g'])} under BIC "
        f"and g={int(sensitivity.loc['KS_replacement_bits','selected_g'])} under the bit-valued KS replacement. "
        "No lambda or one-SE tuning is used. Replacing k removes the parameter-count penalty; KS is not a parameter count. "
        "This is an exploratory entropy-replacement score, not a derived BIC. Small score gaps "
        "must not be presented as strong evidence for a unique feature count.")
    (out/'findings.txt').write_text(findings+'\n', encoding='utf-8')
    make_figures(frames, selected, marginals, out, show)
    if any(sha256(root/name) != digest for name, digest in hashes.items()):
        raise AssertionError('Earlier inputs changed during Task 8.')
    protocol = {'task':'8', 'primary_formula':'-2 ln(L_hat_g) + h_g_bits ln(n)',
        'baseline_formula':'k_g ln(n) - 2 ln(L_hat_g)', 'tuned_lambda':False, 'one_se_rule':False,
        'implicit_coefficient_relative_to_minus_log_likelihood':'ln(n)/2',
        'primary_source':'Original Task 3 fits and validation explanation graphs, reproducing the prior BIC comparison',
        'separate_sensitivity':'Task 7.6 final fits on label-available training cases, with training explanation graphs',
        'units':'KS uses log2 and bits per transition directly in the score; likelihood uses ln',
        'tie_rule':'Smallest g for exactly equal scores', 'test_cases_used':False, 'model_refits':False,
        'input_sha256':hashes, 'python':platform.python_version(),
        'implementation_sha256':{name:sha256(root/name) for name in [Path(__file__).name, 'bpi_task7_2_explanation_coding.py']},
        'limits':['Not standard BIC or evidence for a marginal-likelihood interpretation',
                  'Legacy primary graph uses validation explanations; do not call it training-only or independent evaluation',
                  'Prior test/validation inspection remains relevant',
                  'Training sample size and graph estimation cohort differ across the two comparisons',
                  'No refitting precision audit or new graph-estimation uncertainty analysis; small gaps are fragile',
                  'KS is first-order routing uncertainty, not validated human interpretability',
                  'Unit convention imposes a scale even without a tuned lambda']}
    (out/'analysis_protocol.json').write_text(json.dumps(protocol, indent=2), encoding='utf-8')
    if show:
        display(Markdown('**Task 8 findings.** '+findings))
        for title, frame in [('Selected models', selected), ('Candidate scores and components', all_rows[
            ['source', 'feature_group_count', 'parameter_count_k', 'training_cases', 'training_deviance', 'ks_bits',
             'bic_parameter_penalty', 'ks_penalty_bits', 'BIC', 'KS_replacement_bits']]),
            ('Marginal fit improvement versus penalty', marginals), ('Score identity checks', unit_check), ('Cohort and graph sources', source_audit)]:
            display(Markdown('**'+title+'.**'))
            with pd.option_context('display.max_rows',100,'display.max_columns',25):
                display(frame.round(6))
    print(findings, flush=True)
    return outputs


def write_task8_manifest(study, show=True):
    from multidataset_task7_7 import write_task77_manifest
    frame = write_task77_manifest(study, show=False)
    frame = frame[frame.task.ne('Task 8')].copy()
    if (study.root/OUTPUT/'selection_comparison.csv').exists():
        position = next((i for i, value in enumerate(frame.task) if value == 'Final test report'),len(frame))
        row = pd.DataFrame([{'task':'Task 8','output_directory':OUTPUT,'primary_file':'selection_comparison.csv','available':True}])
        frame = pd.concat([frame.iloc[:position],row,frame.iloc[position:]],ignore_index=True)
    frame.to_csv(study.root/'tasks_1_to_7_output_manifest.csv',index=False)
    frame.to_csv(study.root/'tasks_1_to_8_output_manifest.csv',index=False)
    if show:
        display(frame)
    return frame


if __name__ == '__main__':
    run_task8(show=False)
