"""Readable similarity labels without changing the saved numerical schema."""

from __future__ import annotations

import re

import matplotlib.pyplot as plt
from matplotlib.ticker import PercentFormatter
import numpy as np
import pandas as pd
from IPython.display import display as _display


_LEGACY_NAMES = {
    "supervisor_formula_similarity": "DFG similarity formula",
    "supervisor_similarity": "DFG similarity formula",
    "our_similarity_measure": "Normalized-frequency L1 similarity",
}
_LEGACY_TOKEN = re.compile(
    r"\b(?:[A-Za-z][A-Za-z0-9]*_)*(?:"
    + "|".join(_LEGACY_NAMES)
    + r")(?:_[A-Za-z0-9]+)*\b"
)
_CONTEXT_LABELS = {
    "to_full_support_dfg": "to full-support DFG",
    "to_full_dfg": "to full DFG",
    "to_projected_full_dfg": "to projected full DFG",
    "to_reference_dfg": "to reference DFG",
    "to_previous": "to previous setting",
    "prediction_ground_truth": "Prediction vs ground truth",
    "observed": "Observed",
    "p025": "2.5th percentile",
    "p975": "97.5th percentile",
}


def similarity_labels(text: str) -> str:
    """Replace legacy names in table headings, values, and saved text output."""
    def replace(match: re.Match) -> str:
        token = match.group()
        for old, label in _LEGACY_NAMES.items():
            if old in token:
                prefix, suffix = token.split(old, 1)
                context = [
                    _CONTEXT_LABELS.get(part, part.replace("_", " "))
                    for part in (prefix.strip("_"), suffix.strip("_")) if part
                ]
                return label + (f" ({'; '.join(context)})" if context else "")
        return token

    text = _LEGACY_TOKEN.sub(replace, text)
    for old, new in (
        (r"supervisor(?:'s)?\s+formula(?:\s+similarity)?", "DFG similarity formula"),
        (r"supervisor(?:'s)?\s+(?:score|similarity)", "DFG similarity formula"),
        (r"our\s+similarity\s+measure", "Normalized-frequency L1 similarity"),
    ):
        text = re.sub(old, new, text, flags=re.I)
    return text


def display_study_result(*objects, **kwargs):
    """Use descriptive similarity names in displays, leaving data unchanged."""
    presented = []
    for value in objects:
        if isinstance(value, pd.DataFrame):
            value = value.copy()
            value.columns = [
                similarity_labels(column) if isinstance(column, str) else column
                for column in value.columns
            ]
            for column in value.columns:
                if pd.api.types.is_object_dtype(value[column].dtype) or isinstance(
                    value[column].dtype, pd.StringDtype
                ):
                    value[column] = value[column].map(
                        lambda item: similarity_labels(item) if isinstance(item, str) else item
                    )
        presented.append(value)
    return _display(*presented, **kwargs)


def task1_similarity_figures(pairwise: pd.DataFrame, dataset_title: str):
    """Yield two separate, percentage-labelled figures from pairwise scores."""
    model_labels = {
        "logistic_regression": "Logistic Regression (LR)",
        "random_forest": "Random Forest (RF)",
        "neural_network": "Neural Network (NN)",
    }
    labels = [
        f"{model_labels[row.left_model]}\nvs\n{model_labels[row.right_model]}"
        for row in pairwise.itertuples()
    ]
    x = np.arange(len(pairwise))
    for column, title, filename in (
        (
            "supervisor_formula_similarity", "DFG similarity formula",
            "pairwise_dfg_formula_similarity.png",
        ),
        (
            "our_similarity_measure", "Normalized-frequency L1 similarity",
            "pairwise_normalized_frequency_l1_similarity.png",
        ),
    ):
        values = pairwise[column].to_numpy(dtype=float)
        if not np.all(np.isfinite(values) & (values >= 0) & (values <= 1)):
            raise ValueError(f"{column} must contain finite similarities in [0, 1].")
        fig, axis = plt.subplots(figsize=(9, 5.3), constrained_layout=True)
        bars = axis.bar(x, values, color=["#2f6690", "#3a7d44", "#b56576"])
        axis.bar_label(
            bars, labels=[f"{value:.1%}" for value in values],
            padding=5, fontsize=12, fontweight="bold",
        )
        axis.set_xticks(x, labels)
        axis.set_ylim(0, 1.10)
        axis.set_yticks(np.linspace(0, 1, 6))
        axis.yaxis.set_major_formatter(PercentFormatter(xmax=1, decimals=0))
        axis.set_ylabel("Similarity (%)")
        axis.set_title(title, fontsize=14, pad=12)
        axis.set_axisbelow(True)
        axis.grid(axis="y", alpha=0.25)
        fig.suptitle(f"Task 1: {dataset_title}", fontsize=12)
        yield fig, filename
