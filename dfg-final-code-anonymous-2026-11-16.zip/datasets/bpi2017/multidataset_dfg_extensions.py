"""Extended Tasks 5.4-7.1 for tabular feature-explanation DFG studies.

The functions in this module build on :class:`multidataset_dfg_study.DFGStudy`.
They keep the dataset notebooks compact while preserving all numerical tables,
GraphML files, XES logs, and notebook-visible figures required by the study.
"""

from __future__ import annotations

from collections import Counter
from itertools import combinations, pairwise
import math
from pathlib import Path
import xml.etree.ElementTree as ET

import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import networkx as nx
import numpy as np
import pandas as pd
import shap
from dfg_similarity_presentation import display_study_result as display
from sklearn.ensemble import RandomForestClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    confusion_matrix,
    log_loss,
    roc_auc_score,
)
from sklearn.neural_network import MLPClassifier

from multidataset_dfg_study import (
    _interval,
    _safe_name,
    _stratified_bootstrap_indices,
    build_dfg,
    dfg_branching_penalty,
    edge_weights,
    feature_only_traces,
    grouped_antithetic_permutation_shap,
    ks_entropy,
    l1_dfg_similarity,
    markov_entropy_measures,
    normalized_edge_weights,
    open_graph_measures,
    predictive_metrics,
    supervisor_dfg_similarity,
)


MODEL_SETTINGS = {
    "logistic_regression": {
        "C": 1.0,
        "solver": "lbfgs",
        "max_iter": 3000,
    },
    "random_forest": {
        "n_estimators": 150,
        "max_depth": 10,
        "min_samples_leaf": 2,
    },
    "neural_network": {
        "hidden_layer_sizes": (32, 16),
        "alpha": 0.01,
        "max_iter": 300,
        "early_stopping": True,
        "validation_fraction": 0.15,
        "n_iter_no_change": 15,
    },
}

MODEL_CONFIGURATION_TEXT = {
    "logistic_regression": "L2 Logistic Regression; C=1.0; unweighted probability model",
    "random_forest": (
        "Random Forest; n_estimators=150; max_depth=10; "
        "min_samples_leaf=2; unweighted probability model"
    ),
    "neural_network": (
        "Neural Network; hidden_layer_sizes=(32,16); alpha=0.01; "
        "early_stopping=True"
    ),
}

COMPARISONS = (
    {
        "task": "Task 5.1",
        "slug": "accepted_correct_vs_incorrect",
        "green_label": "Accepted - correct prediction (TP)",
        "red_label": "Accepted - incorrect prediction (FN)",
        "green_mask": lambda truth, prediction: (truth == 1) & (prediction == 1),
        "red_mask": lambda truth, prediction: (truth == 1) & (prediction == 0),
    },
    {
        "task": "Task 5.2",
        "slug": "rejected_correct_vs_incorrect",
        "green_label": "Rejected - correct prediction (TN)",
        "red_label": "Rejected - incorrect prediction (FP)",
        "green_mask": lambda truth, prediction: (truth == 0) & (prediction == 0),
        "red_mask": lambda truth, prediction: (truth == 0) & (prediction == 1),
    },
    {
        "task": "Task 5.3",
        "slug": "ground_truth_accepted_vs_rejected",
        "green_label": "Ground truth accepted",
        "red_label": "Ground truth rejected",
        "green_mask": lambda truth, prediction: truth == 1,
        "red_mask": lambda truth, prediction: truth == 0,
    },
)

GREEN = "#2f8f55"
RED = "#c44747"
BLUE = "#2f6690"
PURPLE = "#7a5195"
GRAY = "#8a8f98"


def _extended_store(study) -> dict:
    if not hasattr(study, "extended_artifacts"):
        study.extended_artifacts = {}
    return study.extended_artifacts


def _feature_order(study, kind: str | None = None) -> list[str]:
    if kind is not None:
        if not study.task1_artifacts:
            study.run_task1()
        return list(study.task1_artifacts[kind]["training_feature_order"])
    if not study.task3_artifacts:
        study.run_task3()
    return list(study.task3_artifacts["feature_order"])


def _consensus_feature_order(study) -> pd.DataFrame:
    """Borda-style consensus of three training-cohort full-model SHAP rankings."""
    rows = []
    model_orders = {kind: _feature_order(study, kind) for kind in MODEL_SETTINGS}
    for feature in study.config.features:
        ranks = {
            kind: order.index(feature) + 1 for kind, order in model_orders.items()
        }
        rows.append(
            {
                "feature_group": feature,
                **{f"{kind}_rank": rank for kind, rank in ranks.items()},
                "mean_model_rank": float(np.mean(list(ranks.values()))),
                "maximum_model_rank": int(max(ranks.values())),
                "original_position": study.config.features.index(feature),
                "ranking_source": "fixed training cohort; no validation cases used for feature identity",
            }
        )
    return pd.DataFrame(rows).sort_values(
        ["mean_model_rank", "maximum_model_rank", "original_position"]
    ).reset_index(drop=True)


def _minmax(values: np.ndarray) -> np.ndarray:
    values = np.asarray(values, dtype=float)
    finite = np.isfinite(values)
    result = np.zeros_like(values, dtype=float)
    if not finite.any():
        return result
    minimum = float(np.min(values[finite]))
    maximum = float(np.max(values[finite]))
    if maximum > minimum:
        result[finite] = (values[finite] - minimum) / (maximum - minimum)
    return result


def _model_for_groups(study, kind: str, columns: np.ndarray, **overrides):
    settings = dict(MODEL_SETTINGS[kind])
    settings.update(overrides)
    settings["random_state"] = int(settings.get("random_state", study.config.random_state))
    if kind == "logistic_regression":
        model = LogisticRegression(**settings)
    elif kind == "random_forest":
        settings.setdefault("n_jobs", -1)
        model = RandomForestClassifier(**settings)
    elif kind == "neural_network":
        model = MLPClassifier(**settings)
    else:
        raise ValueError(f"Unknown model kind: {kind}")
    model.fit(study.X_train[:, columns], study.y_train)
    return model


def _local_group_columns(study, groups: list[str], selected_columns: np.ndarray) -> dict[str, np.ndarray]:
    lookup = {int(column): position for position, column in enumerate(selected_columns)}
    return {
        group: np.asarray([lookup[int(column)] for column in study.group_indices[group]], dtype=int)
        for group in groups
    }


def _positive_class_tree_shap(study, model, cases: np.ndarray) -> np.ndarray:
    raw = shap.TreeExplainer(model).shap_values(cases, check_additivity=False)
    return np.asarray(study._positive_class_shap_array(raw), dtype=float)


def _neural_grouped_permutation_shap(
    study,
    model,
    cases: np.ndarray,
    background: np.ndarray,
    groups: list[str],
    local_group_columns: dict[str, np.ndarray],
    seed_offset: int,
    permutation_pairs: int | None = None,
) -> np.ndarray:
    """Match Task 1's grouped antithetic permutation-SHAP construction."""
    return grouped_antithetic_permutation_shap(
        model,
        cases,
        background,
        groups,
        local_group_columns,
        seed=study.config.random_state + seed_offset,
        permutation_pairs=(
            study.config.nn_shap_permutation_pairs
            if permutation_pairs is None
            else permutation_pairs
        ),
    )


def _grouped_shap_for_nested_model(
    study,
    model,
    kind: str,
    groups: list[str],
    selected_columns: np.ndarray,
    seed_offset: int,
    probe_indices: np.ndarray | None = None,
    background_indices: np.ndarray | None = None,
) -> np.ndarray:
    probe_indices = study.probe_indices if probe_indices is None else np.asarray(probe_indices, dtype=int)
    background_indices = (
        study.background_indices
        if background_indices is None
        else np.asarray(background_indices, dtype=int)
    )
    cases = study.X_validation[probe_indices][:, selected_columns]
    background = study.X_train[background_indices][:, selected_columns]
    local_columns = _local_group_columns(study, groups, selected_columns)
    selected_grouped = np.zeros((len(cases), len(groups)), dtype=float)
    if kind == "logistic_regression":
        transformed = (cases - background.mean(axis=0)) * np.asarray(model.coef_[0], dtype=float)
        for index, group in enumerate(groups):
            selected_grouped[:, index] = transformed[:, local_columns[group]].sum(axis=1)
    elif kind == "random_forest":
        transformed = _positive_class_tree_shap(study, model, cases)
        for index, group in enumerate(groups):
            selected_grouped[:, index] = transformed[:, local_columns[group]].sum(axis=1)
    elif kind == "neural_network":
        # Keep the coalition sampler in the dataset's declared feature order.
        # At full k this exactly matches Task 1 even though the nested model
        # path itself is ordered by L1 entry and mean absolute SHAP.
        sampling_groups = [feature for feature in study.config.features if feature in groups]
        sampled_grouped = _neural_grouped_permutation_shap(
            study,
            model,
            cases,
            background,
            sampling_groups,
            local_columns,
            seed_offset=seed_offset,
        )
        selected_grouped = np.column_stack([
            sampled_grouped[:, sampling_groups.index(group)] for group in groups
        ])
    else:
        raise ValueError(f"Unknown model kind: {kind}")
    grouped = np.zeros((len(cases), len(study.config.features)), dtype=float)
    for index, group in enumerate(groups):
        grouped[:, study.config.features.index(group)] = selected_grouped[:, index]
    return grouped


def _nested_model_artifact(
    study,
    kind: str,
    groups: list[str],
    *,
    seed_offset: int | None = None,
    model_overrides: dict | None = None,
) -> dict:
    columns = study._indices_for_groups(groups)
    model = _model_for_groups(study, kind, columns, **(model_overrides or {}))
    validation_probabilities = np.asarray(
        model.predict_proba(study.X_validation[:, columns])[:, 1], dtype=float
    )
    predictions = (validation_probabilities >= 0.5).astype(int)
    if seed_offset is None:
        seed_offset = 200 if kind == "neural_network" else 0
    grouped_shap = _grouped_shap_for_nested_model(
        study,
        model,
        kind,
        groups,
        columns,
        seed_offset=seed_offset,
    )
    feature_log, open_traces, closed_traces, _ = study._feature_log_and_traces(
        study.probe_case_ids,
        study.probe_outcomes,
        grouped_shap,
        included_features=groups,
    )
    feature_only_traces = [["START", *trace[1:-1], "END"] for trace in open_traces]
    feature_only_closed = [[*trace, "START"] for trace in feature_only_traces]
    return {
        "kind": kind,
        "groups": list(groups),
        "columns": columns,
        "model": model,
        "validation_probabilities": validation_probabilities,
        "validation_predictions": predictions,
        "probe_probabilities": validation_probabilities[study.probe_indices],
        "probe_predictions": predictions[study.probe_indices],
        "grouped_shap": grouped_shap,
        "feature_log": feature_log,
        "open_traces": open_traces,
        "feature_only_traces": feature_only_traces,
        "feature_only_graph": build_dfg(feature_only_traces),
        "feature_only_closed_graph": build_dfg(feature_only_closed),
    }


def _compact_artifact(artifact: dict) -> dict:
    return {
        key: artifact[key]
        for key in [
            "groups",
            "columns",
            "validation_probabilities",
            "validation_predictions",
            "probe_probabilities",
            "probe_predictions",
            "grouped_shap",
            "feature_only_traces",
            "feature_only_graph",
            "feature_only_closed_graph",
        ]
    }


def _write_feature_only_xes(
    traces: list[list[str]],
    case_ids: np.ndarray,
    truth: np.ndarray,
    predictions: np.ndarray,
    positions: np.ndarray,
    path: Path,
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    root = ET.Element(
        "log",
        {
            "xmlns": "http://www.xes-standard.org/",
            "xes.version": "1.0",
            "xes.features": "nested-attributes",
            "openxes.version": "1.0RC7",
        },
    )
    ET.SubElement(
        root,
        "extension",
        {"name": "Concept", "prefix": "concept", "uri": "http://www.xes-standard.org/concept.xesext"},
    )
    for position in positions:
        trace = ET.SubElement(root, "trace")
        ET.SubElement(trace, "string", {"key": "concept:name", "value": str(case_ids[position])})
        ET.SubElement(trace, "int", {"key": "ground_truth", "value": str(int(truth[position]))})
        ET.SubElement(trace, "int", {"key": "prediction", "value": str(int(predictions[position]))})
        ET.SubElement(
            trace,
            "boolean",
            {"key": "prediction_correct", "value": str(bool(truth[position] == predictions[position])).lower()},
        )
        for sequence, activity in enumerate(traces[position], start=1):
            event = ET.SubElement(trace, "event")
            ET.SubElement(event, "string", {"key": "concept:name", "value": str(activity)})
            ET.SubElement(event, "int", {"key": "sequence", "value": str(sequence)})
    ET.ElementTree(root).write(path, encoding="utf-8", xml_declaration=True)


def _edge_comparison(graph_green: nx.DiGraph, graph_red: nx.DiGraph) -> pd.DataFrame:
    green_raw = edge_weights(graph_green)
    red_raw = edge_weights(graph_red)
    green_norm = normalized_edge_weights(green_raw)
    red_norm = normalized_edge_weights(red_raw)
    rows = []
    for source, target in sorted(set(green_raw).union(red_raw)):
        edge = (source, target)
        green_frequency = float(green_raw.get(edge, 0.0))
        red_frequency = float(red_raw.get(edge, 0.0))
        delta = float(green_norm.get(edge, 0.0) - red_norm.get(edge, 0.0))
        if green_frequency > 0 and red_frequency > 0:
            support = "shared"
        elif green_frequency > 0:
            support = "green_only"
        else:
            support = "red_only"
        rows.append(
            {
                "source": source,
                "target": target,
                "green_frequency": int(round(green_frequency)),
                "red_frequency": int(round(red_frequency)),
                "green_normalized_frequency": float(green_norm.get(edge, 0.0)),
                "red_normalized_frequency": float(red_norm.get(edge, 0.0)),
                "signed_normalized_frequency_difference_green_minus_red": delta,
                "absolute_normalized_frequency_difference": abs(delta),
                "edge_support": support,
            }
        )
    return pd.DataFrame(rows)


def _short_label(node: str) -> str:
    return str(node).replace("Checking ", "").replace("Outcome: ", "")


def _common_layout(graphs: list[nx.DiGraph], seed: int) -> dict[str, np.ndarray]:
    union = nx.DiGraph()
    for graph in graphs:
        union.add_nodes_from(graph.nodes())
        union.add_edges_from(graph.edges())
    if len(union) <= 2:
        return nx.circular_layout(union)
    return nx.spring_layout(union, seed=seed, k=max(0.35, 1.8 / math.sqrt(len(union))))


def _draw_source_graph(axis, graph: nx.DiGraph, positions: dict, title: str, edge_color: str) -> None:
    weights = np.asarray([float(data.get("weight", 0.0)) for _, _, data in graph.edges(data=True)])
    maximum = float(weights.max()) if len(weights) else 1.0
    widths = 0.25 + 2.6 * np.sqrt(weights / maximum) if len(weights) else []
    node_colors = [
        "#f3c969" if node == "START" else "#d9d9d9" if node == "END" else "#a8c7e6"
        for node in graph.nodes()
    ]
    nx.draw_networkx_nodes(graph, positions, ax=axis, node_size=310, node_color=node_colors, linewidths=0.5)
    nx.draw_networkx_edges(
        graph,
        positions,
        ax=axis,
        edge_color=edge_color,
        width=widths,
        alpha=0.34,
        arrows=True,
        arrowsize=7,
        connectionstyle="arc3,rad=0.04",
    )
    nx.draw_networkx_labels(
        graph,
        positions,
        labels={node: _short_label(node) for node in graph.nodes()},
        ax=axis,
        font_size=5.6 if len(graph) > 15 else 7.2,
    )
    axis.set_title(title, fontsize=10)
    axis.axis("off")


def _draw_difference_graph(
    axis,
    comparison: pd.DataFrame,
    positions: dict,
    title: str,
    *,
    frequency_volume: bool,
) -> None:
    graph = nx.DiGraph()
    for row in comparison.itertuples(index=False):
        graph.add_edge(row.source, row.target)
    nx.draw_networkx_nodes(graph, positions, ax=axis, node_size=290, node_color="#e6e9ed", linewidths=0.4)
    nx.draw_networkx_labels(
        graph,
        positions,
        labels={node: _short_label(node) for node in graph.nodes()},
        ax=axis,
        font_size=5.4 if len(graph) > 15 else 7.0,
    )
    if frequency_volume:
        maximum = max(
            float(comparison["absolute_normalized_frequency_difference"].max()), 1e-12
        )
        for support, style in [("shared", "dashed"), ("green_only", "solid"), ("red_only", "solid")]:
            subset = comparison[comparison["edge_support"].eq(support)]
            if subset.empty:
                continue
            edges = list(zip(subset["source"], subset["target"]))
            deltas = subset[
                "signed_normalized_frequency_difference_green_minus_red"
            ].to_numpy(dtype=float)
            colors = [GREEN if delta > 1e-12 else RED if delta < -1e-12 else GRAY for delta in deltas]
            widths = 0.35 + 4.2 * np.sqrt(np.abs(deltas) / maximum)
            nx.draw_networkx_edges(
                graph,
                positions,
                ax=axis,
                edgelist=edges,
                edge_color=colors,
                width=widths,
                style=style,
                alpha=0.86,
                arrows=True,
                arrowsize=8,
                connectionstyle="arc3,rad=0.04",
            )
    else:
        for support, color, width, alpha in [
            ("shared", GRAY, 0.45, 0.18),
            ("green_only", GREEN, 2.1, 0.95),
            ("red_only", RED, 2.1, 0.95),
        ]:
            subset = comparison[comparison["edge_support"].eq(support)]
            nx.draw_networkx_edges(
                graph,
                positions,
                ax=axis,
                edgelist=list(zip(subset["source"], subset["target"])),
                edge_color=color,
                width=width,
                alpha=alpha,
                arrows=True,
                arrowsize=8,
                connectionstyle="arc3,rad=0.04",
            )
    axis.set_title(title, fontsize=10)
    axis.axis("off")


def _three_panel_figure(
    study,
    graph_green: nx.DiGraph,
    graph_red: nx.DiGraph,
    comparison: pd.DataFrame,
    green_label: str,
    red_label: str,
    title: str,
    path: Path,
    *,
    frequency_volume: bool = False,
) -> None:
    positions = _common_layout([graph_green, graph_red], study.config.random_state)
    fig, axes = plt.subplots(1, 3, figsize=(20, 6.3), constrained_layout=True)
    _draw_source_graph(axes[0], graph_green, positions, green_label, GREEN)
    _draw_source_graph(axes[1], graph_red, positions, red_label, RED)
    difference_title = (
        "Signed normalized-frequency difference" if frequency_volume else "Observed edge-presence difference"
    )
    _draw_difference_graph(
        axes[2], comparison, positions, difference_title, frequency_volume=frequency_volume
    )
    axes[2].legend(
        handles=[
            Line2D([0], [0], color=GREEN, lw=2, label="Green group only / greater flow"),
            Line2D([0], [0], color=RED, lw=2, label="Red group only / greater flow"),
            Line2D([0], [0], color=GRAY, lw=1, linestyle="--", label="Shared support"),
        ],
        loc="lower center",
        fontsize=7,
        frameon=False,
    )
    fig.suptitle(title, fontsize=13)
    study._save_show(fig, path, dpi=180)


def run_task5_4(study) -> pd.DataFrame:
    """Plot actual edge-support differences and export viewer-ready XES pairs."""
    if not study.task5_artifacts:
        study.run_task5()
    output_dir = study.root / "task5_4_edge_difference_outputs"
    output_dir.mkdir(exist_ok=True)
    summary_rows = []
    manifest_rows = []
    for model_index, (kind, artifact) in enumerate(study.task1_artifacts.items()):
        truth = artifact["probe_outcomes"].astype(int)
        predictions = artifact["probe_predictions"].astype(int)
        traces = [["START", *trace[1:-1], "END"] for trace in artifact["open_traces"]]
        case_ids = artifact["probe_case_ids"]
        for comparison_index, definition in enumerate(COMPARISONS):
            green_positions = np.flatnonzero(definition["green_mask"](truth, predictions))
            red_positions = np.flatnonzero(definition["red_mask"](truth, predictions))
            graph_green = build_dfg([traces[position] for position in green_positions])
            graph_red = build_dfg([traces[position] for position in red_positions])
            edge_frame = _edge_comparison(graph_green, graph_red)
            comparison_dir = output_dir / kind / definition["slug"]
            comparison_dir.mkdir(parents=True, exist_ok=True)
            edge_frame.to_csv(comparison_dir / "edge_frequency_comparison.csv", index=False)
            study._write_graph(graph_green, comparison_dir / "green_group_open_dfg.graphml")
            study._write_graph(graph_red, comparison_dir / "red_group_open_dfg.graphml")
            green_xes = comparison_dir / f"01_green_{definition['slug']}.xes"
            red_xes = comparison_dir / f"02_red_{definition['slug']}.xes"
            _write_feature_only_xes(traces, case_ids, truth, predictions, green_positions, green_xes)
            _write_feature_only_xes(traces, case_ids, truth, predictions, red_positions, red_xes)
            _three_panel_figure(
                study,
                graph_green,
                graph_red,
                edge_frame,
                definition["green_label"],
                definition["red_label"],
                f"Task 5.4 - {study.MODEL_LABELS[kind]} - {definition['task']}",
                comparison_dir / "edge_presence_difference.png",
            )
            support_counts = edge_frame["edge_support"].value_counts()
            summary_rows.append(
                {
                    "task": definition["task"],
                    "model": kind,
                    "model_label": study.MODEL_LABELS[kind],
                    "green_group": definition["green_label"],
                    "red_group": definition["red_label"],
                    "green_cases": len(green_positions),
                    "red_cases": len(red_positions),
                    "shared_edges": int(support_counts.get("shared", 0)),
                    "green_only_edges": int(support_counts.get("green_only", 0)),
                    "red_only_edges": int(support_counts.get("red_only", 0)),
                    "union_edges": len(edge_frame),
                    "normalized_frequency_l1_distance": 1.0 - l1_dfg_similarity(
                        graph_green, graph_red
                    ),
                }
            )
            manifest_rows.extend(
                [
                    {
                        "task": definition["task"],
                        "model": kind,
                        "color": "green",
                        "group": definition["green_label"],
                        "xes_path": str(green_xes),
                    },
                    {
                        "task": definition["task"],
                        "model": kind,
                        "color": "red",
                        "group": definition["red_label"],
                        "xes_path": str(red_xes),
                    },
                ]
            )
    summary = pd.DataFrame(summary_rows)
    manifest = pd.DataFrame(manifest_rows)
    summary.to_csv(output_dir / "edge_presence_difference_summary.csv", index=False)
    manifest.to_csv(output_dir / "matrix_diff_viewer_xes_pair_manifest.csv", index=False)
    display(summary.round(5))
    _extended_store(study)["task5_4"] = {"summary": summary, "manifest": manifest}
    return summary


def _comparison_artifacts(
    study,
    traces: list[list[str]],
    truth: np.ndarray,
    predictions: np.ndarray,
    case_ids: np.ndarray,
    definition: dict,
    output_dir: Path,
) -> dict:
    green_positions = np.flatnonzero(definition["green_mask"](truth, predictions))
    red_positions = np.flatnonzero(definition["red_mask"](truth, predictions))
    graph_green = build_dfg([traces[position] for position in green_positions])
    graph_red = build_dfg([traces[position] for position in red_positions])
    edge_frame = _edge_comparison(graph_green, graph_red)
    output_dir.mkdir(parents=True, exist_ok=True)
    edge_frame.to_csv(output_dir / "edge_frequency_comparison.csv", index=False)
    study._write_graph(graph_green, output_dir / "green_group_open_dfg.graphml")
    study._write_graph(graph_red, output_dir / "red_group_open_dfg.graphml")
    green_xes = output_dir / "01_green_group.xes"
    red_xes = output_dir / "02_red_group.xes"
    _write_feature_only_xes(traces, case_ids, truth, predictions, green_positions, green_xes)
    _write_feature_only_xes(traces, case_ids, truth, predictions, red_positions, red_xes)
    return {
        "green_positions": green_positions,
        "red_positions": red_positions,
        "green_graph": graph_green,
        "red_graph": graph_red,
        "edge_frame": edge_frame,
        "green_xes": green_xes,
        "red_xes": red_xes,
    }


def run_task5_5_model(study, kind: str) -> pd.DataFrame:
    """Run one model family's nested k=2,...,p Task 5 comparisons."""
    if kind not in MODEL_SETTINGS:
        raise ValueError(f"Unknown model kind: {kind}")
    feature_order = _feature_order(study, kind)
    if len(feature_order) < 2:
        raise ValueError("Task 5.5 requires at least two original feature groups.")
    output_dir = study.root / "task5_5_feature_count_outputs" / kind
    output_dir.mkdir(parents=True, exist_ok=True)
    pd.DataFrame({
        "feature_rank": np.arange(1, len(feature_order) + 1),
        "feature_group": feature_order,
        "ranking_source": f"{study.MODEL_LABELS[kind]} full-model mean absolute grouped SHAP",
    }).to_csv(output_dir / "model_specific_feature_order.csv", index=False)
    performance_rows = []
    subgroup_rows = []
    xes_rows = []
    compact_by_count = {}
    truth = study.probe_outcomes.astype(int)
    case_ids = study.probe_case_ids
    counts = list(range(2, len(feature_order) + 1))
    for count in counts:
        groups = feature_order[:count]
        print(f"Task 5.5 - {study.MODEL_LABELS[kind]}: fitting k={count}/{len(feature_order)}")
        artifact = _nested_model_artifact(study, kind, groups)
        predictions = artifact["probe_predictions"].astype(int)
        traces = artifact["feature_only_traces"]
        count_dir = output_dir / f"feature_count_{count:02d}"
        count_dir.mkdir(exist_ok=True)
        all_xes = count_dir / f"{kind}_k{count:02d}_all_cases_feature_only.xes"
        all_positions = np.arange(len(traces), dtype=int)
        _write_feature_only_xes(traces, case_ids, truth, predictions, all_positions, all_xes)
        study._write_graph(
            artifact["feature_only_graph"], count_dir / f"{kind}_k{count:02d}_all_cases_open_dfg.graphml"
        )
        xes_rows.append(
            {
                "model": kind,
                "feature_group_count": count,
                "task": "all cases",
                "color": "all",
                "xes_path": str(all_xes),
            }
        )
        matrix = confusion_matrix(truth, predictions, labels=[0, 1])
        closed_graph = artifact["feature_only_closed_graph"]
        entropy, normalized_entropy, residual = ks_entropy(closed_graph)
        measures = open_graph_measures(artifact["feature_only_graph"])
        performance_rows.append(
            {
                "model": kind,
                "model_label": study.MODEL_LABELS[kind],
                "model_configuration": MODEL_CONFIGURATION_TEXT[kind],
                "feature_group_count": count,
                "new_feature_group": groups[-1],
                "selected_feature_groups": " | ".join(groups),
                "selected_transformed_features": len(artifact["columns"]),
                **predictive_metrics(
                    study.y_validation, artifact["validation_probabilities"], "validation"
                ),
                "probe_true_negative": int(matrix[0, 0]),
                "probe_false_positive": int(matrix[0, 1]),
                "probe_false_negative": int(matrix[1, 0]),
                "probe_true_positive": int(matrix[1, 1]),
                **measures,
                "ks_entropy_bits_per_transition": entropy,
                "normalized_ks_entropy": normalized_entropy,
                "stationary_residual": residual,
                "training_iterations": int(getattr(artifact["model"], "n_iter_", 0))
                if kind == "neural_network"
                else np.nan,
                "matches_task5_4_predictions_at_full_k": (
                    bool(np.array_equal(
                        predictions,
                        study.task1_artifacts[kind]["probe_predictions"],
                    ))
                    if count == len(feature_order) and kind in study.task1_artifacts
                    else np.nan
                ),
                "matches_task5_4_dfg_at_full_k": (
                    bool(
                        edge_weights(artifact["feature_only_graph"])
                        == edge_weights(build_dfg([
                            ["START", *trace[1:-1], "END"]
                            for trace in study.task1_artifacts[kind]["open_traces"]
                        ]))
                    )
                    if count == len(feature_order) and kind in study.task1_artifacts
                    else np.nan
                ),
            }
        )
        comparison_cache = {}
        for definition in COMPARISONS:
            comparison_dir = count_dir / definition["slug"]
            comparison = _comparison_artifacts(
                study,
                traces,
                truth,
                predictions,
                case_ids,
                definition,
                comparison_dir,
            )
            comparison_cache[definition["slug"]] = comparison
            supports = comparison["edge_frame"]["edge_support"].value_counts()
            subgroup_rows.append(
                {
                    "model": kind,
                    "model_label": study.MODEL_LABELS[kind],
                    "task": definition["task"],
                    "comparison_slug": definition["slug"],
                    "feature_group_count": count,
                    "new_feature_group": groups[-1],
                    "selected_feature_groups": " | ".join(groups),
                    "green_group": definition["green_label"],
                    "red_group": definition["red_label"],
                    "green_cases": len(comparison["green_positions"]),
                    "red_cases": len(comparison["red_positions"]),
                    "shared_edges": int(supports.get("shared", 0)),
                    "green_only_edges": int(supports.get("green_only", 0)),
                    "red_only_edges": int(supports.get("red_only", 0)),
                    "union_edges": len(comparison["edge_frame"]),
                    "normalized_frequency_l1_similarity": l1_dfg_similarity(
                        comparison["green_graph"], comparison["red_graph"]
                    ),
                    "normalized_frequency_l1_distance": 1.0
                    - l1_dfg_similarity(comparison["green_graph"], comparison["red_graph"]),
                    "supervisor_formula_similarity": supervisor_dfg_similarity(
                        comparison["green_graph"], comparison["red_graph"]
                    ),
                }
            )
            xes_rows.extend(
                [
                    {
                        "model": kind,
                        "feature_group_count": count,
                        "task": definition["task"],
                        "color": "green",
                        "xes_path": str(comparison["green_xes"]),
                    },
                    {
                        "model": kind,
                        "feature_group_count": count,
                        "task": definition["task"],
                        "color": "red",
                        "xes_path": str(comparison["red_xes"]),
                    },
                ]
            )
        compact = _compact_artifact(artifact)
        compact["comparisons"] = comparison_cache
        compact_by_count[count] = compact
        del artifact["model"]

    performance = pd.DataFrame(performance_rows).sort_values("feature_group_count").reset_index(drop=True)
    subgroup = pd.DataFrame(subgroup_rows)
    xes_manifest = pd.DataFrame(xes_rows)
    full_graph = compact_by_count[len(feature_order)]["feature_only_graph"]
    performance["all_case_l1_similarity_to_previous_k"] = np.nan
    performance["all_case_l1_similarity_to_full_k"] = [
        l1_dfg_similarity(compact_by_count[count]["feature_only_graph"], full_graph)
        for count in counts
    ]
    for position in range(1, len(performance)):
        previous = counts[position - 1]
        current = counts[position]
        performance.loc[position, "all_case_l1_similarity_to_previous_k"] = l1_dfg_similarity(
            compact_by_count[previous]["feature_only_graph"],
            compact_by_count[current]["feature_only_graph"],
        )
    performance.to_csv(output_dir / "nested_performance_and_dfg.csv", index=False)
    subgroup.to_csv(output_dir / "nested_subgroup_edge_differences.csv", index=False)
    xes_manifest.to_csv(output_dir / "xes_manifest.csv", index=False)

    fig, axes = plt.subplots(2, 2, figsize=(15, 10), constrained_layout=True)
    x = performance["feature_group_count"].to_numpy(dtype=int)
    axes[0, 0].plot(x, 100 * performance["validation_accuracy"], marker="o", label="Accuracy")
    axes[0, 0].plot(
        x, 100 * performance["validation_balanced_accuracy"], marker="s", label="Balanced accuracy"
    )
    axes[0, 0].set_ylabel("Validation score (%)")
    axes[0, 0].legend()
    axes[0, 1].plot(x, performance["validation_roc_auc"], marker="o", color=GREEN)
    axes[0, 1].set_ylabel("Validation ROC AUC")
    axes[1, 0].plot(x, performance["open_dfg_edges"], marker="o", label="Edges")
    entropy_axis = axes[1, 0].twinx()
    entropy_axis.plot(x, performance["ks_entropy_bits_per_transition"], marker="s", color=PURPLE)
    axes[1, 0].set_ylabel("Feature-only DFG edges")
    entropy_axis.set_ylabel("KS entropy")
    for task, group in subgroup.groupby("task"):
        axes[1, 1].plot(
            group["feature_group_count"],
            group["normalized_frequency_l1_distance"],
            marker="o",
            label=task,
        )
    axes[1, 1].set_ylabel("Green-red normalized-frequency L1 distance")
    axes[1, 1].legend()
    for axis in axes.ravel():
        axis.set_xlabel("Number of original feature groups")
        axis.grid(alpha=0.25)
    fig.suptitle(f"Task 5.5 - {study.MODEL_LABELS[kind]} - {study.config.dataset_title}")
    study._save_show(fig, output_dir / "nested_feature_count_summary.png", dpi=200)

    landmarks = sorted({2, max(2, int(round(len(feature_order) / 2))), len(feature_order)})
    for count in landmarks:
        for definition in COMPARISONS:
            comparison = compact_by_count[count]["comparisons"][definition["slug"]]
            _three_panel_figure(
                study,
                comparison["green_graph"],
                comparison["red_graph"],
                comparison["edge_frame"],
                definition["green_label"],
                definition["red_label"],
                f"Task 5.5 - {study.MODEL_LABELS[kind]} - k={count} - {definition['task']}",
                output_dir / f"representative_k{count:02d}_{definition['slug']}.png",
            )
    store = _extended_store(study).setdefault("task5_5", {})
    store[kind] = {
        "performance": performance,
        "subgroup": subgroup,
        "xes_manifest": xes_manifest,
        "artifacts": compact_by_count,
    }
    display(performance.round(5))
    display(subgroup.round(5))
    return performance


def run_task5_5_frequency_volume(study) -> pd.DataFrame:
    """Add signed normalized edge-frequency differences to Task 5.5."""
    store = _extended_store(study)
    task_store = store.setdefault("task5_5", {})
    for kind in MODEL_SETTINGS:
        if kind not in task_store:
            run_task5_5_model(study, kind)
    output_dir = study.root / "task5_5_feature_count_outputs" / "frequency_volume_differences"
    output_dir.mkdir(parents=True, exist_ok=True)
    summary_rows = []
    edge_rows = []
    for kind in MODEL_SETTINGS:
        artifacts = task_store[kind]["artifacts"]
        full_count = max(artifacts)
        for count, artifact in artifacts.items():
            for definition in COMPARISONS:
                comparison = artifact["comparisons"][definition["slug"]]
                frame = comparison["edge_frame"].copy()
                frame.insert(0, "comparison_slug", definition["slug"])
                frame.insert(0, "task", definition["task"])
                frame.insert(0, "feature_group_count", count)
                frame.insert(0, "model", kind)
                edge_rows.append(frame)
                positive_mass = float(
                    frame.loc[
                        frame["signed_normalized_frequency_difference_green_minus_red"] > 0,
                        "signed_normalized_frequency_difference_green_minus_red",
                    ].sum()
                )
                negative_mass = float(
                    -frame.loc[
                        frame["signed_normalized_frequency_difference_green_minus_red"] < 0,
                        "signed_normalized_frequency_difference_green_minus_red",
                    ].sum()
                )
                exclusive = frame["edge_support"].ne("shared")
                summary_rows.append(
                    {
                        "model": kind,
                        "model_label": study.MODEL_LABELS[kind],
                        "task": definition["task"],
                        "comparison_slug": definition["slug"],
                        "feature_group_count": count,
                        "positive_green_frequency_mass": positive_mass,
                        "negative_red_frequency_mass": negative_mass,
                        "total_variation_distance": 0.5
                        * float(frame["absolute_normalized_frequency_difference"].sum()),
                        "exclusive_edge_absolute_difference_mass": 0.5
                        * float(
                            frame.loc[exclusive, "absolute_normalized_frequency_difference"].sum()
                        ),
                        "shared_edge_absolute_difference_mass": 0.5
                        * float(
                            frame.loc[~exclusive, "absolute_normalized_frequency_difference"].sum()
                        ),
                    }
                )
                if count == full_count:
                    _three_panel_figure(
                        study,
                        comparison["green_graph"],
                        comparison["red_graph"],
                        frame,
                        definition["green_label"],
                        definition["red_label"],
                        (
                            f"Task 5.5.4 - {study.MODEL_LABELS[kind]} - k={count} - "
                            f"{definition['task']}"
                        ),
                        output_dir / f"{kind}_k{count:02d}_{definition['slug']}_frequency_volume.png",
                        frequency_volume=True,
                    )
    summary = pd.DataFrame(summary_rows)
    edges = pd.concat(edge_rows, ignore_index=True)
    summary.to_csv(output_dir / "frequency_volume_summary.csv", index=False)
    edges.to_csv(output_dir / "all_signed_edge_frequency_differences.csv", index=False)

    fig, axes = plt.subplots(1, 3, figsize=(18, 5.5), constrained_layout=True)
    for axis, definition in zip(axes, COMPARISONS):
        subset = summary[summary["task"].eq(definition["task"])]
        for kind, group in subset.groupby("model"):
            axis.plot(
                group["feature_group_count"],
                group["total_variation_distance"],
                marker="o",
                label=study.MODEL_LABELS[kind],
            )
        axis.set_title(definition["task"])
        axis.set_xlabel("Number of original feature groups")
        axis.set_ylabel("Signed-flow total variation")
        axis.grid(alpha=0.25)
        axis.legend(fontsize=8)
    fig.suptitle(f"Task 5.5.4: edge frequency-volume differences - {study.config.dataset_title}")
    study._save_show(fig, output_dir / "frequency_volume_across_feature_counts.png", dpi=210)
    store["task5_5_frequency_volume"] = {"summary": summary, "edges": edges}
    display(summary.round(5))
    return summary


def run_task6_3_1(study, bootstraps: int = 1000) -> pd.DataFrame:
    """Explain AIC/BIC disagreement and repeat one-SE screens with probabilities."""
    if not study.task6_artifacts:
        study.run_task6()
    output_dir = study.root / "task6_3_1_outputs"
    output_dir.mkdir(exist_ok=True)
    source = study.task6_artifacts["part1"].sort_values("feature_group_count").reset_index(drop=True).copy()
    counts = source["feature_group_count"].to_numpy(dtype=int)
    deviance = -2.0 * source["training_log_likelihood"].to_numpy(dtype=float)
    ranks = source["design_rank_p"].to_numpy(dtype=float)
    marginal = pd.DataFrame(
        {
            "feature_group_count": counts,
            "training_deviance": deviance,
            "design_rank_p": ranks,
            "deviance_improvement_from_previous": np.r_[np.nan, deviance[:-1] - deviance[1:]],
            "added_design_rank": np.r_[np.nan, np.diff(ranks)],
            "AICc_change_from_previous": np.r_[
                np.nan, np.diff(source["AICc"].to_numpy(dtype=float))
            ],
        }
    )
    marginal["AIC_added_penalty"] = 2.0 * marginal["added_design_rank"]
    marginal["BIC_added_penalty"] = math.log(len(study.y_train)) * marginal["added_design_rank"]
    marginal["AIC_improves_at_step"] = (
        marginal["deviance_improvement_from_previous"] > marginal["AIC_added_penalty"]
    )
    marginal["BIC_improves_at_step"] = (
        marginal["deviance_improvement_from_previous"] > marginal["BIC_added_penalty"]
    )
    marginal.to_csv(output_dir / "marginal_likelihood_and_penalties.csv", index=False)

    k = counts.astype(float)
    minimum_edges = k + 1.0
    maximum_edges = k * (k + 1.0)
    capacity = np.maximum(maximum_edges - minimum_edges, 1.0)
    adjusted = source[[
        "feature_group_count",
        "open_dfg_edges",
        "normalized_ks_entropy",
        "information_distance_p95",
    ]].copy()
    adjusted["excess_edge_occupancy"] = np.clip(
        (adjusted["open_dfg_edges"].to_numpy(dtype=float) - minimum_edges) / capacity,
        0.0,
        1.0,
    )
    adjusted["information_cost_per_rank_transition"] = (
        adjusted["information_distance_p95"].to_numpy(dtype=float) / (k + 1.0)
    )
    adjusted["scaled_excess_edge_occupancy"] = _minmax(adjusted["excess_edge_occupancy"])
    adjusted["scaled_normalized_ks_entropy"] = _minmax(adjusted["normalized_ks_entropy"])
    adjusted["scaled_information_cost_per_rank_transition"] = _minmax(
        adjusted["information_cost_per_rank_transition"]
    )
    adjusted["size_adjusted_dfg_complexity"] = adjusted[[
        "scaled_excess_edge_occupancy",
        "scaled_normalized_ks_entropy",
        "scaled_information_cost_per_rank_transition",
    ]].mean(axis=1)
    adjusted.to_csv(output_dir / "size_adjusted_dfg_complexity.csv", index=False)

    settings = study.task3_artifacts["settings"]
    probabilities = {
        int(count): np.asarray(settings[int(count)]["validation_probabilities"], dtype=float)
        for count in counts
    }
    prediction_export = pd.DataFrame({
        "CaseID": study.validation_data[study.config.case_id_column].astype(str).to_numpy(),
        "ground_truth_accepted": study.y_validation,
        **{f"accepted_probability_k_{count}": values for count, values in probabilities.items()},
    })
    prediction_export.to_csv(output_dir / "validation_case_probabilities.csv", index=False)
    observed = {
        "validation_log_loss": {
            count: float(log_loss(study.y_validation, probability, labels=[0, 1]))
            for count, probability in probabilities.items()
        },
        "validation_roc_auc": {
            count: float(roc_auc_score(study.y_validation, probability))
            for count, probability in probabilities.items()
        },
    }
    rng = np.random.default_rng(study.config.random_state + 63101)
    bootstrap_rows = []
    for bootstrap_id in range(bootstraps):
        sampled = _stratified_bootstrap_indices(study.y_validation, rng)
        sampled_y = study.y_validation[sampled]
        for count in counts:
            sampled_probability = probabilities[int(count)][sampled]
            bootstrap_rows.append(
                {
                    "bootstrap_id": bootstrap_id + 1,
                    "feature_group_count": int(count),
                    "validation_log_loss": float(
                        log_loss(sampled_y, sampled_probability, labels=[0, 1])
                    ),
                    "validation_roc_auc": float(roc_auc_score(sampled_y, sampled_probability)),
                }
            )
    bootstrap = pd.DataFrame(bootstrap_rows)
    bootstrap.to_csv(output_dir / "probability_metric_bootstrap_replicates.csv", index=False)
    selection_rows = []
    analysis_rows = []
    raw_complexity = source.set_index("feature_group_count")["relative_dfg_complexity_index"]
    adjusted_complexity = adjusted.set_index("feature_group_count")["size_adjusted_dfg_complexity"]
    for metric, direction in [("validation_log_loss", "min"), ("validation_roc_auc", "max")]:
        metric_observed = observed[metric]
        best_count = (
            min(metric_observed, key=metric_observed.get)
            if direction == "min"
            else max(metric_observed, key=metric_observed.get)
        )
        best_values = bootstrap.loc[
            bootstrap["feature_group_count"].eq(best_count), metric
        ].to_numpy(dtype=float)
        standard_error = float(np.std(best_values, ddof=1))
        threshold = metric_observed[best_count] + standard_error if direction == "min" else metric_observed[best_count] - standard_error
        candidates = [
            int(count)
            for count in counts
            if (
                metric_observed[int(count)] <= threshold + 1e-15
                if direction == "min"
                else metric_observed[int(count)] >= threshold - 1e-15
            )
        ]
        raw_selected = min(candidates, key=lambda count: (raw_complexity.loc[count], count))
        adjusted_selected = min(
            candidates, key=lambda count: (adjusted_complexity.loc[count], count)
        )
        selection_rows.append(
            {
                "metric": metric,
                "direction": direction,
                "observed_best_feature_count": best_count,
                "observed_best_value": metric_observed[best_count],
                "best_model_bootstrap_standard_error": standard_error,
                "one_se_threshold": threshold,
                "one_se_candidate_counts": " | ".join(map(str, candidates)),
                "raw_dfg_complexity_selected_count": raw_selected,
                "size_adjusted_dfg_complexity_selected_count": adjusted_selected,
                "test_cases_used": False,
            }
        )
        for count in counts:
            analysis_rows.append(
                {
                    "metric": metric,
                    "feature_group_count": int(count),
                    "observed_value": metric_observed[int(count)],
                    "within_one_se_set": int(count) in candidates,
                    "raw_dfg_complexity": float(raw_complexity.loc[int(count)]),
                    "size_adjusted_dfg_complexity": float(adjusted_complexity.loc[int(count)]),
                }
            )
    selection = pd.DataFrame(selection_rows)
    analysis = pd.DataFrame(analysis_rows)
    selection.to_csv(output_dir / "selection_sensitivity_summary.csv", index=False)
    analysis.to_csv(output_dir / "probability_metric_one_se_analysis.csv", index=False)

    fig, axes = plt.subplots(2, 2, figsize=(15, 10), constrained_layout=True)
    axes[0, 0].plot(counts[1:], marginal["deviance_improvement_from_previous"].iloc[1:], marker="o", label="Deviance gain")
    axes[0, 0].plot(counts[1:], marginal["AIC_added_penalty"].iloc[1:], marker="s", label="AIC penalty")
    axes[0, 0].plot(counts[1:], marginal["BIC_added_penalty"].iloc[1:], marker="^", label="BIC penalty")
    axes[0, 0].set_ylabel("Step contribution")
    axes[0, 0].legend()
    axes[0, 1].plot(counts, source["relative_dfg_complexity_index"], marker="o", label="Raw DFG index")
    axes[0, 1].plot(counts, adjusted["size_adjusted_dfg_complexity"], marker="s", label="Size-adjusted index")
    axes[0, 1].set_ylabel("Relative DFG complexity")
    axes[0, 1].legend()
    for axis, metric in zip(axes[1], ["validation_log_loss", "validation_roc_auc"]):
        subset = analysis[analysis["metric"].eq(metric)]
        axis.plot(subset["feature_group_count"], subset["observed_value"], marker="o")
        chosen = selection[selection["metric"].eq(metric)].iloc[0]
        axis.axhline(chosen["one_se_threshold"], color=RED, linestyle="--", label="One-SE threshold")
        axis.set_ylabel(metric.replace("validation_", "").replace("_", " ").title())
        axis.legend()
    for axis in axes.ravel():
        axis.set_xlabel("Number of original feature groups")
        axis.grid(alpha=0.25)
    fig.suptitle(f"Task 6.3.1: why DFG, AIC, and BIC selections differ - {study.config.dataset_title}")
    study._save_show(fig, output_dir / "task6_3_1_likelihood_probability_and_size_adjustment.png", dpi=210)
    display(marginal.round(5))
    display(selection.round(5))
    _extended_store(study)["task6_3_1"] = {
        "marginal": marginal,
        "adjusted": adjusted,
        "selection": selection,
        "analysis": analysis,
    }
    return selection


def _fixed_k_choice(study) -> tuple[int, str]:
    selected = int(study.task3_artifacts["selected_count"])
    path = study.task3_artifacts["path"]
    confirmed = bool(path["bootstrap_confirmed_primary_selection"].iloc[0])
    if confirmed and selected >= 2:
        return selected, "Task 3 bootstrap-confirmed DFG knee"
    part3 = study.task6_artifacts["part3"]
    bic_count = int(part3.loc[part3["BIC"].idxmin(), "feature_group_count"])
    return max(2, bic_count), "minimum BIC because Task 3 had no bootstrap-confirmed interior knee"


def _relative_complexity(frame: pd.DataFrame, prefix: str) -> pd.DataFrame:
    result = frame.copy()
    result[f"{prefix}_connectivity"] = np.mean(
        np.column_stack([
            _minmax(result["rank_excess_edge_occupancy"]),
            _minmax(result["effective_transition_dimension_per_feature"]),
        ]),
        axis=1,
    )
    result[f"{prefix}_transition_uncertainty"] = np.mean(
        np.column_stack([
            _minmax(result["normalized_ks_entropy"]),
            _minmax(result["branching_state_entropy_bits"]),
        ]),
        axis=1,
    )
    result[f"{prefix}_rare_transition_cost"] = _minmax(
        result["information_distance_per_rank_step"]
    )
    result[f"{prefix}_index"] = result[[
        f"{prefix}_connectivity",
        f"{prefix}_transition_uncertainty",
        f"{prefix}_rare_transition_cost",
    ]].mean(axis=1)
    return result


def run_task6_4(study, bootstraps: int = 1000) -> pd.DataFrame:
    """Hold feature count and identity fixed while comparing model families."""
    if not study.task6_artifacts:
        study.run_task6()
    consensus_ranking = _consensus_feature_order(study)
    feature_order = consensus_ranking["feature_group"].tolist()
    fixed_k, selection_source = _fixed_k_choice(study)
    groups = feature_order[:fixed_k]
    output_dir = study.root / "task6_4_fixed_k_model_outputs"
    output_dir.mkdir(exist_ok=True)
    consensus_ranking.to_csv(output_dir / "cross_model_consensus_feature_ranking.csv", index=False)
    rows = []
    artifacts = {}
    for kind in MODEL_SETTINGS:
        print(f"Task 6.4: fitting {study.MODEL_LABELS[kind]} at fixed k={fixed_k}")
        artifact = _nested_model_artifact(study, kind, groups)
        measures = study._graph_measure_row(
            artifact["feature_only_graph"], artifact["feature_only_closed_graph"]
        )
        rows.append(
            {
                "model": kind,
                "model_label": study.MODEL_LABELS[kind],
                "model_configuration": MODEL_CONFIGURATION_TEXT[kind],
                "fixed_feature_group_count": fixed_k,
                "fixed_k_selection_source": selection_source,
                "selected_feature_groups": " | ".join(groups),
                "selected_transformed_features": len(artifact["columns"]),
                **predictive_metrics(
                    study.y_validation, artifact["validation_probabilities"], "validation"
                ),
                **measures,
                "test_cases_used": False,
            }
        )
        study._write_graph(
            artifact["feature_only_graph"], output_dir / f"{kind}_k{fixed_k:02d}_open_dfg.graphml"
        )
        study._write_graph(
            artifact["feature_only_closed_graph"], output_dir / f"{kind}_k{fixed_k:02d}_closed_dfg.graphml"
        )
        artifact["feature_log"].to_csv(
            output_dir / f"{kind}_k{fixed_k:02d}_feature_log.csv", index=False
        )
        artifacts[kind] = _compact_artifact(artifact)
        del artifact["model"]
    result = _relative_complexity(pd.DataFrame(rows), "relative_fixed_k_dfg_complexity")
    primary_measure = study.config.task6_4_primary_complexity_measure
    if primary_measure == "ks_entropy_bits_per_transition":
        primary_column = "ks_entropy_bits_per_transition"
        primary_label = "KS entropy (bits per transition)"
        primary_interpretation = (
            "Empirical Markov entropy rate of the restart-closed feature-only DFG; "
            "lower values indicate more predictable transition routing."
        )
    elif primary_measure == "normalized_ks_entropy":
        primary_column = "normalized_ks_entropy"
        primary_label = "Normalized KS entropy"
        primary_interpretation = (
            "Empirical Markov entropy rate divided by the topology-specific maximum; "
            "lower values indicate more predictable transition routing."
        )
    elif primary_measure == "relative_composite":
        primary_column = "relative_fixed_k_dfg_complexity_index"
        primary_label = "Relative fixed-k DFG complexity"
        primary_interpretation = (
            "Within-experiment composite of connectivity, transition uncertainty, "
            "and rare-transition cost."
        )
    else:
        raise ValueError(
            "task6_4_primary_complexity_measure must be one of "
            "'ks_entropy_bits_per_transition', 'normalized_ks_entropy', or "
            "'relative_composite'."
        )
    result["task6_4_primary_complexity_measure"] = primary_measure
    result["task6_4_primary_complexity_label"] = primary_label
    result["task6_4_primary_complexity"] = result[primary_column].astype(float)
    rng = np.random.default_rng(study.config.random_state + 64001)
    bootstrap_rows = []
    for bootstrap_id in range(bootstraps):
        sampled = _stratified_bootstrap_indices(study.y_validation, rng)
        for kind, artifact in artifacts.items():
            sampled_metrics = predictive_metrics(
                study.y_validation[sampled],
                artifact["validation_probabilities"][sampled],
                "validation",
            )
            bootstrap_rows.append(
                {
                    "bootstrap_id": bootstrap_id + 1,
                    "model": kind,
                    **sampled_metrics,
                }
            )
    bootstrap = pd.DataFrame(bootstrap_rows)
    intervals = []
    for kind, group in bootstrap.groupby("model"):
        row = {"model": kind}
        for metric in ["validation_accuracy", "validation_balanced_accuracy", "validation_roc_auc"]:
            stats = _interval(group[metric].to_numpy())
            row.update({f"bootstrap_{metric}_{key}": value for key, value in stats.items()})
        intervals.append(row)
    result = result.merge(pd.DataFrame(intervals), on="model", how="left")
    result["accuracy_complexity_pareto_efficient"] = True
    for index, row in result.iterrows():
        for other_index, other in result.iterrows():
            if index == other_index:
                continue
            if (
                other["validation_accuracy"] >= row["validation_accuracy"] - 1e-15
                and other["task6_4_primary_complexity"]
                <= row["task6_4_primary_complexity"] + 1e-15
                and (
                    other["validation_accuracy"] > row["validation_accuracy"] + 1e-15
                    or other["task6_4_primary_complexity"]
                    < row["task6_4_primary_complexity"] - 1e-15
                )
            ):
                result.loc[index, "accuracy_complexity_pareto_efficient"] = False
                break
    pair_rows = []
    for left, right in combinations(MODEL_SETTINGS, 2):
        row = {
            "left_model": left,
            "right_model": right,
            "our_similarity_measure": l1_dfg_similarity(
                artifacts[left]["feature_only_graph"], artifacts[right]["feature_only_graph"]
            ),
            "supervisor_formula_similarity": supervisor_dfg_similarity(
                artifacts[left]["feature_only_graph"], artifacts[right]["feature_only_graph"]
            ),
        }
        left_bootstrap = bootstrap[bootstrap["model"].eq(left)].sort_values("bootstrap_id")
        right_bootstrap = bootstrap[bootstrap["model"].eq(right)].sort_values("bootstrap_id")
        for metric in ["validation_accuracy", "validation_balanced_accuracy", "validation_roc_auc"]:
            differences = (
                left_bootstrap[metric].to_numpy(dtype=float)
                - right_bootstrap[metric].to_numpy(dtype=float)
            )
            point_left = float(result.loc[result["model"].eq(left), metric].iloc[0])
            point_right = float(result.loc[result["model"].eq(right), metric].iloc[0])
            row[f"{metric}_difference_left_minus_right"] = point_left - point_right
            stats = _interval(differences)
            row.update({f"{metric}_difference_{key}": value for key, value in stats.items()})
        pair_rows.append(row)
    pairwise_frame = pd.DataFrame(pair_rows)
    result.to_csv(output_dir / "fixed_k_model_performance_and_dfg_complexity.csv", index=False)
    pd.DataFrame(
        [{
            "fixed_feature_group_count": fixed_k,
            "fixed_k_selection_source": selection_source,
            "primary_complexity_measure": primary_measure,
            "primary_complexity_column": primary_column,
            "primary_complexity_label": primary_label,
            "primary_complexity_interpretation": primary_interpretation,
            "relative_composite_retained_as_diagnostic": primary_measure != "relative_composite",
            "pareto_frontier_uses_primary_complexity": True,
        }]
    ).to_csv(output_dir / "task6_4_method_summary.csv", index=False)
    bootstrap.to_csv(output_dir / "paired_accuracy_bootstrap_replicates.csv", index=False)
    pairwise_frame.to_csv(output_dir / "paired_cross_model_differences.csv", index=False)

    fig, axes = plt.subplots(1, 2, figsize=(14, 5.5), constrained_layout=True)
    x = np.arange(len(result))
    labels = result["model_label"].tolist()
    axes[0].bar(x - 0.18, 100 * result["validation_accuracy"], 0.36, label="Accuracy")
    axes[0].bar(x + 0.18, 100 * result["validation_balanced_accuracy"], 0.36, label="Balanced accuracy")
    axes[0].set_xticks(x, labels, rotation=18, ha="right")
    axes[0].set_ylabel("Validation score (%)")
    axes[0].legend()
    scatter = axes[1].scatter(
        result["task6_4_primary_complexity"],
        100 * result["validation_accuracy"],
        c=np.arange(len(result)),
        cmap="viridis",
        s=90,
    )
    for row in result.itertuples(index=False):
        axes[1].annotate(
            row.model_label,
            (row.task6_4_primary_complexity, 100 * row.validation_accuracy),
            xytext=(5, 5),
            textcoords="offset points",
        )
    axes[1].set_xlabel(primary_label)
    axes[1].set_ylabel("Validation accuracy (%)")
    for axis in axes:
        axis.grid(alpha=0.25)
    fig.suptitle(f"Task 6.4: fixed k={fixed_k} across model families - {study.config.dataset_title}")
    study._save_show(fig, output_dir / "task6_4_accuracy_vs_dfg_complexity.png", dpi=210)

    positions = _common_layout([artifact["feature_only_graph"] for artifact in artifacts.values()], study.config.random_state)
    fig, axes = plt.subplots(1, 3, figsize=(19, 6), constrained_layout=True)
    for axis, kind in zip(axes, MODEL_SETTINGS):
        _draw_source_graph(
            axis,
            artifacts[kind]["feature_only_graph"],
            positions,
            study.MODEL_LABELS[kind],
            BLUE,
        )
    fig.suptitle(f"Task 6.4: explanation DFGs at fixed k={fixed_k} - {study.config.dataset_title}")
    study._save_show(fig, output_dir / "task6_4_fixed_k_model_dfgs.png", dpi=190)
    display(result.round(5))
    display(pairwise_frame.round(5))
    _extended_store(study)["task6_4"] = {
        "fixed_k": fixed_k,
        "selection_source": selection_source,
        "groups": groups,
        "primary_complexity_measure": primary_measure,
        "primary_complexity_label": primary_label,
        "result": result,
        "artifacts": artifacts,
        "pairwise": pairwise_frame,
    }
    return result


def _mlp_parameter_count(model: MLPClassifier) -> int:
    return int(sum(array.size for array in model.coefs_) + sum(array.size for array in model.intercepts_))


def run_task6_5(study, bootstraps: int = 1000) -> pd.DataFrame:
    """Cross neural-network depth and width at the Task 6.4 fixed feature set."""
    store = _extended_store(study)
    if "task6_4" not in store:
        run_task6_4(study, bootstraps=bootstraps)
    fixed = store["task6_4"]
    fixed_k = int(fixed["fixed_k"])
    groups = list(fixed["groups"])
    output_dir = study.root / "task6_5_nn_depth_width_outputs"
    output_dir.mkdir(exist_ok=True)
    depths = [1, 2, 3]
    widths = [16, 32, 64]
    seeds = [study.config.random_state, study.config.random_state + 1000, study.config.random_state + 2000]
    canonical_rows = []
    seed_rows = []
    seed_dfg_rows = []
    artifacts = {}
    predictions_by_architecture = {}
    columns = study._indices_for_groups(groups)
    for depth in depths:
        for width in widths:
            architecture = tuple(max(2, width // (2**layer)) for layer in range(depth))
            key = f"L{depth}_W{width}"
            canonical_model = None
            architecture_predictions = []
            for seed in seeds:
                model = _model_for_groups(
                    study,
                    "neural_network",
                    columns,
                    hidden_layer_sizes=architecture,
                    random_state=seed,
                )
                probabilities = np.asarray(
                    model.predict_proba(study.X_validation[:, columns])[:, 1], dtype=float
                )
                architecture_predictions.append((seed, probabilities))
                seed_rows.append(
                    {
                        "architecture_key": key,
                        "depth": depth,
                        "initial_width": width,
                        "hidden_layer_sizes": str(architecture),
                        "training_seed": seed,
                        "trainable_parameters": _mlp_parameter_count(model),
                        "training_iterations": int(model.n_iter_),
                        **predictive_metrics(study.y_validation, probabilities, "validation"),
                    }
                )
                diagnostic_grouped_shap = _grouped_shap_for_nested_model(
                    study,
                    model,
                    "neural_network",
                    groups,
                    columns,
                    seed_offset=265,
                    probe_indices=study.sweep_probe_indices,
                    background_indices=study.sweep_background_indices,
                )
                diagnostic_case_ids = study.validation_data.iloc[study.sweep_probe_indices][
                    study.config.case_id_column
                ].to_numpy(dtype=object)
                diagnostic_outcomes = study.y_validation[study.sweep_probe_indices]
                _, diagnostic_endpoint_traces, _, _ = study._feature_log_and_traces(
                    diagnostic_case_ids,
                    diagnostic_outcomes,
                    diagnostic_grouped_shap,
                    included_features=groups,
                )
                diagnostic_traces = feature_only_traces(diagnostic_endpoint_traces)
                diagnostic_closed = [[*trace, "START"] for trace in diagnostic_traces]
                seed_dfg_rows.append(
                    {
                        "architecture_key": key,
                        "training_seed": seed,
                        **study._graph_measure_row(
                            build_dfg(diagnostic_traces), build_dfg(diagnostic_closed)
                        ),
                    }
                )
                if seed == study.config.random_state:
                    canonical_model = model
            predictions_by_architecture[key] = architecture_predictions
            print(f"Task 6.5: explaining {key} {architecture} at fixed k={fixed_k}")
            grouped_shap = _grouped_shap_for_nested_model(
                study,
                canonical_model,
                "neural_network",
                groups,
                columns,
                seed_offset=200,
            )
            feature_log, open_traces, _, _ = study._feature_log_and_traces(
                study.probe_case_ids,
                study.probe_outcomes,
                grouped_shap,
                included_features=groups,
            )
            traces = [["START", *trace[1:-1], "END"] for trace in open_traces]
            graph = build_dfg(traces)
            closed_graph = build_dfg([[*trace, "START"] for trace in traces])
            probabilities = np.asarray(
                canonical_model.predict_proba(study.X_validation[:, columns])[:, 1], dtype=float
            )
            graph_measures = study._graph_measure_row(graph, closed_graph)
            canonical_rows.append(
                {
                    "architecture_key": key,
                    "depth": depth,
                    "initial_width": width,
                    "hidden_layer_sizes": str(architecture),
                    "fixed_feature_group_count": fixed_k,
                    "selected_feature_groups": " | ".join(groups),
                    "trainable_parameters": _mlp_parameter_count(canonical_model),
                    "training_iterations": int(canonical_model.n_iter_),
                    **predictive_metrics(study.y_validation, probabilities, "validation"),
                    **graph_measures,
                    "test_cases_used": False,
                }
            )
            feature_log.to_csv(output_dir / f"{key}_feature_log.csv", index=False)
            study._write_graph(graph, output_dir / f"{key}_open_dfg.graphml")
            study._write_graph(closed_graph, output_dir / f"{key}_closed_dfg.graphml")
            artifacts[key] = {
                "graph": graph,
                "closed_graph": closed_graph,
                "probabilities": probabilities,
                "predictions": (probabilities >= 0.5).astype(int),
            }
    canonical = _relative_complexity(pd.DataFrame(canonical_rows), "relative_architecture_dfg_complexity")
    seed_frame = pd.DataFrame(seed_rows)
    seed_dfg_frame = _relative_complexity(
        pd.DataFrame(seed_dfg_rows), "relative_seed_dfg_complexity"
    )
    seed_summary = seed_frame.groupby("architecture_key").agg(
        accuracy_across_seed_mean=("validation_accuracy", "mean"),
        accuracy_across_seed_sd=("validation_accuracy", "std"),
        roc_auc_across_seed_mean=("validation_roc_auc", "mean"),
        roc_auc_across_seed_sd=("validation_roc_auc", "std"),
    ).reset_index()
    seed_dfg_summary = seed_dfg_frame.groupby("architecture_key").agg(
        dfg_complexity_across_seed_mean=("relative_seed_dfg_complexity_index", "mean"),
        dfg_complexity_across_seed_sd=("relative_seed_dfg_complexity_index", "std"),
        normalized_ks_entropy_across_seed_mean=("normalized_ks_entropy", "mean"),
        rank_excess_edge_occupancy_across_seed_mean=("rank_excess_edge_occupancy", "mean"),
    ).reset_index()
    canonical = canonical.merge(seed_summary, on="architecture_key", how="left").merge(
        seed_dfg_summary, on="architecture_key", how="left"
    )
    rng = np.random.default_rng(study.config.random_state + 65001)
    bootstrap_rows = []
    for bootstrap_id in range(bootstraps):
        sampled = _stratified_bootstrap_indices(study.y_validation, rng)
        for key, seed_predictions in predictions_by_architecture.items():
            seed_accuracies = [
                accuracy_score(
                    study.y_validation[sampled],
                    (probabilities[sampled] >= 0.5).astype(int),
                )
                for _, probabilities in seed_predictions
            ]
            bootstrap_rows.append(
                {
                    "bootstrap_id": bootstrap_id + 1,
                    "architecture_key": key,
                    "mean_accuracy_across_training_seeds": float(np.mean(seed_accuracies)),
                }
            )
    bootstrap = pd.DataFrame(bootstrap_rows)
    best_row = canonical.loc[canonical["accuracy_across_seed_mean"].idxmax()]
    best_key = str(best_row["architecture_key"])
    best_values = bootstrap.loc[
        bootstrap["architecture_key"].eq(best_key), "mean_accuracy_across_training_seeds"
    ]
    case_bootstrap_standard_error = float(best_values.std(ddof=1))
    seed_mean_standard_error = float(best_row["accuracy_across_seed_sd"] / math.sqrt(len(seeds)))
    combined_standard_error = float(
        math.sqrt(case_bootstrap_standard_error**2 + seed_mean_standard_error**2)
    )
    threshold = float(best_row["accuracy_across_seed_mean"] - combined_standard_error)
    canonical["within_one_se_set"] = (
        canonical["accuracy_across_seed_mean"] >= threshold - 1e-15
    )
    candidates = canonical[canonical["within_one_se_set"]]
    selected = candidates.sort_values(
        [
            "dfg_complexity_across_seed_mean",
            "trainable_parameters",
            "depth",
            "initial_width",
        ]
    ).iloc[0]
    canonical["selected_by_one_se_dfg_simplicity"] = canonical["architecture_key"].eq(
        selected["architecture_key"]
    )
    selection = pd.DataFrame(
        [
            {
                "fixed_feature_group_count": fixed_k,
                "best_accuracy_architecture": best_key,
                "best_validation_accuracy_across_seed_mean": float(
                    best_row["accuracy_across_seed_mean"]
                ),
                "best_case_bootstrap_standard_error": case_bootstrap_standard_error,
                "best_training_seed_mean_standard_error": seed_mean_standard_error,
                "best_combined_standard_error": combined_standard_error,
                "one_se_threshold": threshold,
                "one_se_architectures": " | ".join(candidates["architecture_key"]),
                "selected_architecture": selected["architecture_key"],
                "selected_hidden_layer_sizes": selected["hidden_layer_sizes"],
                "selected_validation_accuracy_across_seed_mean": float(
                    selected["accuracy_across_seed_mean"]
                ),
                "selected_dfg_complexity_across_seed_mean": float(
                    selected["dfg_complexity_across_seed_mean"]
                ),
                "selection_rule": (
                    "minimum mean diagnostic DFG complexity inside the one-SE set of "
                    "mean validation accuracy across three training seeds"
                ),
                "test_cases_used": False,
            }
        ]
    )
    depth_means = canonical.groupby("depth", as_index=False).agg(
        validation_accuracy_mean=("accuracy_across_seed_mean", "mean"),
        dfg_complexity_mean=("dfg_complexity_across_seed_mean", "mean"),
        trainable_parameters_mean=("trainable_parameters", "mean"),
    )
    width_means = canonical.groupby("initial_width", as_index=False).agg(
        validation_accuracy_mean=("accuracy_across_seed_mean", "mean"),
        dfg_complexity_mean=("dfg_complexity_across_seed_mean", "mean"),
        trainable_parameters_mean=("trainable_parameters", "mean"),
    )
    canonical.to_csv(output_dir / "nn_depth_width_accuracy_dfg_complexity.csv", index=False)
    seed_frame.to_csv(output_dir / "nn_depth_width_training_seed_results.csv", index=False)
    seed_dfg_frame.to_csv(output_dir / "nn_depth_width_seed_dfg_diagnostics.csv", index=False)
    bootstrap.to_csv(output_dir / "paired_accuracy_bootstrap_replicates.csv", index=False)
    selection.to_csv(output_dir / "architecture_selection_summary.csv", index=False)
    depth_means.to_csv(output_dir / "depth_marginal_means.csv", index=False)
    width_means.to_csv(output_dir / "width_marginal_means.csv", index=False)

    fig, axes = plt.subplots(1, 3, figsize=(17, 5.5), constrained_layout=True)
    for axis, value, title, cmap in [
        (axes[0], "accuracy_across_seed_mean", "Validation accuracy across seeds", "YlGn"),
        (axes[1], "dfg_complexity_across_seed_mean", "DFG complexity across seeds", "YlOrRd"),
        (axes[2], "trainable_parameters", "Trainable parameters", "Blues"),
    ]:
        matrix = canonical.pivot(index="depth", columns="initial_width", values=value).loc[depths, widths]
        image = axis.imshow(matrix, cmap=cmap, aspect="auto")
        for row in range(len(depths)):
            for column in range(len(widths)):
                number = matrix.iloc[row, column]
                text = (
                    f"{100 * number:.2f}%"
                    if value == "accuracy_across_seed_mean"
                    else f"{number:.3f}"
                    if value == "dfg_complexity_across_seed_mean"
                    else f"{int(number):,}"
                )
                axis.text(column, row, text, ha="center", va="center", fontsize=8)
        axis.set_xticks(range(len(widths)), widths)
        axis.set_yticks(range(len(depths)), depths)
        axis.set_xlabel("Initial width")
        axis.set_ylabel("Hidden-layer depth")
        axis.set_title(title)
        fig.colorbar(image, ax=axis, shrink=0.75)
    fig.suptitle(f"Task 6.5: neural-network depth versus width - {study.config.dataset_title}")
    study._save_show(fig, output_dir / "task6_5_depth_width_heatmaps.png", dpi=210)

    all_graphs = [artifacts[f"L{depth}_W{width}"]["graph"] for depth in depths for width in widths]
    positions = _common_layout(all_graphs, study.config.random_state)
    fig, axes = plt.subplots(3, 3, figsize=(18, 17), constrained_layout=True)
    for row, depth in enumerate(depths):
        for column, width in enumerate(widths):
            key = f"L{depth}_W{width}"
            _draw_source_graph(axes[row, column], artifacts[key]["graph"], positions, key, BLUE)
    fig.suptitle(f"Task 6.5: fixed-k explanation DFGs - {study.config.dataset_title}")
    study._save_show(fig, output_dir / "task6_5_depth_width_dfg_grid.png", dpi=175)

    fig, axes = plt.subplots(1, 2, figsize=(14, 5.5), constrained_layout=True)
    scatter = axes[0].scatter(
        canonical["dfg_complexity_across_seed_mean"],
        100 * canonical["accuracy_across_seed_mean"],
        c=canonical["trainable_parameters"],
        cmap="viridis",
        s=80,
    )
    for row in canonical.itertuples(index=False):
        axes[0].annotate(
            row.architecture_key,
            (row.dfg_complexity_across_seed_mean, 100 * row.accuracy_across_seed_mean),
            xytext=(4, 4),
            textcoords="offset points",
            fontsize=8,
        )
    fig.colorbar(scatter, ax=axes[0], label="Trainable parameters")
    axes[0].set_xlabel("Mean diagnostic DFG complexity across seeds")
    axes[0].set_ylabel("Mean validation accuracy across seeds (%)")
    axes[1].errorbar(
        canonical["trainable_parameters"],
        100 * canonical["accuracy_across_seed_mean"],
        yerr=100 * canonical["accuracy_across_seed_sd"].fillna(0.0),
        fmt="o",
    )
    axes[1].set_xscale("log")
    axes[1].set_xlabel("Trainable parameters (log scale)")
    axes[1].set_ylabel("Accuracy across seeds (%)")
    for axis in axes:
        axis.grid(alpha=0.25)
    fig.suptitle(f"Task 6.5: accuracy, capacity, and DFG simplicity - {study.config.dataset_title}")
    study._save_show(fig, output_dir / "task6_5_accuracy_complexity_tradeoffs.png", dpi=210)
    display(canonical.round(5))
    display(selection.round(5))
    store["task6_5"] = {
        "result": canonical,
        "selection": selection,
        "artifacts": artifacts,
        "seeds": seed_frame,
        "seed_dfg": seed_dfg_frame,
    }
    return canonical


def _transition_profile(graph: nx.DiGraph) -> tuple[pd.DataFrame, dict[str, float]]:
    rows = []
    q_effective = 0.0
    q_support = 0.0
    frequency_penalty = 0.0
    support_penalty = 0.0
    for node in graph.nodes():
        outgoing = list(graph.out_edges(node, data=True))
        frequencies = np.asarray(
            [float(data.get("weight", data.get("frequency", 0.0))) for _, _, data in outgoing],
            dtype=float,
        )
        total = float(frequencies.sum())
        if total <= 0:
            continue
        probabilities = frequencies / total
        positive = probabilities > 0
        entropy_bits = float(-np.sum(probabilities[positive] * np.log2(probabilities[positive])))
        effective_successors = float(np.exp2(entropy_bits))
        support_successors = int(len(probabilities))
        effective_dimension = max(0.0, effective_successors - 1.0)
        support_dimension = max(0, support_successors - 1)
        node_frequency_penalty = effective_dimension * math.log(total)
        node_support_penalty = support_dimension * math.log(total)
        q_effective += effective_dimension
        q_support += support_dimension
        frequency_penalty += node_frequency_penalty
        support_penalty += node_support_penalty
        rows.append(
            {
                "source_node": node,
                "outgoing_observations_N_u": total,
                "outgoing_support_d_u": support_successors,
                "entropy_bits_H_u": entropy_bits,
                "entropy_effective_successors": effective_successors,
                "effective_transition_dimension": effective_dimension,
                "support_transition_dimension": support_dimension,
                "frequency_sensitive_node_penalty": node_frequency_penalty,
                "support_node_penalty": node_support_penalty,
            }
        )
    return pd.DataFrame(rows), {
        "effective_transition_dimension_q": q_effective,
        "support_transition_dimension_q": q_support,
        "frequency_sensitive_dfg_penalty": frequency_penalty,
        "exact_support_dfg_penalty": support_penalty,
    }


def _exact_lower_envelope(intercepts: np.ndarray, slopes: np.ndarray, counts: np.ndarray) -> pd.DataFrame:
    boundaries = {0.0}
    for left, right in combinations(range(len(counts)), 2):
        denominator = slopes[left] - slopes[right]
        if abs(denominator) <= 1e-15:
            continue
        crossing = (intercepts[right] - intercepts[left]) / denominator
        if crossing > 0 and np.isfinite(crossing):
            boundaries.add(float(crossing))
    ordered = sorted(boundaries)
    intervals = []
    for index, lower in enumerate(ordered):
        upper = ordered[index + 1] if index + 1 < len(ordered) else np.inf
        probe = (lower + upper) / 2 if np.isfinite(upper) else lower + max(1.0, 0.1 * max(1.0, lower))
        selected = int(counts[np.argmin(intercepts + probe * slopes)])
        if intervals and intervals[-1]["selected_feature_group_count"] == selected:
            intervals[-1]["lambda_upper"] = upper
        else:
            intervals.append(
                {
                    "selected_feature_group_count": selected,
                    "lambda_lower": lower,
                    "lambda_upper": upper,
                }
            )
    return pd.DataFrame(intervals)


def _task7_full_pipeline_retraining(study, counts: np.ndarray) -> dict[str, object]:
    """Run the shared Task 7/7.1 retraining-and-reranking bootstrap once."""
    store = _extended_store(study)
    cached = store.get("task7_shared_full_pipeline")
    if cached is not None and np.array_equal(cached["counts"], counts):
        return cached

    full_pipeline_count = int(study.config.task7_full_pipeline_bootstraps)
    rng = np.random.default_rng(study.config.random_state + 77002)
    rows = []
    order_rows = []
    all_groups = list(study.config.features)
    all_columns = study._indices_for_groups(all_groups)
    reference_order = list(study.task3_artifacts["feature_order"])
    reference_position = {
        feature: position for position, feature in enumerate(reference_order)
    }
    ranking_cases = study.X_train[study.ranking_indices]
    probe_cases = study.X_validation[study.probe_indices]
    fixed_background = study.X_train[study.background_indices]
    for bootstrap_id in range(full_pipeline_count):
        sampled = _stratified_bootstrap_indices(study.y_train, rng)
        bootstrap_X = study.X_train[sampled]
        bootstrap_y = study.y_train[sampled]
        ranking_model = LogisticRegression(
            C=np.inf,
            solver="lbfgs",
            max_iter=5000,
            random_state=study.config.random_state + 88000 + bootstrap_id,
        ).fit(bootstrap_X[:, all_columns], bootstrap_y)
        ranking_shap = study._linear_grouped_shap(
            ranking_model,
            all_columns,
            ranking_cases,
            fixed_background,
        )
        ranking_mean_abs = np.mean(np.abs(ranking_shap), axis=0)
        replicate_order = sorted(
            all_groups,
            key=lambda feature: (
                -float(ranking_mean_abs[study.config.features.index(feature)]),
                reference_position[feature],
            ),
        )
        for rank, feature in enumerate(replicate_order, start=1):
            order_rows.append(
                {
                    "bootstrap_id": bootstrap_id + 1,
                    "feature_rank": rank,
                    "feature_group": feature,
                    "training_mean_abs_grouped_shap": float(
                        ranking_mean_abs[study.config.features.index(feature)]
                    ),
                }
            )

        for count in counts:
            groups = replicate_order[: int(count)]
            columns = study._indices_for_groups(groups)
            model = LogisticRegression(
                C=np.inf,
                solver="lbfgs",
                max_iter=5000,
                random_state=study.config.random_state + 89000 + bootstrap_id,
            ).fit(bootstrap_X[:, columns], bootstrap_y)
            probabilities = np.clip(
                model.predict_proba(bootstrap_X[:, columns])[:, 1],
                1e-12,
                1 - 1e-12,
            )
            log_likelihood = float(
                np.sum(
                    bootstrap_y * np.log(probabilities)
                    + (1 - bootstrap_y) * np.log(1 - probabilities)
                )
            )
            design_rank = int(study._design_rank(bootstrap_X, columns))
            bootstrap_bic = math.log(len(bootstrap_y)) * design_rank - 2.0 * log_likelihood
            grouped_shap = study._linear_grouped_shap(
                model,
                columns,
                probe_cases,
                fixed_background,
            )
            _, endpoint_traces, _, _ = study._feature_log_and_traces(
                study.probe_case_ids,
                study.probe_outcomes,
                grouped_shap,
                included_features=groups,
            )
            analysis_traces = feature_only_traces(endpoint_traces)
            open_graph = build_dfg(analysis_traces)
            closed_graph = build_dfg([[*trace, "START"] for trace in analysis_traces])
            _, graph_summary = _transition_profile(open_graph)
            entropy = markov_entropy_measures(closed_graph)
            entropy_bits = float(entropy["ks_entropy_bits_per_transition"])
            rows.append(
                {
                    "bootstrap_id": bootstrap_id + 1,
                    "feature_group_count": int(count),
                    "included_feature_groups": " | ".join(groups),
                    "bootstrap_feature_order": " | ".join(replicate_order),
                    "bootstrap_design_rank_p": design_rank,
                    "bootstrap_BIC": float(bootstrap_bic),
                    "bootstrap_ks_entropy_bits_per_transition": entropy_bits,
                    "bootstrap_frequency_sensitive_dfg_penalty": float(
                        graph_summary["frequency_sensitive_dfg_penalty"]
                    ),
                    "bootstrap_exact_support_dfg_penalty": float(
                        graph_summary["exact_support_dfg_penalty"]
                    ),
                }
            )
        if (bootstrap_id + 1) % 10 == 0 or bootstrap_id == 0:
            print(
                "Tasks 7/7.1 shared full-pipeline bootstrap "
                f"{bootstrap_id + 1}/{full_pipeline_count}"
            )

    cached = {
        "counts": np.asarray(counts, dtype=int).copy(),
        "replicates": pd.DataFrame(rows),
        "feature_orders": pd.DataFrame(order_rows),
        "bootstrap_count": full_pipeline_count,
    }
    store["task7_shared_full_pipeline"] = cached
    return cached


def run_task7(study, bootstraps: int = 2000, default_lambda: float = 1.0) -> pd.DataFrame:
    """Evaluate BIC plus the pure stationary-weighted KS entropy rate."""
    if not study.task6_artifacts:
        study.run_task6()
    output_dir = study.root / "task7_pure_ks_bic_outputs"
    output_dir.mkdir(exist_ok=True)
    source = (
        study.task6_artifacts["part1"]
        .sort_values("feature_group_count")
        .reset_index(drop=True)
        .copy()
    )
    counts = source["feature_group_count"].to_numpy(dtype=int)
    settings = study.task3_artifacts["settings"]
    candidate_rows = []
    for count in counts:
        source_row = source[source["feature_group_count"].eq(count)].iloc[0]
        entropy = markov_entropy_measures(settings[int(count)]["analysis_closed_graph"])
        entropy_bits = float(entropy["ks_entropy_bits_per_transition"])
        candidate_rows.append(
            {
                "feature_group_count": int(count),
                "included_feature_groups": source_row["included_feature_groups"],
                "training_log_likelihood": float(source_row["training_log_likelihood"]),
                "design_rank_p": int(source_row["design_rank_p"]),
                "training_deviance": -2.0 * float(source_row["training_log_likelihood"]),
                "coefficient_BIC_penalty": int(source_row["design_rank_p"])
                * math.log(len(study.y_train)),
                "BIC": float(source_row["BIC"]),
                "ks_entropy_bits_per_transition": entropy_bits,
                "normalized_ks_entropy": float(entropy["normalized_ks_entropy"]),
                "stationary_residual": float(entropy["stationary_residual"]),
                "validation_accuracy": float(source_row["validation_accuracy"]),
                "validation_roc_auc": float(source_row["validation_roc_auc"]),
            }
        )
    candidates = pd.DataFrame(candidate_rows)
    candidates["weighted_ks_entropy_penalty_default_lambda"] = (
        default_lambda * candidates["ks_entropy_bits_per_transition"]
    )
    candidates["pure_KS_BIC_default_lambda"] = (
        candidates["BIC"]
        + candidates["weighted_ks_entropy_penalty_default_lambda"]
    )
    bic_selected = int(candidates.loc[candidates["BIC"].idxmin(), "feature_group_count"])
    selected_count = int(
        candidates.loc[
            candidates["pure_KS_BIC_default_lambda"].idxmin(), "feature_group_count"
        ]
    )
    candidates["selected_by_BIC"] = candidates["feature_group_count"].eq(bic_selected)
    candidates["selected_by_pure_KS_BIC"] = candidates["feature_group_count"].eq(
        selected_count
    )
    candidates["delta_BIC"] = candidates["BIC"] - candidates["BIC"].min()
    candidates["delta_pure_KS_BIC"] = (
        candidates["pure_KS_BIC_default_lambda"]
        - candidates["pure_KS_BIC_default_lambda"].min()
    )
    candidates["ks_induced_delta_difference"] = (
        candidates["delta_pure_KS_BIC"] - candidates["delta_BIC"]
    )
    candidates.to_csv(output_dir / "pure_ks_entropy_penalized_bic_results.csv", index=False)

    intercepts = candidates["BIC"].to_numpy(dtype=float)
    slopes = candidates["ks_entropy_bits_per_transition"].to_numpy(dtype=float)
    envelope = _exact_lower_envelope(intercepts, slopes, counts)
    envelope.to_csv(output_dir / "exact_lambda_selection_intervals.csv", index=False)
    selected_interval = envelope[
        (envelope["lambda_lower"] <= default_lambda + 1e-15)
        & (envelope["lambda_upper"] > default_lambda - 1e-15)
    ].iloc[0]
    finite_upper = envelope["lambda_upper"].replace(np.inf, np.nan).max()
    lambda_max = max(
        8.0,
        float(finite_upper) * 1.15 if np.isfinite(finite_upper) else 8.0,
    )
    lambda_rows = []
    for value in np.linspace(0.0, lambda_max, 241):
        scores = intercepts + value * slopes
        selected = int(counts[np.argmin(scores)])
        for count, score in zip(counts, scores):
            lambda_rows.append(
                {
                    "lambda": float(value),
                    "feature_group_count": int(count),
                    "pure_KS_BIC": float(score),
                    "selected": int(count) == selected,
                }
            )
    lambda_path = pd.DataFrame(lambda_rows)
    lambda_path.to_csv(output_dir / "pure_ks_bic_lambda_path.csv", index=False)

    rng = np.random.default_rng(study.config.random_state + 76901)
    bootstrap_rows = []
    selection_counts = Counter()
    case_count = len(study.probe_case_ids)
    for bootstrap_id in range(bootstraps):
        sampled = rng.choice(case_count, size=case_count, replace=True)
        replicate_entropy = []
        for count in counts:
            traces = [
                settings[int(count)]["analysis_traces"][position] for position in sampled
            ]
            closed_graph = build_dfg([[*trace, "START"] for trace in traces])
            entropy_bits = float(
                markov_entropy_measures(closed_graph)["ks_entropy_bits_per_transition"]
            )
            replicate_entropy.append(entropy_bits)
            bootstrap_rows.append(
                {
                    "bootstrap_id": bootstrap_id + 1,
                    "feature_group_count": int(count),
                    "ks_entropy_bits_per_transition": entropy_bits,
                }
            )
        scores = intercepts + default_lambda * np.asarray(replicate_entropy, dtype=float)
        selection_counts[int(counts[np.argmin(scores)])] += 1
    bootstrap = pd.DataFrame(bootstrap_rows)
    bootstrap.to_csv(output_dir / "paired_ks_entropy_bootstrap_replicates.csv", index=False)
    interval_rows = []
    for count, group in bootstrap.groupby("feature_group_count"):
        stats = _interval(group["ks_entropy_bits_per_transition"].to_numpy())
        interval_rows.append(
            {
                "feature_group_count": int(count),
                **{f"ks_entropy_bits_{key}": value for key, value in stats.items()},
            }
        )
    intervals = pd.DataFrame(interval_rows)
    intervals.to_csv(output_dir / "ks_entropy_bootstrap_intervals.csv", index=False)
    selection_frequency = pd.DataFrame(
        [
            {
                "feature_group_count": int(count),
                "selection_count": int(selection_counts[count]),
                "selection_probability": float(selection_counts[count] / bootstraps),
            }
            for count in counts
        ]
    )
    selection_frequency.to_csv(
        output_dir / "conditional_graph_bootstrap_selection_probabilities.csv",
        index=False,
    )

    if not study.task4_artifacts:
        study.run_task4()
    fixed_source = study.task4_artifacts["replicates"]
    fixed_rows = []
    fixed_counts = Counter()
    for bootstrap_id, group in fixed_source.groupby("bootstrap_id"):
        ordered = group.set_index("feature_group_count").reindex(counts)
        entropy_bits = (
            ordered["ks_entropy_bits_per_transition"].to_numpy(dtype=float)
        )
        scores = ordered["bootstrap_BIC"].to_numpy(dtype=float) + default_lambda * entropy_bits
        selected = int(counts[np.argmin(scores)])
        fixed_counts[selected] += 1
        for count, entropy_value, score in zip(counts, entropy_bits, scores):
            fixed_rows.append(
                {
                    "bootstrap_id": int(bootstrap_id),
                    "feature_group_count": int(count),
                    "bootstrap_ks_entropy_bits_per_transition": float(entropy_value),
                    "bootstrap_pure_KS_BIC": float(score),
                    "selected": int(count) == selected,
                }
            )
    fixed_bootstrap = pd.DataFrame(fixed_rows)
    fixed_frequency = pd.DataFrame(
        [
            {
                "feature_group_count": int(count),
                "selection_count": int(fixed_counts[count]),
                "selection_probability": float(
                    fixed_counts[count] / fixed_source["bootstrap_id"].nunique()
                ),
            }
            for count in counts
        ]
    )
    fixed_bootstrap.to_csv(
        output_dir / "fixed_order_retraining_bootstrap_criterion_replicates.csv",
        index=False,
    )
    fixed_frequency.to_csv(
        output_dir / "fixed_order_retraining_bootstrap_selection_probabilities.csv",
        index=False,
    )

    shared = _task7_full_pipeline_retraining(study, counts)
    shared_replicates = shared["replicates"].copy()
    full_rows = []
    full_counts = Counter()
    for bootstrap_id, group in shared_replicates.groupby("bootstrap_id"):
        ordered = group.set_index("feature_group_count").reindex(counts)
        scores = (
            ordered["bootstrap_BIC"].to_numpy(dtype=float)
            + default_lambda
            * ordered["bootstrap_ks_entropy_bits_per_transition"].to_numpy(dtype=float)
        )
        selected = int(counts[np.argmin(scores)])
        full_counts[selected] += 1
        for count, score in zip(counts, scores):
            full_rows.append(
                {
                    "bootstrap_id": int(bootstrap_id),
                    "feature_group_count": int(count),
                    "bootstrap_pure_KS_BIC": float(score),
                    "selected": int(count) == selected,
                }
            )
    full_bootstrap = pd.DataFrame(full_rows)
    full_count = int(shared["bootstrap_count"])
    full_frequency = pd.DataFrame(
        [
            {
                "feature_group_count": int(count),
                "selection_count": int(full_counts[count]),
                "selection_probability": float(full_counts[count] / full_count),
            }
            for count in counts
        ]
    )
    full_bootstrap.to_csv(
        output_dir / "full_retraining_bootstrap_criterion_replicates.csv", index=False
    )
    full_frequency.to_csv(
        output_dir / "full_retraining_bootstrap_selection_probabilities.csv", index=False
    )
    shared["feature_orders"].to_csv(
        output_dir / "full_retraining_bootstrap_feature_orders.csv", index=False
    )

    selected_row = candidates[candidates["feature_group_count"].eq(selected_count)].iloc[0]
    selected_artifact = settings[selected_count]
    selected_test_probabilities = selected_artifact["model"].predict_proba(
        study.X_test[:, selected_artifact["indices"]]
    )[:, 1]
    selected_test_metrics = predictive_metrics(
        study.y_test, selected_test_probabilities, "test"
    )
    summary = pd.DataFrame(
        [
            {
                "criterion": "BIC plus pure KS entropy-rate penalty",
                "formula": "BIC_k + lambda * h_KS,k",
                "default_lambda": default_lambda,
                "lambda_units": "BIC criterion points per bit per transition",
                "ks_entropy_unit_used_in_penalty": "bits per transition",
                "ks_entropy_is_stationary_weighted": True,
                "training_cases_for_likelihood": len(study.y_train),
                "explanation_cases_for_entropy": case_count,
                "bic_selected_feature_group_count": bic_selected,
                "pure_ks_bic_selected_feature_group_count": selected_count,
                "selected_feature_groups": selected_row["included_feature_groups"],
                "selected_validation_accuracy": selected_row["validation_accuracy"],
                "selected_validation_roc_auc": selected_row["validation_roc_auc"],
                "selected_bic": selected_row["BIC"],
                "selected_ks_entropy_bits_per_transition": selected_row[
                    "ks_entropy_bits_per_transition"
                ],
                "selected_pure_ks_bic": selected_row["pure_KS_BIC_default_lambda"],
                "selected_lambda_interval_lower": selected_interval["lambda_lower"],
                "selected_lambda_interval_upper": selected_interval["lambda_upper"],
                "conditional_graph_bootstrap_selection_probability": float(
                    selection_counts[selected_count] / bootstraps
                ),
                "fixed_order_retraining_bootstrap_selection_probability": float(
                    fixed_counts[selected_count] / fixed_source["bootstrap_id"].nunique()
                ),
                "full_retraining_bootstrap_selection_probability": float(
                    full_counts[selected_count] / full_count
                ),
                "full_retraining_bootstraps": full_count,
                "full_retraining_recomputes_global_feature_order": True,
                "full_retraining_fixed_ranking_cohort": True,
                "full_retraining_fixed_shap_background": True,
                "criterion_is_conventional_bic_or_bayes_factor": False,
                "test_cases_used": False,
                "test_evaluated_after_selection": True,
                **selected_test_metrics,
            }
        ]
    )
    summary.to_csv(output_dir / "task7_selection_summary.csv", index=False)

    fig, axes = plt.subplots(1, 2, figsize=(15, 5.5), constrained_layout=True)
    bic_line = axes[0].plot(counts, candidates["BIC"], marker="o", color=BLUE, label="BIC")
    entropy_axis = axes[0].twinx()
    entropy_line = entropy_axis.plot(
        counts,
        candidates["ks_entropy_bits_per_transition"],
        marker="s",
        color=GREEN,
        label="Pure KS entropy rate",
    )
    axes[0].set_ylabel("BIC")
    entropy_axis.set_ylabel("KS entropy (bits per transition)")
    axes[0].legend(bic_line + entropy_line, [line.get_label() for line in bic_line + entropy_line])
    axes[1].plot(
        counts,
        candidates["delta_BIC"],
        marker="o",
        markerfacecolor="white",
        markeredgewidth=1.8,
        linewidth=2.4,
        color=BLUE,
        zorder=3,
        label="Delta BIC",
    )
    axes[1].plot(
        counts,
        candidates["delta_pure_KS_BIC"],
        marker="x",
        markersize=7,
        linestyle="--",
        linewidth=1.8,
        color="#d95f02",
        zorder=4,
        label=f"Delta KS-BIC (lambda={default_lambda:g})",
    )
    axes[1].set_ylabel("Difference from minimum")
    axes[1].legend()
    separation_axis = axes[1].inset_axes([0.53, 0.12, 0.43, 0.32])
    separation_axis.axhline(0.0, color="black", linewidth=0.8, alpha=0.6)
    separation_axis.plot(
        counts,
        candidates["ks_induced_delta_difference"],
        marker="d",
        markersize=4,
        color=PURPLE,
    )
    separation_axis.set_title("KS-induced separation", fontsize=8)
    separation_axis.set_xlabel("Feature groups", fontsize=7)
    separation_axis.set_ylabel("Delta KS-BIC - Delta BIC", fontsize=7)
    separation_axis.tick_params(labelsize=7)
    separation_axis.grid(alpha=0.2)
    for axis in axes:
        axis.set_xlabel("Number of original feature groups")
        axis.grid(alpha=0.25)
    fig.suptitle(
        f"Task 7: BIC with pure KS entropy-rate penalty - {study.config.dataset_title}"
    )
    study._save_show(fig, output_dir / "task7_pure_ks_bic_components_and_selection.png", dpi=210)

    selected_path = lambda_path[lambda_path["selected"]]
    fig, axes = plt.subplots(1, 2, figsize=(15, 5.5), constrained_layout=True)
    axes[0].step(
        selected_path["lambda"],
        selected_path["feature_group_count"],
        where="post",
        color=PURPLE,
    )
    axes[0].axvline(
        default_lambda,
        linestyle="--",
        color=RED,
        label=f"Reference lambda={default_lambda:g}",
    )
    axes[0].set_xlabel("KS-entropy weight lambda")
    axes[0].set_ylabel("Selected feature-group count")
    axes[0].legend()
    merged = candidates.merge(intervals, on="feature_group_count", how="left")
    axes[1].plot(
        counts,
        candidates["ks_entropy_bits_per_transition"],
        marker="o",
        color=GREEN,
    )
    axes[1].fill_between(
        counts,
        merged["ks_entropy_bits_p025"].to_numpy(dtype=float),
        merged["ks_entropy_bits_p975"].to_numpy(dtype=float),
        color=GREEN,
        alpha=0.18,
    )
    axes[1].set_xlabel("Number of original feature groups")
    axes[1].set_ylabel("KS entropy (bits per transition)")
    axes[1].grid(alpha=0.25)
    fig.suptitle(
        f"Task 7: lambda and KS-entropy bootstrap sensitivity - {study.config.dataset_title}"
    )
    study._save_show(fig, output_dir / "task7_lambda_and_entropy_sensitivity.png", dpi=210)
    display(candidates.round(5))
    display(envelope)
    display(summary.round(5))
    _extended_store(study)["task7"] = {
        "candidates": candidates,
        "envelope": envelope,
        "bootstrap": bootstrap,
        "fixed_order_bootstrap": fixed_bootstrap,
        "fixed_order_frequency": fixed_frequency,
        "full_pipeline_bootstrap": full_bootstrap,
        "full_pipeline_frequency": full_frequency,
        "summary": summary,
    }
    return summary


def run_task7_1(study, bootstraps: int = 2000, default_lambda: float = 1.0) -> pd.DataFrame:
    """Evaluate the proposed entropy-effective branching penalty from former Task 7."""
    if not study.task6_artifacts:
        study.run_task6()
    output_dir = study.root / "task7_1_entropy_effective_dfg_bic_outputs"
    output_dir.mkdir(exist_ok=True)
    source = study.task6_artifacts["part1"].sort_values("feature_group_count").reset_index(drop=True).copy()
    counts = source["feature_group_count"].to_numpy(dtype=int)
    settings = study.task3_artifacts["settings"]
    candidate_rows = []
    profile_rows = []
    for count in counts:
        profile, summary = _transition_profile(settings[int(count)]["analysis_graph"])
        profile.insert(0, "feature_group_count", int(count))
        profile_rows.append(profile)
        source_row = source[source["feature_group_count"].eq(count)].iloc[0]
        candidate_rows.append(
            {
                "feature_group_count": int(count),
                "included_feature_groups": source_row["included_feature_groups"],
                "training_log_likelihood": float(source_row["training_log_likelihood"]),
                "design_rank_p": int(source_row["design_rank_p"]),
                "training_deviance": -2.0 * float(source_row["training_log_likelihood"]),
                "coefficient_BIC_penalty": int(source_row["design_rank_p"])
                * math.log(len(study.y_train)),
                "BIC": float(source_row["BIC"]),
                "validation_accuracy": float(source_row["validation_accuracy"]),
                "validation_roc_auc": float(source_row["validation_roc_auc"]),
                "relative_dfg_complexity_index": float(source_row["relative_dfg_complexity_index"]),
                **summary,
            }
        )
    candidates = pd.DataFrame(candidate_rows)
    candidates["frequency_DFG_BIC_default_lambda"] = (
        candidates["BIC"] + default_lambda * candidates["frequency_sensitive_dfg_penalty"]
    )
    candidates["support_DFG_BIC_default_lambda"] = (
        candidates["BIC"] + default_lambda * candidates["exact_support_dfg_penalty"]
    )
    candidates["graph_penalty_equivalent_regression_parameters"] = (
        candidates["frequency_sensitive_dfg_penalty"] / math.log(len(study.y_train))
    )
    bic_selected = int(candidates.loc[candidates["BIC"].idxmin(), "feature_group_count"])
    frequency_selected = int(
        candidates.loc[
            candidates["frequency_DFG_BIC_default_lambda"].idxmin(), "feature_group_count"
        ]
    )
    support_selected = int(
        candidates.loc[
            candidates["support_DFG_BIC_default_lambda"].idxmin(), "feature_group_count"
        ]
    )
    candidates["selected_by_BIC"] = candidates["feature_group_count"].eq(bic_selected)
    candidates["selected_by_frequency_DFG_BIC"] = candidates["feature_group_count"].eq(
        frequency_selected
    )
    candidates["selected_by_support_DFG_BIC"] = candidates["feature_group_count"].eq(
        support_selected
    )
    profiles = pd.concat(profile_rows, ignore_index=True)
    candidates.to_csv(output_dir / "entropy_effective_dfg_bic_results.csv", index=False)
    profiles.to_csv(output_dir / "node_transition_entropy_profiles.csv", index=False)

    envelope = _exact_lower_envelope(
        candidates["BIC"].to_numpy(dtype=float),
        candidates["frequency_sensitive_dfg_penalty"].to_numpy(dtype=float),
        counts,
    )
    envelope.to_csv(output_dir / "exact_lambda_selection_intervals.csv", index=False)
    selected_interval = envelope[
        (envelope["lambda_lower"] <= default_lambda + 1e-15)
        & (envelope["lambda_upper"] > default_lambda - 1e-15)
    ].iloc[0]
    finite_upper = envelope["lambda_upper"].replace(np.inf, np.nan).max()
    lambda_max = max(8.0, float(finite_upper) * 1.15 if np.isfinite(finite_upper) else 8.0)
    lambda_grid = np.linspace(0.0, lambda_max, 161)
    lambda_rows = []
    intercepts = candidates["BIC"].to_numpy(dtype=float)
    slopes = candidates["frequency_sensitive_dfg_penalty"].to_numpy(dtype=float)
    for value in lambda_grid:
        scores = intercepts + value * slopes
        selected = int(counts[np.argmin(scores)])
        for count, score in zip(counts, scores):
            lambda_rows.append(
                {
                    "lambda": float(value),
                    "feature_group_count": int(count),
                    "frequency_DFG_BIC": float(score),
                    "selected": int(count) == selected,
                }
            )
    lambda_path = pd.DataFrame(lambda_rows)
    lambda_path.to_csv(output_dir / "entropy_effective_dfg_bic_lambda_path.csv", index=False)

    rng = np.random.default_rng(study.config.random_state + 77001)
    bootstrap_rows = []
    selection_counts = Counter()
    case_count = len(study.probe_case_ids)
    for bootstrap_id in range(bootstraps):
        sampled = rng.choice(case_count, size=case_count, replace=True)
        replicate_penalties = []
        for count in counts:
            graph = build_dfg(
                [settings[int(count)]["analysis_traces"][position] for position in sampled]
            )
            _, graph_summary = _transition_profile(graph)
            penalty = graph_summary["frequency_sensitive_dfg_penalty"]
            replicate_penalties.append(penalty)
            bootstrap_rows.append(
                {
                    "bootstrap_id": bootstrap_id + 1,
                    "feature_group_count": int(count),
                    "frequency_sensitive_dfg_penalty": penalty,
                    "effective_transition_dimension_q": graph_summary[
                        "effective_transition_dimension_q"
                    ],
                }
            )
        replicate_penalties = np.asarray(replicate_penalties, dtype=float)
        selected = int(counts[np.argmin(intercepts + default_lambda * replicate_penalties)])
        selection_counts[selected] += 1
    bootstrap = pd.DataFrame(bootstrap_rows)
    bootstrap.to_csv(output_dir / "paired_graph_penalty_bootstrap_replicates.csv", index=False)
    interval_rows = []
    for count, group in bootstrap.groupby("feature_group_count"):
        stats = _interval(group["frequency_sensitive_dfg_penalty"].to_numpy())
        interval_rows.append(
            {
                "feature_group_count": int(count),
                **{f"graph_penalty_{key}": value for key, value in stats.items()},
            }
        )
    intervals = pd.DataFrame(interval_rows)
    intervals.to_csv(output_dir / "graph_penalty_bootstrap_intervals.csv", index=False)
    selection_frequency = pd.DataFrame(
        [
            {
                "feature_group_count": int(count),
                "selection_count": int(selection_counts[count]),
                "selection_probability": float(selection_counts[count] / bootstraps),
            }
            for count in counts
        ]
    )
    selection_frequency.to_csv(output_dir / "default_lambda_bootstrap_selection_probabilities.csv", index=False)

    if not study.task4_artifacts:
        study.run_task4()
    fixed_order_retraining = study.task4_artifacts["replicates"]
    fixed_order_counts = Counter()
    fixed_order_rows = []
    for bootstrap_id, group in fixed_order_retraining.groupby("bootstrap_id"):
        ordered = group.set_index("feature_group_count").reindex(counts)
        scores = (
            ordered["bootstrap_BIC"].to_numpy(dtype=float)
            + default_lambda
            * ordered["frequency_sensitive_dfg_penalty"].to_numpy(dtype=float)
        )
        selected = int(counts[np.argmin(scores)])
        fixed_order_counts[selected] += 1
        for count, score in zip(counts, scores):
            fixed_order_rows.append({
                "bootstrap_id": int(bootstrap_id),
                "feature_group_count": int(count),
                "bootstrap_frequency_DFG_BIC": float(score),
                "selected": int(count) == selected,
            })
    fixed_order_bootstrap = pd.DataFrame(fixed_order_rows)
    fixed_order_frequency = pd.DataFrame([
        {
            "feature_group_count": int(count),
            "selection_count": int(fixed_order_counts[count]),
            "selection_probability": float(
                fixed_order_counts[count]
                / fixed_order_retraining["bootstrap_id"].nunique()
            ),
        }
        for count in counts
    ])
    fixed_order_bootstrap.to_csv(
        output_dir / "fixed_order_retraining_bootstrap_criterion_replicates.csv", index=False
    )
    fixed_order_frequency.to_csv(
        output_dir / "fixed_order_retraining_bootstrap_selection_probabilities.csv", index=False
    )

    shared = _task7_full_pipeline_retraining(study, counts)
    shared_replicates = shared["replicates"].copy()
    full_pipeline_count = int(shared["bootstrap_count"])
    full_pipeline_counts = Counter()
    full_pipeline_rows = []
    for bootstrap_id, group in shared_replicates.groupby("bootstrap_id"):
        ordered = group.set_index("feature_group_count").reindex(counts)
        scores = (
            ordered["bootstrap_BIC"].to_numpy(dtype=float)
            + default_lambda
            * ordered["bootstrap_frequency_sensitive_dfg_penalty"].to_numpy(dtype=float)
        )
        selected = int(counts[np.argmin(scores)])
        full_pipeline_counts[selected] += 1
        for count, score in zip(counts, scores):
            full_pipeline_rows.append(
                {
                    "bootstrap_id": int(bootstrap_id),
                    "feature_group_count": int(count),
                    "bootstrap_frequency_DFG_BIC": float(score),
                    "selected": int(count) == selected,
                }
            )

    full_pipeline_bootstrap = pd.DataFrame(full_pipeline_rows)
    full_pipeline_frequency = pd.DataFrame(
        [
            {
                "feature_group_count": int(count),
                "selection_count": int(full_pipeline_counts[count]),
                "selection_probability": float(
                    full_pipeline_counts[count] / full_pipeline_count
                ),
            }
            for count in counts
        ]
    )
    full_pipeline_bootstrap.to_csv(
        output_dir / "full_retraining_bootstrap_criterion_replicates.csv", index=False
    )
    full_pipeline_frequency.to_csv(
        output_dir / "full_retraining_bootstrap_selection_probabilities.csv", index=False
    )
    shared["feature_orders"].to_csv(
        output_dir / "full_retraining_bootstrap_feature_orders.csv", index=False
    )
    selected_row = candidates[candidates["feature_group_count"].eq(frequency_selected)].iloc[0]
    selected_artifact = settings[frequency_selected]
    selected_test_probabilities = selected_artifact["model"].predict_proba(
        study.X_test[:, selected_artifact["indices"]]
    )[:, 1]
    selected_test_metrics = predictive_metrics(
        study.y_test, selected_test_probabilities, "test"
    )
    summary = pd.DataFrame(
        [
            {
                "criterion": "Task 7.1 entropy-effective DFG-BIC-style score",
                "default_lambda": default_lambda,
                "training_cases_for_likelihood": len(study.y_train),
                "explanation_cases_for_graph_penalty": case_count,
                "bic_selected_feature_group_count": bic_selected,
                "frequency_dfg_bic_selected_feature_group_count": frequency_selected,
                "support_dfg_bic_selected_feature_group_count": support_selected,
                "selected_feature_groups": selected_row["included_feature_groups"],
                "selected_validation_accuracy": selected_row["validation_accuracy"],
                "selected_validation_roc_auc": selected_row["validation_roc_auc"],
                "selected_bic": selected_row["BIC"],
                "selected_frequency_dfg_penalty": selected_row[
                    "frequency_sensitive_dfg_penalty"
                ],
                "selected_frequency_dfg_bic": selected_row[
                    "frequency_DFG_BIC_default_lambda"
                ],
                "selected_graph_penalty_equivalent_regression_parameters": selected_row[
                    "graph_penalty_equivalent_regression_parameters"
                ],
                "selected_lambda_interval_lower": selected_interval["lambda_lower"],
                "selected_lambda_interval_upper": selected_interval["lambda_upper"],
                "paired_graph_bootstrap_selection_probability": float(
                    selection_counts[frequency_selected] / bootstraps
                ),
                "fixed_order_retraining_bootstrap_selection_probability": float(
                    fixed_order_counts[frequency_selected]
                    / fixed_order_retraining["bootstrap_id"].nunique()
                ),
                "full_retraining_bootstrap_selection_probability": float(
                    full_pipeline_counts[frequency_selected] / full_pipeline_count
                ),
                "full_retraining_bootstraps": full_pipeline_count,
                "full_retraining_recomputes_global_feature_order": True,
                "full_retraining_fixed_ranking_cohort": True,
                "full_retraining_fixed_shap_background": True,
                "criterion_is_conventional_bic_or_bayes_factor": False,
                "test_cases_used": False,
                "test_evaluated_after_selection": True,
                **selected_test_metrics,
            }
        ]
    )
    summary.to_csv(output_dir / "task7_1_selection_summary.csv", index=False)

    fig, axes = plt.subplots(1, 2, figsize=(15, 5.5), constrained_layout=True)
    axes[0].plot(counts, candidates["training_deviance"], marker="o", label="Training deviance")
    axes[0].plot(counts, candidates["coefficient_BIC_penalty"], marker="s", label="Coefficient BIC penalty")
    axes[0].plot(counts, candidates["frequency_sensitive_dfg_penalty"], marker="^", label="DFG penalty")
    axes[0].set_ylabel("Criterion component")
    axes[0].legend()
    axes[1].plot(counts, candidates["BIC"] - candidates["BIC"].min(), marker="o", label="Delta BIC")
    axes[1].plot(
        counts,
        candidates["frequency_DFG_BIC_default_lambda"]
        - candidates["frequency_DFG_BIC_default_lambda"].min(),
        marker="s",
        label="Delta DFG-BIC",
    )
    axes[1].set_ylabel("Difference from minimum")
    axes[1].legend()
    for axis in axes:
        axis.set_xlabel("Number of original feature groups")
        axis.grid(alpha=0.25)
    fig.suptitle(
        f"Task 7.1: Entropy-effective DFG penalty - {study.config.dataset_title}"
    )
    study._save_show(
        fig,
        output_dir / "task7_1_dfg_bic_components_and_selection.png",
        dpi=210,
    )

    selected_path = lambda_path[lambda_path["selected"]].copy()
    fig, axes = plt.subplots(1, 2, figsize=(15, 5.5), constrained_layout=True)
    axes[0].step(
        selected_path["lambda"],
        selected_path["feature_group_count"],
        where="post",
        color=PURPLE,
    )
    axes[0].axvline(default_lambda, linestyle="--", color=RED, label="Default lambda=1")
    axes[0].set_xlabel("Graph-penalty weight lambda")
    axes[0].set_ylabel("Selected feature-group count")
    axes[0].legend()
    merged = candidates.merge(intervals, on="feature_group_count", how="left")
    lower = merged["graph_penalty_p025"].to_numpy(dtype=float)
    upper = merged["graph_penalty_p975"].to_numpy(dtype=float)
    axes[1].plot(counts, candidates["frequency_sensitive_dfg_penalty"], marker="o")
    axes[1].fill_between(counts, lower, upper, alpha=0.18)
    axes[1].set_xlabel("Number of original feature groups")
    axes[1].set_ylabel("Frequency-sensitive DFG penalty")
    axes[1].grid(alpha=0.25)
    fig.suptitle(
        f"Task 7.1: Lambda and graph-bootstrap sensitivity - {study.config.dataset_title}"
    )
    study._save_show(
        fig,
        output_dir / "task7_1_lambda_and_bootstrap_sensitivity.png",
        dpi=210,
    )
    display(candidates.round(5))
    display(envelope)
    display(summary.round(5))
    _extended_store(study)["task7_1"] = {
        "candidates": candidates,
        "profiles": profiles,
        "envelope": envelope,
        "bootstrap": bootstrap,
        "fixed_order_bootstrap": fixed_order_bootstrap,
        "fixed_order_frequency": fixed_order_frequency,
        "full_pipeline_bootstrap": full_pipeline_bootstrap,
        "full_pipeline_frequency": full_pipeline_frequency,
        "summary": summary,
    }
    return summary


def write_extended_manifest(study) -> pd.DataFrame:
    rows = [
        ("Study Protocol", ".", "study_protocol_data_quality_audit.csv"),
        ("Task 1", "task1_outputs", "model_graph_summary.csv"),
        ("Task 2", "task2_outputs", "baseline_model_entropy.csv"),
        ("Task 2.1", "task2_1_outputs", "random_forest_depth_validation_entropy.csv"),
        ("Task 2.2", "task2_2_outputs", "logistic_regression_c_validation_entropy.csv"),
        ("Task 2.3", "task2_3_outputs", "neural_network_alpha_validation_entropy.csv"),
        ("Task 2.3.1", "task2_3_1_outputs", "neural_network_architecture_validation_entropy.csv"),
        ("Task 2.3.2", "task2_3_2_outputs", "early_stopping_validation_performance.csv"),
        ("Task 2.4", "task2_4_outputs", "hyperparameter_model_dfg_measures.csv"),
        ("Task 3", "task3_outputs", "dfg_only_selection_summary.csv"),
        ("Task 4", "task4_outputs", "complexity_stability_summary.csv"),
        ("Task 5", "task5_outputs", "model_decision_ground_truth_summary.csv"),
        ("Task 5.1", "task5_1_accepted_outputs", "dfg_comparison_summary.csv"),
        ("Task 5.2", "task5_2_rejected_outputs", "dfg_comparison_summary.csv"),
        ("Task 5.3", "task5_3_accepted_rejected_outputs", "dfg_comparison_summary.csv"),
        ("Task 5.4", "task5_4_edge_difference_outputs", "edge_presence_difference_summary.csv"),
        ("Task 5.5.1", "task5_5_feature_count_outputs/logistic_regression", "nested_performance_and_dfg.csv"),
        ("Task 5.5.2", "task5_5_feature_count_outputs/random_forest", "nested_performance_and_dfg.csv"),
        ("Task 5.5.3", "task5_5_feature_count_outputs/neural_network", "nested_performance_and_dfg.csv"),
        ("Task 5.5.4", "task5_5_feature_count_outputs/frequency_volume_differences", "frequency_volume_summary.csv"),
        ("Task 6", "task6_outputs", "task6_method_comparison_summary.csv"),
        ("Task 6.3.1", "task6_3_1_outputs", "selection_sensitivity_summary.csv"),
        ("Task 6.4", "task6_4_fixed_k_model_outputs", "fixed_k_model_performance_and_dfg_complexity.csv"),
        ("Task 6.5", "task6_5_nn_depth_width_outputs", "architecture_selection_summary.csv"),
        ("Task 7", "task7_pure_ks_bic_outputs", "task7_selection_summary.csv"),
        (
            "Task 7.1",
            "task7_1_entropy_effective_dfg_bic_outputs",
            "task7_1_selection_summary.csv",
        ),
    ]
    optional_rows = [
        ("Task 7.2", "task7_2_explanation_coding_outputs", "selection_comparison.csv"),
        ("Task 7.3", "task7_3_stability_tradeoff_outputs", "performance_complexity_pareto.csv"),
        ("Task 7.4", "task7_4_fit_entropy_outputs", "selection_comparison.csv"),
        ("Task 7.5", "task7_5_centrality_outputs", "selection_comparison.csv"),
        ("Task 7.6", "task7_6_likelihood_ks_outputs", "selection_comparison.csv"),
        (
            "Task 6.3.2",
            "task6_3_2_lr_tuning_outputs",
            "nested_feature_count_c_and_class_weight_sensitivity.csv",
        ),
        (
            "Task 6.3.2",
            "task6_3_2_validation_performance_outputs",
            "logistic_regression_validation_performance_by_feature_count.csv",
        ),
        (
            "Task 6.3.2.1",
            "task6_3_2_lr_tuning_outputs",
            "logistic_regression_validation_performance_by_feature_count.csv",
        ),
        ("Final test report", "test_performance_outputs", "test_model_performance.csv"),
    ]
    for row in optional_rows:
        if (study.root / row[1] / row[2]).exists():
            if row[0].startswith("Task 6.3.2"):
                position = next(index for index, existing in enumerate(rows) if existing[0] == "Task 6.4")
                rows.insert(position, row)
            else:
                rows.append(row)
    if (study.root / "protocol_sensitivity_outputs" / "declared_feature_exclusion_sensitivity.csv").exists():
        rows.insert(
            1,
            (
                "Study Protocol sensitivity",
                "protocol_sensitivity_outputs",
                "declared_feature_exclusion_sensitivity.csv",
            ),
        )
    frame = pd.DataFrame(rows, columns=["task", "output_directory", "primary_file"])
    frame["available"] = [
        (study.root / row.output_directory / row.primary_file).exists()
        for row in frame.itertuples(index=False)
    ]
    frame.to_csv(study.root / "tasks_1_to_7_output_manifest.csv", index=False)
    display(frame)
    return frame
