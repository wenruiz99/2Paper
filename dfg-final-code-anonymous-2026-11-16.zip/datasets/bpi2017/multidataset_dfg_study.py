"""Reusable Tasks 1-7 feature-explanation DFG analysis.

The public surface is the :class:`DFGStudy` class. Dataset-specific notebooks
prepare a case-level table, instantiate the class, and execute one method per
task. All feature DFGs use original feature groups, not one-hot columns.
"""

from __future__ import annotations

from collections import Counter, defaultdict
from dataclasses import asdict, dataclass, field
from itertools import combinations, pairwise
from pathlib import Path
import json
import math
import re
import warnings
import xml.etree.ElementTree as ET

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import networkx as nx
import numpy as np
import pandas as pd
import shap
from IPython.display import Image as NotebookImage
from dfg_similarity_presentation import display_study_result as display, task1_similarity_figures
from scipy.stats import spearmanr
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.exceptions import ConvergenceWarning
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    brier_score_loss,
    confusion_matrix,
    log_loss,
    roc_auc_score,
)
from sklearn.model_selection import train_test_split
from sklearn.neural_network import MLPClassifier
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler


warnings.filterwarnings("ignore", message="IProgress not found.*")
warnings.filterwarnings("ignore", message="'penalty' was deprecated.*", category=FutureWarning)
warnings.filterwarnings("ignore", message="Inconsistent values: penalty=l1.*", category=UserWarning)


@dataclass
class StudyConfig:
    dataset_key: str
    dataset_title: str
    features: list[str]
    numerical_features: list[str]
    categorical_features: list[str]
    target_column: str = "Outcome_Accepted"
    case_id_column: str = "CaseID"
    time_column: str | None = None
    split_mode: str = "stratified"
    positive_label: str = "Accepted"
    negative_label: str = "Rejected"
    endpoint_note: str = ""
    feature_labels: dict[str, str] = field(default_factory=dict)
    random_state: int = 42
    analysis_protocol_version: str = "2.0"
    one_hot_drop_first: bool = True
    explanation_cases: int = 500
    background_cases: int = 100
    ranking_cases: int = 1000
    sweep_explanation_cases: int = 100
    sweep_background_cases: int = 25
    rank_tie_relative_tolerance: float = 1e-9
    nn_shap_permutation_pairs: int = 2
    task1_metric_bootstraps: int = 1000
    task1_bootstraps: int = 200
    task2_graph_bootstraps: int = 200
    task3_bootstraps: int = 300
    task4_retraining_bootstraps: int = 100
    task5_bootstraps: int = 1000
    task5_permutations: int = 1000
    task6_bootstraps: int = 2000
    task6_4_primary_complexity_measure: str = "relative_composite"
    task7_full_pipeline_bootstraps: int = 100
    context_features: list[str] = field(default_factory=list)
    sensitivity_exclusions: dict[str, list[str]] = field(default_factory=dict)
    cohort_manifest: str | None = None


def _safe_name(value: object) -> str:
    text = re.sub(r"[^A-Za-z0-9._-]+", "_", str(value)).strip("_")
    return text or "setting"


def _interval(values: list[float] | np.ndarray) -> dict[str, float]:
    array = np.asarray(values, dtype=float)
    if len(array) == 0:
        return {
            "mean": np.nan,
            "sd": np.nan,
            "se": np.nan,
            "mcse_mean": np.nan,
            "p025": np.nan,
            "p975": np.nan,
        }
    sd = float(np.std(array, ddof=1)) if len(array) > 1 else 0.0
    return {
        "mean": float(np.mean(array)),
        "sd": sd,
        # For a bootstrap distribution, its standard deviation estimates the
        # sampling standard error. The Monte Carlo error of the replicate mean
        # is a different, usually much smaller, simulation diagnostic.
        "se": sd,
        "mcse_mean": sd / math.sqrt(len(array)) if len(array) > 1 else 0.0,
        "p025": float(np.quantile(array, 0.025)),
        "p975": float(np.quantile(array, 0.975)),
    }


def _stratified_indices(targets: np.ndarray, size: int, rng: np.random.Generator) -> np.ndarray:
    targets = np.asarray(targets, dtype=int)
    size = min(int(size), len(targets))
    if size == len(targets):
        return np.arange(len(targets), dtype=int)
    selected: list[np.ndarray] = []
    for label in np.unique(targets):
        positions = np.flatnonzero(targets == label)
        label_size = max(1, int(round(size * len(positions) / len(targets))))
        label_size = min(label_size, len(positions))
        selected.append(rng.choice(positions, size=label_size, replace=False))
    result = np.unique(np.concatenate(selected))
    if len(result) > size:
        result = rng.choice(result, size=size, replace=False)
    elif len(result) < size:
        remaining = np.setdiff1d(np.arange(len(targets)), result)
        result = np.concatenate([result, rng.choice(remaining, size=size - len(result), replace=False)])
    return np.sort(result.astype(int))


def _stratified_bootstrap_indices(targets: np.ndarray, rng: np.random.Generator) -> np.ndarray:
    targets = np.asarray(targets, dtype=int)
    pieces = []
    for label in np.unique(targets):
        positions = np.flatnonzero(targets == label)
        pieces.append(rng.choice(positions, size=len(positions), replace=True))
    sampled = np.concatenate(pieces)
    rng.shuffle(sampled)
    return sampled.astype(int)


def grouped_antithetic_permutation_shap(
    model,
    cases: np.ndarray,
    background: np.ndarray,
    groups: list[str],
    group_columns: dict[str, np.ndarray],
    *,
    seed: int,
    permutation_pairs: int = 2,
) -> np.ndarray:
    """Estimate grouped probability-scale SHAP with forward/reverse paths.

    Every sampled permutation is paired with its reverse. Each path is locally
    efficient, and antithetic pairing reduces ordering Monte Carlo noise without
    splitting one-hot feature groups into impossible partial-category states.
    """
    cases = np.asarray(cases, dtype=float)
    background = np.asarray(background, dtype=float)
    if len(groups) == 0:
        return np.zeros((len(cases), 0), dtype=float)
    if len(background) == 0:
        raise ValueError("Permutation SHAP requires at least one background case.")
    rng = np.random.default_rng(seed)
    grouped = np.zeros((len(cases), len(groups)), dtype=float)
    path_count = 2 * max(1, int(permutation_pairs))
    for case_index, case in enumerate(cases):
        contributions = np.zeros(len(groups), dtype=float)
        for _ in range(max(1, int(permutation_pairs))):
            forward = rng.permutation(len(groups))
            for order in (forward, forward[::-1]):
                state = background.copy()
                states = [state.copy()]
                for group_index in order:
                    columns = np.asarray(group_columns[groups[int(group_index)]], dtype=int)
                    state[:, columns] = case[columns]
                    states.append(state.copy())
                means = model.predict_proba(np.vstack(states))[:, 1].reshape(
                    len(groups) + 1, len(background)
                ).mean(axis=1)
                marginal = np.diff(means)
                for step, group_index in enumerate(order):
                    contributions[int(group_index)] += marginal[step]
        grouped[case_index] = contributions / path_count
    return grouped


def build_dfg(traces: list[list[str]]) -> nx.DiGraph:
    counts: Counter[tuple[str, str]] = Counter()
    for trace in traces:
        counts.update(pairwise(trace))
    graph = nx.DiGraph()
    for (source, target), frequency in counts.items():
        graph.add_edge(source, target, weight=float(frequency), frequency=int(frequency))
    return graph


def feature_only_traces(traces: list[list[str]]) -> list[list[str]]:
    """Remove the endpoint label while retaining one common terminal event."""
    return [["START", *trace[1:-1], "END"] for trace in traces]


def project_feature_traces(
    traces: list[list[str]], included_feature_events: set[str]
) -> list[list[str]]:
    """Project aligned traces onto retained feature events and their endpoints."""
    projected = []
    for trace in traces:
        events = [event for event in trace if event in included_feature_events]
        projected.append(["START", *events, "END"])
    return projected


def edge_weights(graph: nx.DiGraph) -> dict[tuple[str, str], float]:
    return {
        (source, target): float(data.get("weight", data.get("frequency", 0.0)))
        for source, target, data in graph.edges(data=True)
    }


def normalized_edge_weights(graph_or_weights: nx.DiGraph | dict[tuple[str, str], float]) -> dict[tuple[str, str], float]:
    weights = edge_weights(graph_or_weights) if isinstance(graph_or_weights, nx.Graph) else graph_or_weights
    total = float(sum(weights.values()))
    if total <= 0:
        return {}
    return {edge: float(weight) / total for edge, weight in weights.items()}


def l1_dfg_similarity(first: nx.DiGraph | dict, second: nx.DiGraph | dict) -> float:
    first_norm = normalized_edge_weights(first)
    second_norm = normalized_edge_weights(second)
    edges = set(first_norm).union(second_norm)
    distance = 0.5 * sum(abs(first_norm.get(edge, 0.0) - second_norm.get(edge, 0.0)) for edge in edges)
    return float(np.clip(1.0 - distance, 0.0, 1.0))


def proposed_dfg_similarity(first: nx.DiGraph | dict, second: nx.DiGraph | dict) -> float:
    """Return the project-defined mean edge-frequency similarity.

    The union of the two edge sets supplies ``E``.  For each edge, the raw
    frequency difference is divided by both graph totals and the larger
    normalized difference is retained.  The result is one minus the mean
    retained difference.  Consequently, identical graphs score one; despite
    earlier ``D_DFG`` notation, this expression is a similarity.
    """
    first_weights = edge_weights(first) if isinstance(first, nx.Graph) else first
    second_weights = edge_weights(second) if isinstance(second, nx.Graph) else second
    first_total = float(sum(first_weights.values()))
    second_total = float(sum(second_weights.values()))
    edges = set(first_weights).union(second_weights)
    if not edges:
        return 1.0
    if first_total <= 0 or second_total <= 0:
        return 0.0
    penalties = [
        max(
            abs(first_weights.get(edge, 0.0) - second_weights.get(edge, 0.0)) / first_total,
            abs(first_weights.get(edge, 0.0) - second_weights.get(edge, 0.0)) / second_total,
        )
        for edge in edges
    ]
    return float(np.clip(1.0 - np.mean(penalties), 0.0, 1.0))


def proposed_dfg_distance(first: nx.DiGraph | dict, second: nx.DiGraph | dict) -> float:
    """Return dissimilarity corresponding to :func:`proposed_dfg_similarity`."""
    return float(1.0 - proposed_dfg_similarity(first, second))


def supervisor_dfg_similarity(first: nx.DiGraph | dict, second: nx.DiGraph | dict) -> float:
    """Backward-compatible alias for the project-defined similarity."""
    return proposed_dfg_similarity(first, second)


def markov_entropy_measures(
    closed_graph: nx.DiGraph, renewal_node: str = "START"
) -> dict[str, float]:
    """Return entropy-rate and regenerative-cycle diagnostics for a closed DFG."""
    nodes = list(closed_graph.nodes())
    if not nodes:
        return {
            "ks_entropy_bits_per_transition": 0.0,
            "normalized_ks_entropy": 0.0,
            "stationary_residual": 0.0,
            "renewal_state_probability": 0.0,
            "expected_transitions_per_case_cycle": 0.0,
            "entropy_bits_per_case_cycle": 0.0,
            "branching_state_stationary_mass": 0.0,
            "branching_state_entropy_bits": 0.0,
        }
    node_index = {node: index for index, node in enumerate(nodes)}
    transition = np.zeros((len(nodes), len(nodes)), dtype=float)
    for source in nodes:
        outgoing = list(closed_graph.out_edges(source, data=True))
        total = sum(float(data.get("weight", 0.0)) for _, _, data in outgoing)
        if total <= 0:
            transition[node_index[source], node_index[source]] = 1.0
        else:
            for _, target, data in outgoing:
                transition[node_index[source], node_index[target]] = float(data["weight"]) / total
    system = transition.T - np.eye(len(nodes))
    system[-1, :] = 1.0
    target = np.zeros(len(nodes), dtype=float)
    target[-1] = 1.0
    try:
        stationary = np.linalg.solve(system, target)
    except np.linalg.LinAlgError:
        stationary = np.linalg.lstsq(system, target, rcond=None)[0]
    stationary[np.abs(stationary) < 1e-14] = 0.0
    stationary = np.clip(stationary, 0.0, None)
    stationary = stationary / stationary.sum() if stationary.sum() else np.full(len(nodes), 1 / len(nodes))
    positive = transition > 0
    logs = np.zeros_like(transition)
    np.log2(transition, out=logs, where=positive)
    local_entropy = -np.sum(transition * logs, axis=1)
    entropy_rate = float(np.sum(stationary * local_entropy))
    out_degree = np.count_nonzero(positive, axis=1)
    maximum = float(np.sum(stationary * np.log2(np.maximum(out_degree, 1))))
    normalized = entropy_rate / maximum if maximum > 0 else 0.0
    residual = float(np.max(np.abs(stationary @ transition - stationary)))
    branching = out_degree > 1
    branching_mass = float(stationary[branching].sum())
    branching_entropy = (
        float(np.sum(stationary[branching] * local_entropy[branching]) / branching_mass)
        if branching_mass > 0
        else 0.0
    )
    renewal_probability = (
        float(stationary[node_index[renewal_node]]) if renewal_node in node_index else 0.0
    )
    expected_cycle = 1.0 / renewal_probability if renewal_probability > 0 else 0.0
    cycle_entropy = entropy_rate * expected_cycle if expected_cycle > 0 else 0.0
    return {
        "ks_entropy_bits_per_transition": entropy_rate,
        "normalized_ks_entropy": normalized,
        "stationary_residual": residual,
        "renewal_state_probability": renewal_probability,
        "expected_transitions_per_case_cycle": expected_cycle,
        "entropy_bits_per_case_cycle": cycle_entropy,
        "branching_state_stationary_mass": branching_mass,
        "branching_state_entropy_bits": branching_entropy,
    }


def ks_entropy(closed_graph: nx.DiGraph) -> tuple[float, float, float]:
    """Backward-compatible entropy-rate tuple used by existing notebook cells."""
    measures = markov_entropy_measures(closed_graph)
    return (
        measures["ks_entropy_bits_per_transition"],
        measures["normalized_ks_entropy"],
        measures["stationary_residual"],
    )


def dfg_branching_penalty(graph: nx.DiGraph) -> dict[str, float]:
    """Local BIC-style transition penalty used by Task 7.1.

    Deterministic routing has zero dimension. A node with several balanced
    successors approaches its exact support dimension, while very rare edges
    contribute less through the entropy-effective successor count.
    """
    effective_dimension = 0.0
    support_dimension = 0.0
    frequency_penalty = 0.0
    support_penalty = 0.0
    for node in graph.nodes():
        frequencies = np.asarray(
            [
                float(data.get("weight", data.get("frequency", 0.0)))
                for _, _, data in graph.out_edges(node, data=True)
            ],
            dtype=float,
        )
        total = float(frequencies.sum())
        if total <= 0:
            continue
        probabilities = frequencies / total
        positive = probabilities > 0
        entropy_bits = float(-np.sum(probabilities[positive] * np.log2(probabilities[positive])))
        effective = max(0.0, float(np.exp2(entropy_bits)) - 1.0)
        support = max(0, int(positive.sum()) - 1)
        effective_dimension += effective
        support_dimension += support
        frequency_penalty += effective * math.log(total)
        support_penalty += support * math.log(total)
    return {
        "effective_transition_dimension_q": effective_dimension,
        "support_transition_dimension_q": support_dimension,
        "frequency_sensitive_dfg_penalty": frequency_penalty,
        "exact_support_dfg_penalty": support_penalty,
    }


def _normalized_hhi(values: list[float]) -> float:
    array = np.asarray(values, dtype=float)
    total = float(array.sum())
    if len(array) <= 1 or total <= 0:
        return 0.0
    shares = array / total
    hhi = float(np.sum(shares**2))
    minimum = 1.0 / len(array)
    return float(np.clip((hhi - minimum) / (1.0 - minimum), 0.0, 1.0))


def open_graph_measures(open_graph: nx.DiGraph) -> dict[str, float]:
    graph = open_graph.copy()
    if graph.number_of_nodes() == 0:
        return {name: 0.0 for name in [
            "open_dfg_nodes", "open_dfg_edges", "open_dfg_density", "directed_edge_surplus",
            "rank_feature_nodes", "rank_possible_edges", "rank_minimum_edges",
            "rank_edge_capacity_fraction", "rank_excess_edge_occupancy",
            "directed_reachable_diameter", "directed_reachable_average_path",
            "inverse_probability_diameter", "inverse_probability_mean_path",
            "information_distance_p95", "information_distance_mean_path", "mean_out_closeness",
            "out_closeness_concentration", "mean_betweenness", "betweenness_concentration",
            "mean_undirected_eigenvector", "eigenvector_concentration",
            "effective_transition_dimension_q", "support_transition_dimension_q",
        ]}
    for source in graph.nodes():
        outgoing = list(graph.out_edges(source, data=True))
        total = sum(float(data.get("weight", 0.0)) for _, _, data in outgoing)
        for _, _, data in outgoing:
            probability = float(data.get("weight", 0.0)) / total if total else 0.0
            data["transition_probability"] = probability
            data["inverse_probability_distance"] = 1.0 / max(probability, 1e-15)
            data["information_distance"] = -math.log2(max(probability, 1e-15))

    unweighted_lengths = dict(nx.all_pairs_shortest_path_length(graph))
    unweighted = [
        float(distance)
        for source, lengths in unweighted_lengths.items()
        for target, distance in lengths.items()
        if source != target
    ]
    inverse_lengths = dict(nx.all_pairs_dijkstra_path_length(graph, weight="inverse_probability_distance"))
    inverse_distances = [
        float(distance)
        for source, lengths in inverse_lengths.items()
        for target, distance in lengths.items()
        if source != target
    ]
    information_lengths = dict(nx.all_pairs_dijkstra_path_length(graph, weight="information_distance"))
    information_distances = [
        float(distance)
        for source, lengths in information_lengths.items()
        for target, distance in lengths.items()
        if source != target
    ]
    outward_closeness = nx.closeness_centrality(graph.reverse(copy=False), distance="inverse_probability_distance")
    betweenness = nx.betweenness_centrality(graph, weight="inverse_probability_distance", normalized=True)
    strength_graph = nx.Graph()
    strength_graph.add_nodes_from(graph.nodes())
    for source, target, data in graph.edges(data=True):
        weight = float(data.get("weight", 0.0))
        if strength_graph.has_edge(source, target):
            strength_graph[source][target]["weight"] += weight
        else:
            strength_graph.add_edge(source, target, weight=weight)
    try:
        eigenvector = nx.eigenvector_centrality(strength_graph, weight="weight", max_iter=5000)
    except (nx.NetworkXException, nx.PowerIterationFailedConvergence) as exc:
        raise RuntimeError("Eigenvector centrality did not converge; do not report zeros as measurements.") from exc
    closeness_values = list(outward_closeness.values())
    betweenness_values = list(betweenness.values())
    eigenvector_values = list(eigenvector.values())
    feature_nodes = [node for node in graph.nodes() if str(node).startswith("Checking ")]
    terminal_nodes = [
        node
        for node in graph.nodes()
        if node == "END" or str(node).startswith("Outcome:")
    ]
    feature_count = len(feature_nodes)
    terminal_count = max(1, len(terminal_nodes)) if feature_count else 0
    rank_possible_edges = float(feature_count * (feature_count + terminal_count))
    rank_minimum_edges = float(feature_count + terminal_count) if feature_count else 0.0
    rank_capacity = max(rank_possible_edges - rank_minimum_edges, 0.0)
    observed_edges = float(graph.number_of_edges())
    branching_penalty = dfg_branching_penalty(graph)
    return {
        "open_dfg_nodes": float(graph.number_of_nodes()),
        "open_dfg_edges": float(graph.number_of_edges()),
        "open_dfg_density": float(nx.density(graph)),
        "directed_edge_surplus": float(max(0, graph.number_of_edges() - graph.number_of_nodes() + 1)),
        "rank_feature_nodes": float(feature_count),
        "rank_possible_edges": rank_possible_edges,
        "rank_minimum_edges": rank_minimum_edges,
        "rank_edge_capacity_fraction": observed_edges / rank_possible_edges if rank_possible_edges else 0.0,
        "rank_excess_edge_occupancy": (
            float(np.clip((observed_edges - rank_minimum_edges) / rank_capacity, 0.0, 1.0))
            if rank_capacity > 0
            else 0.0
        ),
        "directed_reachable_diameter": max(unweighted, default=0.0),
        "directed_reachable_average_path": float(np.mean(unweighted)) if unweighted else 0.0,
        "inverse_probability_diameter": max(inverse_distances, default=0.0),
        "inverse_probability_mean_path": float(np.mean(inverse_distances)) if inverse_distances else 0.0,
        "information_distance_p95": float(np.quantile(information_distances, 0.95)) if information_distances else 0.0,
        "information_distance_mean_path": float(np.mean(information_distances)) if information_distances else 0.0,
        "mean_out_closeness": float(np.mean(closeness_values)) if closeness_values else 0.0,
        "out_closeness_concentration": _normalized_hhi(closeness_values),
        "mean_betweenness": float(np.mean(betweenness_values)) if betweenness_values else 0.0,
        "betweenness_concentration": _normalized_hhi(betweenness_values),
        "mean_undirected_eigenvector": float(np.mean(eigenvector_values)) if eigenvector_values else 0.0,
        "eigenvector_concentration": _normalized_hhi(eigenvector_values),
        "effective_transition_dimension_q": branching_penalty["effective_transition_dimension_q"],
        "support_transition_dimension_q": branching_penalty["support_transition_dimension_q"],
    }


def predictive_metrics(targets: np.ndarray, probabilities: np.ndarray, prefix: str = "validation") -> dict[str, float]:
    targets = np.asarray(targets)
    probabilities = np.asarray(probabilities, dtype=float)
    if targets.ndim != 1 or probabilities.shape != targets.shape or not len(targets):
        raise ValueError("Targets and probabilities must be aligned, nonempty one-dimensional arrays.")
    if set(np.unique(targets)) != {0, 1}:
        raise ValueError("Predictive metrics require both binary outcomes, encoded exactly as 0 and 1.")
    if not np.isfinite(probabilities).all() or np.any((probabilities < 0) | (probabilities > 1)):
        raise ValueError("Predicted probabilities must be finite and between zero and one.")
    targets = targets.astype(int)
    probabilities = np.clip(probabilities, 1e-12, 1 - 1e-12)
    predictions = (probabilities >= 0.5).astype(int)
    return {
        f"{prefix}_accuracy": float(accuracy_score(targets, predictions)),
        f"{prefix}_balanced_accuracy": float(balanced_accuracy_score(targets, predictions)),
        f"{prefix}_roc_auc": float(roc_auc_score(targets, probabilities)),
        f"{prefix}_log_loss": float(log_loss(targets, probabilities, labels=[0, 1])),
        f"{prefix}_brier_score": float(brier_score_loss(targets, probabilities)),
    }


def quantile_calibration_error(
    targets: np.ndarray, probabilities: np.ndarray, bins: int = 10
) -> dict[str, float]:
    """Equal-count expected and maximum calibration gaps."""
    targets = np.asarray(targets, dtype=int)
    probabilities = np.clip(np.asarray(probabilities, dtype=float), 0.0, 1.0)
    if len(targets) == 0:
        return {"expected_calibration_error": np.nan, "maximum_calibration_error": np.nan}
    order = np.argsort(probabilities, kind="stable")
    groups = np.array_split(order, min(int(bins), len(order)))
    gaps = []
    weights = []
    for group in groups:
        if len(group) == 0:
            continue
        gaps.append(abs(float(probabilities[group].mean() - targets[group].mean())))
        weights.append(len(group) / len(targets))
    return {
        "expected_calibration_error": float(np.dot(weights, gaps)) if gaps else np.nan,
        "maximum_calibration_error": float(max(gaps)) if gaps else np.nan,
    }


def _benjamini_hochberg(p_values: np.ndarray) -> np.ndarray:
    values = np.asarray(p_values, dtype=float)
    order = np.argsort(values)
    ranked = values[order]
    adjusted = ranked * len(values) / np.arange(1, len(values) + 1)
    adjusted = np.minimum.accumulate(adjusted[::-1])[::-1]
    result = np.empty_like(adjusted)
    result[order] = np.clip(adjusted, 0.0, 1.0)
    return result


class DFGStudy:
    """Stateful, notebook-friendly implementation shared by Tasks 1 through 7."""

    MODEL_LABELS = {
        "logistic_regression": "Logistic Regression",
        "random_forest": "Random Forest",
        "neural_network": "Neural Network",
    }

    def __init__(self, case_data: pd.DataFrame, config: StudyConfig, root: str | Path = "."):
        self.config = config
        self.root = Path(root)
        self.root.mkdir(parents=True, exist_ok=True)
        self.rng = np.random.default_rng(config.random_state)
        self.case_data = self._validate_case_data(case_data)
        self._split_data()
        self._fit_preprocessor()
        self.task1_artifacts: dict[str, dict] = {}
        self.task2_4_artifacts: dict[str, object] = {}
        self.task3_artifacts: dict[str, object] = {}
        self.task4_artifacts: dict[str, object] = {}
        self.task5_artifacts: dict[str, object] = {}
        self.task6_artifacts: dict[str, object] = {}
        self._write_protocol()

    def _validate_case_data(self, frame: pd.DataFrame) -> pd.DataFrame:
        typed = self.config.numerical_features + self.config.categorical_features
        if len(set(self.config.features)) != len(self.config.features) or len(set(typed)) != len(typed):
            raise ValueError("Feature groups must be unique, with disjoint numerical and categorical types.")
        if set(typed) != set(self.config.features):
            raise ValueError("Every feature group must have exactly one declared type.")
        required = [self.config.case_id_column, self.config.target_column, *self.config.features]
        if self.config.time_column:
            required.append(self.config.time_column)
        missing = [column for column in required if column not in frame.columns]
        if missing:
            raise ValueError(f"Case-level data are missing required columns: {missing}")
        data = frame[required].copy()
        for feature in self.config.numerical_features:
            values = pd.to_numeric(data[feature], errors="raise")
            if np.isinf(values.to_numpy(dtype=float, na_value=np.nan)).any():
                raise ValueError(f"Infinite numerical feature values are not supported: {feature}")
        if data[self.config.case_id_column].isna().any():
            raise ValueError("Case IDs must not be missing.")
        data[self.config.case_id_column] = data[self.config.case_id_column].astype(str)
        if data[self.config.case_id_column].str.strip().eq("").any():
            raise ValueError("Case IDs must not be empty.")
        target = pd.to_numeric(data[self.config.target_column], errors="raise")
        if target.isna().any() or set(target.unique()) != {0, 1}:
            raise ValueError("The target must contain both binary values 0 and 1.")
        data[self.config.target_column] = target.astype(int)
        if data[self.config.case_id_column].duplicated().any():
            raise ValueError("CaseID values must be unique.")
        if self.config.time_column:
            data[self.config.time_column] = pd.to_datetime(
                data[self.config.time_column], format="ISO8601", utc=True, errors="raise"
            )
            if data[self.config.time_column].isna().any():
                raise ValueError("Prediction timestamps must not be missing; record exclusions explicitly.")
        self.input_case_count = len(data)
        self.cohort_exclusions = pd.DataFrame(columns=[self.config.case_id_column, "partition", "reason"])
        self._pinned_partitions = None
        if self.config.cohort_manifest:
            manifest = pd.read_csv(self.root / self.config.cohort_manifest, dtype={"CaseID": str}, keep_default_na=False)
            expected = {"CaseID", "partition", "partition_position", "outcome", "reason"}
            if not expected.issubset(manifest.columns) or manifest.CaseID.duplicated().any():
                raise ValueError("The cohort manifest must contain unique IDs and the declared audit columns.")
            if set(manifest.CaseID) != set(data[self.config.case_id_column]):
                raise ValueError("Source case IDs changed relative to the pinned cohort. Use a new, versioned study cohort.")
            if not set(manifest.partition).issubset({"train", "validation", "test", "excluded"}):
                raise ValueError("Unrecognized cohort-manifest partition.")
            observed = data.set_index(self.config.case_id_column)[self.config.target_column].reindex(manifest.CaseID)
            if not np.array_equal(observed.to_numpy(), pd.to_numeric(manifest.outcome).to_numpy()):
                raise ValueError("Outcomes changed relative to the pinned cohort.")
            exclusions = manifest.loc[manifest.partition.eq("excluded")].copy()
            if exclusions.reason.str.strip().eq("").any():
                raise ValueError("Every excluded case needs an explicit reason.")
            self.cohort_exclusions = exclusions
            self._pinned_partitions = manifest.loc[~manifest.partition.eq("excluded")].copy()
            data = data[data[self.config.case_id_column].isin(self._pinned_partitions.CaseID)]
        return data.reset_index(drop=True)

    def _split_data(self) -> None:
        target = self.config.target_column
        if self.config.split_mode not in {"chronological", "stratified"}:
            raise ValueError("split_mode must be chronological or stratified.")
        if self.config.split_mode == "chronological" and not self.config.time_column:
            raise ValueError("Chronological splitting requires a prediction-time column.")
        if self._pinned_partitions is not None:
            indexed = self.case_data.set_index(self.config.case_id_column, drop=False)
            frames = []
            for partition in ["train", "validation", "test"]:
                rows = self._pinned_partitions[self._pinned_partitions.partition.eq(partition)].copy()
                rows["partition_position"] = pd.to_numeric(rows.partition_position, errors="raise")
                rows = rows.sort_values("partition_position")
                if not np.array_equal(rows.partition_position.to_numpy(), np.arange(len(rows))):
                    raise ValueError("Pinned partition positions must be unique and contiguous from zero.")
                frames.append(indexed.loc[rows.CaseID].reset_index(drop=True))
            train, validation, test = frames
        elif self.config.split_mode == "chronological":
            ordered = self.case_data.sort_values(
                [self.config.time_column, self.config.case_id_column]
            ).reset_index(drop=True)
            first_time = ordered.iloc[int(0.60 * len(ordered))][self.config.time_column]
            second_time = ordered.iloc[int(0.80 * len(ordered))][self.config.time_column]
            train = ordered[ordered[self.config.time_column] < first_time].copy()
            validation = ordered[
                (ordered[self.config.time_column] >= first_time)
                & (ordered[self.config.time_column] < second_time)
            ].copy()
            test = ordered[ordered[self.config.time_column] >= second_time].copy()
        else:
            train, validation, test = self._random_split()
        if min(train[target].nunique(), validation[target].nunique(), test[target].nunique()) != 2:
            raise ValueError("Each declared partition must contain both outcomes; no random-split fallback is permitted.")
        if self.config.split_mode == "chronological":
            time = self.config.time_column
            if not (train[time].max() < validation[time].min() and validation[time].max() < test[time].min()):
                raise ValueError("Chronological partition times overlap.")
        self.train_data = train.reset_index(drop=True)
        self.validation_data = validation.reset_index(drop=True)
        self.test_data = test.reset_index(drop=True)

    def _random_split(self) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
        target = self.config.target_column
        train, remainder = train_test_split(
            self.case_data,
            test_size=0.40,
            random_state=self.config.random_state,
            stratify=self.case_data[target],
        )
        validation, test = train_test_split(
            remainder,
            test_size=0.50,
            random_state=self.config.random_state + 1,
            stratify=remainder[target],
        )
        return train, validation, test

    def _make_preprocessor(self, drop_first: bool = False) -> ColumnTransformer:
        numeric = Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("scaler", StandardScaler()),
        ])
        categorical = Pipeline([
            ("imputer", SimpleImputer(strategy="most_frequent")),
            (
                "onehot",
                OneHotEncoder(
                    handle_unknown="ignore",
                    sparse_output=False,
                    drop="first" if drop_first else None,
                ),
            ),
        ])
        return ColumnTransformer(
            [
                ("num", numeric, self.config.numerical_features),
                ("cat", categorical, self.config.categorical_features),
            ],
            verbose_feature_names_out=False,
        )

    def _fit_preprocessor(self) -> None:
        features = self.config.features
        target = self.config.target_column
        self.preprocessor = self._make_preprocessor(drop_first=self.config.one_hot_drop_first)
        self.X_train = np.asarray(self.preprocessor.fit_transform(self.train_data[features]), dtype=float)
        self.X_validation = np.asarray(self.preprocessor.transform(self.validation_data[features]), dtype=float)
        self.X_test = np.asarray(self.preprocessor.transform(self.test_data[features]), dtype=float)
        self.y_train = self.train_data[target].to_numpy(dtype=int)
        self.y_validation = self.validation_data[target].to_numpy(dtype=int)
        self.y_test = self.test_data[target].to_numpy(dtype=int)
        self.transformed_names, self.group_indices = self._transformed_group_indices(self.preprocessor)
        probe_rng = np.random.default_rng(self.config.random_state)
        self.probe_indices = _stratified_indices(
            self.y_validation, self.config.explanation_cases, probe_rng
        )
        self.background_indices = _stratified_indices(
            self.y_train, self.config.background_cases, probe_rng
        )
        self.sweep_probe_indices = _stratified_indices(
            self.y_validation, self.config.sweep_explanation_cases, probe_rng
        )
        self.sweep_background_indices = _stratified_indices(
            self.y_train, self.config.sweep_background_cases, probe_rng
        )
        self.ranking_indices = _stratified_indices(
            self.y_train, self.config.ranking_cases, probe_rng
        )
        self.probe_case_ids = self.validation_data.iloc[self.probe_indices][
            self.config.case_id_column
        ].to_numpy(dtype=object)
        self.probe_outcomes = self.y_validation[self.probe_indices]

    def _transformed_group_indices(self, preprocessor: ColumnTransformer) -> tuple[np.ndarray, dict[str, np.ndarray]]:
        names = np.asarray(preprocessor.get_feature_names_out(), dtype=object)
        groups: dict[str, np.ndarray] = {}
        names_as_text = names.astype(str)
        for feature in self.config.features:
            if feature in self.config.numerical_features:
                groups[feature] = np.flatnonzero(names == feature)
            else:
                groups[feature] = np.flatnonzero(np.char.startswith(names_as_text, f"{feature}_"))
        return names, groups

    def _write_protocol(self) -> None:
        memberships = []
        rows = []
        for name, frame in [
            ("train", self.train_data),
            ("validation", self.validation_data),
            ("test", self.test_data),
        ]:
            row = {
                "partition": name,
                "cases": len(frame),
                "acceptance_rate": float(frame[self.config.target_column].mean()),
            }
            if self.config.time_column:
                row["start"] = frame[self.config.time_column].min()
                row["end"] = frame[self.config.time_column].max()
            rows.append(row)
            memberships.extend({"CaseID": str(case_id), "partition": name, "partition_position": position,
                                "outcome": int(outcome), "reason": ""}
                               for position, (case_id, outcome) in enumerate(zip(
                                   frame[self.config.case_id_column], frame[self.config.target_column])))
        self.case_partitions = pd.DataFrame(memberships)
        self.case_partitions.to_csv(self.root / "study_case_partitions.csv", index=False)
        self.cohort_exclusions.to_csv(self.root / "study_cohort_exclusions.csv", index=False)
        self.cohort_summary = pd.DataFrame([{
            "input_cases": self.input_case_count, "explicitly_excluded_cases": len(self.cohort_exclusions),
            "analysis_cases": len(self.case_data), "split_mode": self.config.split_mode,
            "pinned_case_membership": self.config.cohort_manifest is not None,
        }])
        self.cohort_summary.to_csv(self.root / "study_protocol_cohort_audit.csv", index=False)
        self.protocol_summary = pd.DataFrame(rows)
        self.protocol_summary.to_csv(self.root / "study_protocol_partitions.csv", index=False)
        pd.DataFrame([{
            **asdict(self.config),
            "features": json.dumps(self.config.features),
            "numerical_features": json.dumps(self.config.numerical_features),
            "categorical_features": json.dumps(self.config.categorical_features),
            "feature_labels": json.dumps(self.config.feature_labels),
            "context_features": json.dumps(self.config.context_features),
            "sensitivity_exclusions": json.dumps(self.config.sensitivity_exclusions),
        }]).to_csv(self.root / "study_protocol_configuration.csv", index=False)

        audit_rows = []
        target = self.config.target_column
        for feature in self.config.features:
            accepted = self.train_data.loc[self.train_data[target].eq(1), feature]
            rejected = self.train_data.loc[self.train_data[target].eq(0), feature]
            row = {
                "audit_partition": "train", "audit_cases": len(self.train_data),
                "feature_group": feature,
                "feature_label": self.config.feature_labels.get(feature, feature),
                "feature_type": (
                    "numerical" if feature in self.config.numerical_features else "categorical"
                ),
                "context_feature": feature in self.config.context_features,
                "overall_missing_rate": float(self.train_data[feature].isna().mean()),
                "accepted_missing_rate": float(accepted.isna().mean()),
                "rejected_missing_rate": float(rejected.isna().mean()),
                "absolute_missing_rate_gap": float(abs(accepted.isna().mean() - rejected.isna().mean())),
                "unique_values": int(self.train_data[feature].nunique(dropna=True)),
                "standardized_mean_difference": np.nan,
                "categorical_total_variation_distance": np.nan,
            }
            if feature in self.config.numerical_features:
                accepted_numeric = pd.to_numeric(accepted, errors="coerce").dropna()
                rejected_numeric = pd.to_numeric(rejected, errors="coerce").dropna()
                pooled_variance = 0.5 * (
                    float(accepted_numeric.var(ddof=1)) + float(rejected_numeric.var(ddof=1))
                )
                if len(accepted_numeric) > 1 and len(rejected_numeric) > 1 and pooled_variance > 0:
                    row["standardized_mean_difference"] = float(
                        (accepted_numeric.mean() - rejected_numeric.mean()) / math.sqrt(pooled_variance)
                    )
            else:
                accepted_distribution = accepted.fillna("<missing>").astype(str).value_counts(normalize=True)
                rejected_distribution = rejected.fillna("<missing>").astype(str).value_counts(normalize=True)
                levels = accepted_distribution.index.union(rejected_distribution.index)
                row["categorical_total_variation_distance"] = float(
                    0.5
                    * np.abs(
                        accepted_distribution.reindex(levels, fill_value=0.0).to_numpy()
                        - rejected_distribution.reindex(levels, fill_value=0.0).to_numpy()
                    ).sum()
                )
            strong_separation = (
                row["absolute_missing_rate_gap"] >= 0.10
                or (
                    np.isfinite(row["standardized_mean_difference"])
                    and abs(row["standardized_mean_difference"]) >= 1.0
                )
                or (
                    np.isfinite(row["categorical_total_variation_distance"])
                    and row["categorical_total_variation_distance"] >= 0.50
                )
            )
            row["strong_marginal_separation_review_flag"] = bool(strong_separation)
            audit_rows.append(row)
        self.data_quality_audit = pd.DataFrame(audit_rows)
        self.data_quality_audit.to_csv(self.root / "study_protocol_data_quality_audit.csv", index=False)

    def show_protocol(self) -> pd.DataFrame:
        print(self.config.endpoint_note)
        print(
            f"Analysis protocol {self.config.analysis_protocol_version}; "
            "candidate settings use validation data, and candidate-wide test evaluation is disabled."
        )
        display(self.protocol_summary)
        display(self.cohort_summary)
        flagged = self.data_quality_audit[
            self.data_quality_audit["strong_marginal_separation_review_flag"]
        ]
        if len(flagged):
            print("Features with strong marginal outcome separation that require semantic review:")
            display(flagged)
        return self.protocol_summary

    def run_data_sensitivity(self) -> pd.DataFrame:
        """Evaluate declared source/context exclusions without using test cases."""
        scenarios = {"all_features": []}
        scenarios.update(self.config.sensitivity_exclusions)
        if len(scenarios) == 1:
            self.data_sensitivity = pd.DataFrame()
            return self.data_sensitivity
        output_dir = self.root / "protocol_sensitivity_outputs"
        output_dir.mkdir(exist_ok=True)
        rows = []
        for scenario, excluded in scenarios.items():
            unknown = sorted(set(excluded).difference(self.config.features))
            if unknown:
                raise ValueError(f"Unknown sensitivity features for {scenario}: {unknown}")
            included = [feature for feature in self.config.features if feature not in excluded]
            columns = self._indices_for_groups(included)
            if len(columns) == 0:
                continue
            for kind in self.MODEL_LABELS:
                model = self._fit_model(kind, columns=columns)
                probabilities = self._model_probabilities(model, self.X_validation[:, columns])
                rows.append(
                    {
                        "scenario": scenario,
                        "excluded_feature_groups": " | ".join(excluded),
                        "included_feature_group_count": len(included),
                        "model": kind,
                        "model_label": self.MODEL_LABELS[kind],
                        **predictive_metrics(self.y_validation, probabilities, "validation"),
                        "test_cases_used": False,
                    }
                )
        result = pd.DataFrame(rows)
        baseline = result[result["scenario"].eq("all_features")].set_index("model")
        result["validation_accuracy_change_from_all_features"] = [
            row.validation_accuracy - float(baseline.loc[row.model, "validation_accuracy"])
            for row in result.itertuples(index=False)
        ]
        result["validation_roc_auc_change_from_all_features"] = [
            row.validation_roc_auc - float(baseline.loc[row.model, "validation_roc_auc"])
            for row in result.itertuples(index=False)
        ]
        result.to_csv(output_dir / "declared_feature_exclusion_sensitivity.csv", index=False)
        fig, axes = plt.subplots(1, 2, figsize=(14, 5.2), constrained_layout=True)
        for kind, group in result.groupby("model", sort=False):
            axes[0].plot(
                group["scenario"], 100 * group["validation_accuracy"], marker="o",
                label=self.MODEL_LABELS[kind],
            )
            axes[1].plot(
                group["scenario"], group["validation_roc_auc"], marker="o",
                label=self.MODEL_LABELS[kind],
            )
        axes[0].set_ylabel("Validation accuracy (%)")
        axes[1].set_ylabel("Validation ROC AUC")
        for axis in axes:
            axis.tick_params(axis="x", rotation=25)
            axis.grid(alpha=0.25)
            axis.legend()
        fig.suptitle(f"Protocol sensitivity: declared feature exclusions - {self.config.dataset_title}")
        self._save_show(fig, output_dir / "declared_feature_exclusion_sensitivity.png")
        display(result.round(5))
        self.data_sensitivity = result
        return result

    def _aggregate_shap(self, transformed_shap: np.ndarray) -> np.ndarray:
        values = np.asarray(transformed_shap, dtype=float)
        return np.column_stack([
            values[:, self.group_indices[feature]].sum(axis=1)
            if len(self.group_indices[feature])
            else np.zeros(len(values), dtype=float)
            for feature in self.config.features
        ])

    def _fit_model(self, kind: str, columns: np.ndarray | None = None, **overrides):
        seed = self.config.random_state
        if kind == "logistic_regression":
            settings = dict(
                C=1.0,
                solver="lbfgs",
                max_iter=3000,
                random_state=seed,
            )
            settings.update(overrides)
            model = LogisticRegression(**settings)
        elif kind == "random_forest":
            settings = dict(
                n_estimators=150,
                max_depth=10,
                min_samples_leaf=2,
                random_state=seed,
                n_jobs=-1,
            )
            settings.update(overrides)
            model = RandomForestClassifier(**settings)
        elif kind == "neural_network":
            settings = dict(
                hidden_layer_sizes=(32, 16),
                alpha=0.01,
                max_iter=300,
                early_stopping=True,
                validation_fraction=0.15,
                n_iter_no_change=15,
                random_state=seed,
            )
            settings.update(overrides)
            model = MLPClassifier(**settings)
        else:
            raise ValueError(f"Unknown model kind: {kind}")
        training_values = self.X_train if columns is None else self.X_train[:, columns]
        model.fit(training_values, self.y_train)
        return model

    @staticmethod
    def _positive_class_shap_array(values: object) -> np.ndarray:
        if isinstance(values, list):
            values = values[1]
        array = np.asarray(values, dtype=float)
        if array.ndim == 3:
            array = array[:, :, 1]
        if array.ndim == 1:
            array = array.reshape(1, -1)
        if array.ndim != 2:
            raise ValueError(f"Expected a two-dimensional SHAP array, got {array.shape}.")
        return array

    def _transformed_shap(
        self,
        model,
        kind: str,
        cases: np.ndarray,
        background: np.ndarray,
        seed_offset: int = 0,
    ) -> np.ndarray:
        if kind == "logistic_regression":
            baseline = np.mean(background, axis=0)
            return (cases - baseline) * np.asarray(model.coef_[0], dtype=float)
        if kind == "random_forest":
            raw = shap.TreeExplainer(model).shap_values(cases, check_additivity=False)
            return self._positive_class_shap_array(raw)
        if kind == "neural_network":
            transformed = np.zeros((len(cases), cases.shape[1]), dtype=float)
            grouped = grouped_antithetic_permutation_shap(
                model,
                cases,
                background,
                self.config.features,
                self.group_indices,
                seed=self.config.random_state + seed_offset,
                permutation_pairs=self.config.nn_shap_permutation_pairs,
            )
            for feature_index, feature in enumerate(self.config.features):
                columns = self.group_indices[feature]
                if len(columns):
                    transformed[:, columns[0]] = grouped[:, feature_index]
            return transformed
        raise ValueError(f"Unknown model kind: {kind}")

    def _label(self, outcome: int) -> str:
        return self.config.positive_label if int(outcome) == 1 else self.config.negative_label

    def _feature_event(self, feature: str) -> str:
        return f"Checking {self.config.feature_labels.get(feature, feature)}"

    def _feature_log_and_traces(
        self,
        case_ids: np.ndarray,
        outcomes: np.ndarray,
        grouped_shap: np.ndarray,
        included_features: list[str] | None = None,
    ) -> tuple[pd.DataFrame, list[list[str]], list[list[str]], dict[str, list[str]]]:
        features = self.config.features if included_features is None else list(included_features)
        positions = {feature: self.config.features.index(feature) for feature in self.config.features}
        global_mean_abs = {
            feature: float(np.mean(np.abs(grouped_shap[:, positions[feature]])))
            for feature in features
        }
        rows: list[dict] = []
        open_traces: list[list[str]] = []
        closed_traces: list[list[str]] = []
        trace_lookup: dict[str, list[str]] = {}
        for row_index, (case_id, outcome) in enumerate(zip(case_ids, outcomes)):
            initially_ranked = sorted(
                [(feature, float(grouped_shap[row_index, positions[feature]])) for feature in features],
                key=lambda item: (-abs(item[1]), positions[item[0]]),
            )
            case_scale = max((abs(value) for _, value in initially_ranked), default=0.0)
            tolerance = max(1e-15, self.config.rank_tie_relative_tolerance * case_scale)
            tie_groups: list[list[tuple[str, float]]] = []
            for item in initially_ranked:
                if not tie_groups or abs(abs(item[1]) - abs(tie_groups[-1][0][1])) > tolerance:
                    tie_groups.append([item])
                else:
                    tie_groups[-1].append(item)
            ranked: list[tuple[str, float]] = []
            tie_metadata: dict[str, tuple[int, int]] = {}
            for tie_group_index, tie_group in enumerate(tie_groups, start=1):
                ordered_tie = sorted(
                    tie_group,
                    key=lambda item: (-global_mean_abs[item[0]], positions[item[0]]),
                )
                ranked.extend(ordered_tie)
                for feature, _ in ordered_tie:
                    tie_metadata[feature] = (tie_group_index, len(ordered_tie))
            events = [self._feature_event(feature) for feature, _ in ranked]
            outcome_event = f"Outcome: {self._label(int(outcome))}"
            for rank, ((feature, shap_value), event) in enumerate(zip(ranked, events), start=1):
                rows.append({
                    "CaseID": str(case_id),
                    "concept:name": event,
                    "feature_group": feature,
                    "local_shap_value": shap_value,
                    "abs_local_shap_importance": abs(shap_value),
                    "explanation_rank": rank,
                    "time:timestamp": rank,
                    "importance_tie_group": tie_metadata[feature][0],
                    "importance_tie_group_size": tie_metadata[feature][1],
                    "ground_truth": int(outcome),
                    "ground_truth_label": self._label(int(outcome)),
                })
            rows.append({
                "CaseID": str(case_id),
                "concept:name": outcome_event,
                "feature_group": "",
                "local_shap_value": 0.0,
                "abs_local_shap_importance": 0.0,
                "explanation_rank": len(events) + 1,
                "time:timestamp": len(events) + 1,
                "importance_tie_group": 0,
                "importance_tie_group_size": 1,
                "ground_truth": int(outcome),
                "ground_truth_label": self._label(int(outcome)),
            })
            open_trace = ["START", *events, outcome_event]
            open_traces.append(open_trace)
            closed_traces.append([*open_trace, "START"])
            trace_lookup[str(case_id)] = open_trace
        return pd.DataFrame(rows), open_traces, closed_traces, trace_lookup

    @staticmethod
    def _graph_edge_frame(graph: nx.DiGraph) -> pd.DataFrame:
        rows = []
        total = sum(float(data.get("weight", 0.0)) for _, _, data in graph.edges(data=True))
        for source, target, data in graph.edges(data=True):
            weight = float(data.get("weight", 0.0))
            rows.append({
                "source": source,
                "target": target,
                "frequency": int(round(weight)),
                "normalized_frequency": weight / total if total else 0.0,
            })
        return pd.DataFrame(rows).sort_values(["source", "target"]).reset_index(drop=True)

    @staticmethod
    def _write_graph(graph: nx.DiGraph, path: Path, metadata: dict | None = None) -> None:
        exported = graph.copy()
        for key, value in (metadata or {}).items():
            exported.graph[str(key)] = str(value)
        nx.write_graphml(exported, path)

    @staticmethod
    def _write_xes(event_log: pd.DataFrame, path: Path) -> None:
        log = ET.Element("log", {
            "xmlns": "http://www.xes-standard.org/",
            "xes.version": "1.0",
            "xes.features": "nested-attributes",
            "openxes.version": "1.0RC7",
        })
        ET.SubElement(
            log,
            "extension",
            {"name": "Concept", "prefix": "concept", "uri": "http://www.xes-standard.org/concept.xesext"},
        )
        for case_id, group in event_log.groupby("CaseID", sort=False):
            trace = ET.SubElement(log, "trace")
            ET.SubElement(trace, "string", {"key": "concept:name", "value": str(case_id)})
            first = group.iloc[0]
            for key in ["ground_truth_label", "prediction_label", "confusion_class"]:
                if key in group.columns and pd.notna(first.get(key)):
                    ET.SubElement(trace, "string", {"key": key, "value": str(first[key])})
            for _, row in group.sort_values("time:timestamp").iterrows():
                event = ET.SubElement(trace, "event")
                ET.SubElement(event, "string", {"key": "concept:name", "value": str(row["concept:name"])})
                ET.SubElement(
                    event,
                    "int",
                    {"key": "sequence", "value": str(int(row["time:timestamp"]))},
                )
                if "local_shap_value" in group.columns and pd.notna(row.get("local_shap_value")):
                    ET.SubElement(
                        event,
                        "float",
                        {"key": "local_shap_value", "value": f"{float(row['local_shap_value']):.17g}"},
                    )
        ET.ElementTree(log).write(path, encoding="utf-8", xml_declaration=True)

    @staticmethod
    def _save_show(fig: plt.Figure, path: Path, dpi: int = 210) -> None:
        fig.savefig(path, dpi=dpi, bbox_inches="tight")
        plt.close(fig)
        # The module uses the non-interactive Agg backend for reproducibility.
        # Display the saved raster explicitly so nbclient embeds it in the
        # notebook instead of recording only a textual ``Figure(...)`` repr.
        display(NotebookImage(filename=str(path)))

    @staticmethod
    def _model_probabilities(model, values: np.ndarray) -> np.ndarray:
        return np.asarray(model.predict_proba(values)[:, 1], dtype=float)

    def _graph_measure_row(self, open_graph: nx.DiGraph, closed_graph: nx.DiGraph) -> dict[str, float]:
        open_measures = open_graph_measures(open_graph)
        feature_count = max(1.0, open_measures["rank_feature_nodes"])
        return {
            **open_measures,
            "effective_transition_dimension_per_feature": (
                open_measures["effective_transition_dimension_q"] / feature_count
            ),
            "information_distance_per_rank_step": (
                open_measures["information_distance_mean_path"] / (feature_count + 1.0)
            ),
            **markov_entropy_measures(closed_graph),
        }

    def _graph_case_bootstrap_intervals(
        self,
        open_traces: list[list[str]],
        closed_traces: list[list[str]],
        *,
        bootstraps: int,
        seed: int,
    ) -> dict[str, float]:
        metrics = [
            "ks_entropy_bits_per_transition",
            "normalized_ks_entropy",
            "entropy_bits_per_case_cycle",
            "branching_state_entropy_bits",
            "rank_excess_edge_occupancy",
        ]
        if not open_traces or bootstraps <= 0:
            return {
                f"case_bootstrap_{metric}_{suffix}": np.nan
                for metric in metrics
                for suffix in ["sd", "p025", "p975"]
            }
        rng = np.random.default_rng(seed)
        values = {metric: [] for metric in metrics}
        case_count = len(open_traces)
        for _ in range(int(bootstraps)):
            sampled = rng.choice(case_count, size=case_count, replace=True)
            measures = self._graph_measure_row(
                build_dfg([open_traces[index] for index in sampled]),
                build_dfg([closed_traces[index] for index in sampled]),
            )
            for metric in metrics:
                values[metric].append(float(measures[metric]))
        result = {}
        for metric, samples in values.items():
            stats = _interval(samples)
            for suffix in ["sd", "p025", "p975"]:
                result[f"case_bootstrap_{metric}_{suffix}"] = stats[suffix]
        return result

    def _evaluate_fitted_model(
        self,
        model,
        kind: str,
        probe_indices: np.ndarray | None = None,
        background_indices: np.ndarray | None = None,
        seed_offset: int = 0,
    ) -> dict:
        probe_indices = self.probe_indices if probe_indices is None else np.asarray(probe_indices, dtype=int)
        background_indices = (
            self.background_indices
            if background_indices is None
            else np.asarray(background_indices, dtype=int)
        )
        validation_probabilities = self._model_probabilities(model, self.X_validation)
        test_probabilities = self._model_probabilities(model, self.X_test)
        probe_probabilities = validation_probabilities[probe_indices]
        probe_predictions = (probe_probabilities >= 0.5).astype(int)
        transformed_shap = self._transformed_shap(
            model,
            kind,
            self.X_validation[probe_indices],
            self.X_train[background_indices],
            seed_offset=seed_offset,
        )
        grouped_shap = self._aggregate_shap(transformed_shap)
        case_ids = self.validation_data.iloc[probe_indices][self.config.case_id_column].to_numpy(dtype=object)
        outcomes = self.y_validation[probe_indices]
        feature_log, open_traces, closed_traces, trace_lookup = self._feature_log_and_traces(
            case_ids, outcomes, grouped_shap
        )
        open_graph = build_dfg(open_traces)
        closed_graph = build_dfg(closed_traces)
        return {
            "model": model,
            "kind": kind,
            "validation_probabilities": validation_probabilities,
            "validation_predictions": (validation_probabilities >= 0.5).astype(int),
            "test_probabilities": test_probabilities,
            "test_predictions": (test_probabilities >= 0.5).astype(int),
            "probe_indices": probe_indices,
            "probe_case_ids": case_ids,
            "probe_outcomes": outcomes,
            "probe_probabilities": probe_probabilities,
            "probe_predictions": probe_predictions,
            "grouped_shap": grouped_shap,
            "feature_log": feature_log,
            "open_traces": open_traces,
            "closed_traces": closed_traces,
            "trace_lookup": trace_lookup,
            "open_graph": open_graph,
            "closed_graph": closed_graph,
        }

    def run_task1(self) -> pd.DataFrame:
        """Fit three models and compare their ground-truth-ended feature DFGs."""
        output_dir = self.root / "task1_outputs"
        output_dir.mkdir(exist_ok=True)
        model_settings = {
            "logistic_regression": {},
            "random_forest": {},
            "neural_network": {},
        }
        summary_rows = []
        training_ranking_rows = []
        for model_index, (kind, settings) in enumerate(model_settings.items()):
            label = self.MODEL_LABELS[kind]
            print(f"Task 1: fitting and explaining {label}...")
            model = self._fit_model(kind, **settings)
            artifact = self._evaluate_fitted_model(model, kind, seed_offset=100 * model_index)
            ranking_transformed_shap = self._transformed_shap(
                model,
                kind,
                self.X_train[self.ranking_indices],
                self.X_train[self.background_indices],
                seed_offset=50000 + 100 * model_index,
            )
            ranking_grouped_shap = self._aggregate_shap(ranking_transformed_shap)
            ranking_mean_abs = np.mean(np.abs(ranking_grouped_shap), axis=0)
            training_feature_order = sorted(
                self.config.features,
                key=lambda feature: (
                    -float(ranking_mean_abs[self.config.features.index(feature)]),
                    self.config.features.index(feature),
                ),
            )
            artifact["training_ranking_grouped_shap"] = ranking_grouped_shap
            artifact["training_feature_order"] = training_feature_order
            for rank, feature in enumerate(training_feature_order, start=1):
                training_ranking_rows.append(
                    {
                        "model": kind,
                        "model_label": label,
                        "feature_rank": rank,
                        "feature_group": feature,
                        "training_mean_abs_grouped_shap": float(
                            ranking_mean_abs[self.config.features.index(feature)]
                        ),
                        "ranking_cases": len(self.ranking_indices),
                        "ranking_source": (
                            "fixed training cohort; full baseline model mean absolute grouped SHAP"
                        ),
                    }
                )
            self.task1_artifacts[kind] = artifact
            measures = self._graph_measure_row(artifact["open_graph"], artifact["closed_graph"])
            graph_intervals = self._graph_case_bootstrap_intervals(
                artifact["open_traces"],
                artifact["closed_traces"],
                bootstraps=self.config.task1_bootstraps,
                seed=self.config.random_state + 1200 + model_index,
            )
            feature_rows = artifact["feature_log"][artifact["feature_log"]["feature_group"].ne("")]
            case_has_tie = feature_rows.groupby("CaseID")["importance_tie_group_size"].max().gt(1)
            row = {
                "model": kind,
                "model_label": label,
                "explained_cases": len(artifact["probe_case_ids"]),
                "features_per_trace": len(self.config.features),
                "cases_with_importance_tie_rate": float(case_has_tie.mean()) if len(case_has_tie) else 0.0,
                "feature_events_in_nontrivial_ties_rate": float(
                    feature_rows["importance_tie_group_size"].gt(1).mean()
                ) if len(feature_rows) else 0.0,
                **predictive_metrics(self.y_validation, artifact["validation_probabilities"], "validation"),
                **predictive_metrics(self.y_test, artifact["test_probabilities"], "test"),
                **measures,
                **graph_intervals,
            }
            if kind == "neural_network":
                row["training_iterations"] = int(model.n_iter_)
                row["early_stopping_enabled"] = bool(model.early_stopping)
            summary_rows.append(row)
            artifact["feature_log"].to_csv(output_dir / f"{kind}_feature_log.csv", index=False)
            self._write_xes(artifact["feature_log"], output_dir / f"{kind}_feature_log.xes")
            self._write_graph(
                artifact["open_graph"],
                output_dir / f"{kind}_open_dfg.graphml",
                {"model": label, "endpoint": "ground truth"},
            )
            self._write_graph(
                artifact["closed_graph"],
                output_dir / f"{kind}_restart_closed_dfg.graphml",
                {"model": label, "endpoint": "ground truth", "closure": "outcome to START"},
            )
            self._graph_edge_frame(artifact["open_graph"]).to_csv(
                output_dir / f"{kind}_dfg_edges.csv", index=False
            )

        summary = pd.DataFrame(summary_rows)
        pd.DataFrame(training_ranking_rows).to_csv(
            output_dir / "model_training_feature_group_rankings.csv", index=False
        )
        metric_rng = np.random.default_rng(self.config.random_state + 1151)
        metric_bootstrap_rows = []
        for bootstrap_id in range(self.config.task1_metric_bootstraps):
            sampled = _stratified_bootstrap_indices(self.y_validation, metric_rng)
            for kind, artifact in self.task1_artifacts.items():
                metric_bootstrap_rows.append({
                    "bootstrap_id": bootstrap_id + 1,
                    "model": kind,
                    **predictive_metrics(
                        self.y_validation[sampled],
                        artifact["validation_probabilities"][sampled],
                        "validation",
                    ),
                })
        metric_bootstraps = pd.DataFrame(metric_bootstrap_rows)
        metric_interval_rows = []
        metric_columns = [
            "validation_accuracy",
            "validation_balanced_accuracy",
            "validation_roc_auc",
            "validation_log_loss",
            "validation_brier_score",
        ]
        for kind, group in metric_bootstraps.groupby("model", sort=False):
            row = {"model": kind}
            for metric in metric_columns:
                stats = _interval(group[metric].to_numpy(dtype=float))
                row.update({f"{metric}_bootstrap_{key}": value for key, value in stats.items()})
            metric_interval_rows.append(row)
        metric_intervals = pd.DataFrame(metric_interval_rows)
        summary = summary.merge(metric_intervals, on="model", how="left")
        paired_metric_rows = []
        for left, right in combinations(self.task1_artifacts, 2):
            left_frame = metric_bootstraps[metric_bootstraps["model"].eq(left)].sort_values("bootstrap_id")
            right_frame = metric_bootstraps[metric_bootstraps["model"].eq(right)].sort_values("bootstrap_id")
            for metric in metric_columns:
                differences = (
                    left_frame[metric].to_numpy(dtype=float)
                    - right_frame[metric].to_numpy(dtype=float)
                )
                paired_metric_rows.append({
                    "left_model": left,
                    "right_model": right,
                    "metric": metric,
                    **{f"difference_{key}": value for key, value in _interval(differences).items()},
                })
        paired_metric_differences = pd.DataFrame(paired_metric_rows)
        summary.to_csv(output_dir / "model_graph_summary.csv", index=False)
        metric_bootstraps.to_csv(output_dir / "validation_metric_bootstrap_replicates.csv", index=False)
        metric_intervals.to_csv(output_dir / "validation_metric_bootstrap_intervals.csv", index=False)
        paired_metric_differences.to_csv(
            output_dir / "paired_validation_metric_differences.csv", index=False
        )
        names = list(self.task1_artifacts)
        pair_rows = []
        bootstrap_rows = []
        bootstrap_rng = np.random.default_rng(self.config.random_state + 1101)
        for left_index in range(len(names)):
            for right_index in range(left_index + 1, len(names)):
                left = names[left_index]
                right = names[right_index]
                left_artifact = self.task1_artifacts[left]
                right_artifact = self.task1_artifacts[right]
                pair_rows.append({
                    "left_model": left,
                    "right_model": right,
                    "supervisor_formula_similarity": supervisor_dfg_similarity(
                        left_artifact["open_graph"], right_artifact["open_graph"]
                    ),
                    "our_similarity_measure": l1_dfg_similarity(
                        left_artifact["open_graph"], right_artifact["open_graph"]
                    ),
                })
                case_count = len(left_artifact["open_traces"])
                for bootstrap_id in range(self.config.task1_bootstraps):
                    sampled = bootstrap_rng.choice(case_count, size=case_count, replace=True)
                    left_graph = build_dfg([left_artifact["open_traces"][i] for i in sampled])
                    right_graph = build_dfg([right_artifact["open_traces"][i] for i in sampled])
                    bootstrap_rows.append({
                        "bootstrap_id": bootstrap_id + 1,
                        "left_model": left,
                        "right_model": right,
                        "supervisor_formula_similarity": supervisor_dfg_similarity(left_graph, right_graph),
                        "our_similarity_measure": l1_dfg_similarity(left_graph, right_graph),
                    })
        pairwise = pd.DataFrame(pair_rows)
        bootstraps = pd.DataFrame(bootstrap_rows)
        interval_rows = []
        for (left, right), group in bootstraps.groupby(["left_model", "right_model"]):
            row = {"left_model": left, "right_model": right}
            for measure in ["supervisor_formula_similarity", "our_similarity_measure"]:
                stats = _interval(group[measure].to_numpy())
                row.update({f"{measure}_{name}": value for name, value in stats.items()})
            interval_rows.append(row)
        intervals = pd.DataFrame(interval_rows)
        pairwise.to_csv(output_dir / "pairwise_dfg_formula_scores.csv", index=False)
        bootstraps.to_csv(output_dir / "pairwise_similarity_bootstrap_replicates.csv", index=False)
        intervals.to_csv(output_dir / "pairwise_similarity_intervals.csv", index=False)

        for fig, filename in task1_similarity_figures(pairwise, self.config.dataset_title):
            self._save_show(fig, output_dir / filename)
        display(summary.round(5))
        display(pairwise.round(5))
        self.task1_summary = summary
        self.task1_pairwise = pairwise
        return summary

    def run_task2_baseline(self) -> pd.DataFrame:
        """Calculate occupancy-weighted first-order Markov entropy rates."""
        if not self.task1_artifacts:
            self.run_task1()
        output_dir = self.root / "task2_outputs"
        output_dir.mkdir(exist_ok=True)
        rows = []
        for kind, artifact in self.task1_artifacts.items():
            actual_closed = artifact["closed_graph"]
            predicted_open_traces = []
            for trace, prediction in zip(artifact["open_traces"], artifact["probe_predictions"]):
                predicted_open_traces.append([
                    *trace[:-1],
                    f"Outcome: {self._label(int(prediction))}",
                ])
            predicted_closed = build_dfg([[*trace, "START"] for trace in predicted_open_traces])
            for endpoint, graph, open_traces in [
                ("ground_truth", actual_closed, artifact["open_traces"]),
                ("prediction", predicted_closed, predicted_open_traces),
            ]:
                entropy_measures = markov_entropy_measures(graph)
                graph_intervals = self._graph_case_bootstrap_intervals(
                    open_traces,
                    [[*trace, "START"] for trace in open_traces],
                    bootstraps=self.config.task2_graph_bootstraps,
                    seed=(
                        self.config.random_state
                        + 2000
                        + 100 * list(self.task1_artifacts).index(kind)
                        + int(endpoint == "prediction")
                    ),
                )
                rows.append({
                    "model": kind,
                    "model_label": self.MODEL_LABELS[kind],
                    "endpoint": endpoint,
                    **entropy_measures,
                    **graph_intervals,
                    "nodes": graph.number_of_nodes(),
                    "edges": graph.number_of_edges(),
                })
                self._write_graph(
                    graph,
                    output_dir / f"{kind}_{endpoint}_restart_closed_dfg.graphml",
                    {"model": self.MODEL_LABELS[kind], "endpoint": endpoint},
                )
        result = pd.DataFrame(rows)
        result.to_csv(output_dir / "baseline_model_entropy.csv", index=False)
        pivot = result.pivot(index="model_label", columns="endpoint", values="ks_entropy_bits_per_transition")
        pivot.plot(kind="bar", figsize=(9, 4.8), color=["#2f6690", "#c05a47"])
        fig = plt.gcf()
        axis = plt.gca()
        axis.set_ylabel("KS entropy rate (bits/transition)")
        axis.set_xlabel("")
        axis.set_title(f"Task 2: ground-truth and prediction entropy - {self.config.dataset_title}")
        axis.grid(axis="y", alpha=0.25)
        axis.legend(title="DFG endpoint")
        fig.tight_layout()
        self._save_show(fig, output_dir / "baseline_model_entropy.png")
        display(result.round(6))
        self.task2_entropy = result
        return result

    def _evaluate_setting(
        self,
        kind: str,
        setting_name: str,
        output_dir: Path,
        seed_offset: int = 0,
        **model_overrides,
    ) -> tuple[dict, dict]:
        model = self._fit_model(kind, **model_overrides)
        artifact = self._evaluate_fitted_model(
            model,
            kind,
            probe_indices=self.sweep_probe_indices,
            background_indices=self.sweep_background_indices,
            seed_offset=seed_offset,
        )
        train_probabilities = self._model_probabilities(model, self.X_train)
        validation_metrics = predictive_metrics(
            self.y_validation, artifact["validation_probabilities"], "validation"
        )
        train_metrics = predictive_metrics(self.y_train, train_probabilities, "train")
        graph_intervals = self._graph_case_bootstrap_intervals(
            artifact["open_traces"],
            artifact["closed_traces"],
            bootstraps=self.config.task2_graph_bootstraps,
            seed=self.config.random_state + 2900 + seed_offset,
        )
        metrics = {
            "setting": setting_name,
            **train_metrics,
            **validation_metrics,
            "accuracy_generalization_gap_train_minus_validation": (
                train_metrics["train_accuracy"] - validation_metrics["validation_accuracy"]
            ),
            "roc_auc_generalization_gap_train_minus_validation": (
                train_metrics["train_roc_auc"] - validation_metrics["validation_roc_auc"]
            ),
            **self._graph_measure_row(artifact["open_graph"], artifact["closed_graph"]),
            **graph_intervals,
        }
        if kind == "neural_network":
            metrics.update({
                "training_iterations": int(model.n_iter_),
                "converged_before_max_iter": bool(model.n_iter_ < model.max_iter),
                "early_stopping_enabled": bool(model.early_stopping),
                "best_internal_validation_score": float(max(model.validation_scores_))
                if model.early_stopping and getattr(model, "validation_scores_", None)
                else np.nan,
            })
        stem = _safe_name(setting_name).lower()
        artifact["feature_log"].to_csv(output_dir / f"{stem}_feature_log.csv", index=False)
        self._write_graph(
            artifact["open_graph"],
            output_dir / f"{stem}_open_dfg.graphml",
            {"setting": setting_name, "model_kind": kind},
        )
        self._write_graph(
            artifact["closed_graph"],
            output_dir / f"{stem}_restart_closed_dfg.graphml",
            {"setting": setting_name, "model_kind": kind},
        )
        return metrics, artifact

    def _plot_sweep(
        self,
        frame: pd.DataFrame,
        parameter: str,
        title: str,
        output_path: Path,
    ) -> None:
        x = np.arange(len(frame))
        labels = frame[parameter].astype(str).tolist()
        fig, axes = plt.subplots(1, 3, figsize=(15, 4.6), constrained_layout=True)
        axes[0].plot(x, 100 * frame["validation_accuracy"], marker="o", label="Accuracy")
        axes[0].plot(x, 100 * frame["validation_balanced_accuracy"], marker="s", label="Balanced accuracy")
        axes[0].set_ylabel("Validation score (%)")
        axes[0].legend()
        axes[1].plot(x, frame["validation_roc_auc"], marker="o", color="#3a7d44")
        axes[1].set_ylabel("Validation ROC AUC")
        axes[1].set_ylim(0.45, 1.01)
        axes[2].plot(x, frame["ks_entropy_bits_per_transition"], marker="o", color="#b56576")
        axes[2].set_ylabel("KS entropy (bits/transition)")
        for axis in axes:
            axis.set_xticks(x, labels, rotation=35, ha="right")
            axis.set_xlabel(parameter)
            axis.grid(alpha=0.25)
        fig.suptitle(f"{title} - {self.config.dataset_title}")
        self._save_show(fig, output_path)

    def run_task2_1(self) -> pd.DataFrame:
        """Random Forest max-depth sensitivity."""
        output_dir = self.root / "task2_1_outputs"
        output_dir.mkdir(exist_ok=True)
        rows = []
        artifacts = {}
        for setting_index, depth in enumerate([1, 2, 3, 5, 10, None]):
            label = "unlimited" if depth is None else str(depth)
            print(f"Task 2.1: Random Forest max_depth={label}")
            metrics, artifact = self._evaluate_setting(
                "random_forest",
                f"random_forest_depth_{label}",
                output_dir,
                seed_offset=2100 + setting_index,
                max_depth=depth,
            )
            rows.append({"max_depth": label, **metrics})
            artifacts[label] = artifact
        result = pd.DataFrame(rows)
        result.to_csv(output_dir / "random_forest_depth_validation_entropy.csv", index=False)
        self._plot_sweep(
            result,
            "max_depth",
            "Task 2.1: Random Forest depth",
            output_dir / "validation_vs_ks_entropy.png",
        )
        display(result[[
            "max_depth", "validation_accuracy", "validation_balanced_accuracy",
            "validation_roc_auc", "ks_entropy_bits_per_transition",
        ]].round(5))
        self.task2_1_artifacts = artifacts
        return result

    def run_task2_2(self) -> pd.DataFrame:
        """Logistic Regression L2-C sensitivity."""
        output_dir = self.root / "task2_2_outputs"
        output_dir.mkdir(exist_ok=True)
        rows = []
        artifacts = {}
        c_values = [0.001, 0.01, 0.1, 1.0, 10.0, 100.0]
        for setting_index, c_value in enumerate(c_values):
            print(f"Task 2.2: Logistic Regression C={c_value:g}")
            metrics, artifact = self._evaluate_setting(
                "logistic_regression",
                f"logistic_regression_c_{c_value:g}",
                output_dir,
                seed_offset=2200 + setting_index,
                C=c_value,
            )
            rows.append({"C": c_value, **metrics})
            artifacts[c_value] = artifact
        result = pd.DataFrame(rows)
        result.to_csv(output_dir / "logistic_regression_c_validation_entropy.csv", index=False)
        self._plot_sweep(
            result,
            "C",
            "Task 2.2: Logistic Regression regularization",
            output_dir / "validation_vs_ks_entropy.png",
        )
        display(result[[
            "C", "validation_accuracy", "validation_balanced_accuracy",
            "validation_roc_auc", "ks_entropy_bits_per_transition",
        ]].round(5))
        self.task2_2_artifacts = artifacts
        return result

    def run_task2_3(self) -> dict[str, pd.DataFrame]:
        """Neural-network alpha, architecture, and early-stopping diagnostics."""
        alpha_dir = self.root / "task2_3_outputs"
        arch_dir = self.root / "task2_3_1_outputs"
        early_dir = self.root / "task2_3_2_outputs"
        for directory in [alpha_dir, arch_dir, early_dir]:
            directory.mkdir(exist_ok=True)

        alpha_rows = []
        for index, alpha in enumerate([1.0, 0.1, 0.01, 0.001, 0.0001]):
            print(f"Task 2.3: Neural Network alpha={alpha:g}")
            metrics, _ = self._evaluate_setting(
                "neural_network",
                f"neural_network_alpha_{alpha:g}",
                alpha_dir,
                seed_offset=2300 + index,
                alpha=alpha,
            )
            alpha_rows.append({"alpha": alpha, **metrics})
        alpha_df = pd.DataFrame(alpha_rows)
        alpha_df.to_csv(alpha_dir / "neural_network_alpha_validation_entropy.csv", index=False)
        self._plot_sweep(
            alpha_df,
            "alpha",
            "Task 2.3: Neural Network alpha",
            alpha_dir / "alpha_validation_vs_entropy.png",
        )

        architectures = [(4, 2), (16, 8), (32, 16), (100, 50)]
        architecture_rows = []
        for index, architecture in enumerate(architectures):
            print(f"Task 2.3.1: Neural Network architecture={architecture}")
            metrics, _ = self._evaluate_setting(
                "neural_network",
                f"neural_network_architecture_{architecture}",
                arch_dir,
                seed_offset=2400 + index,
                hidden_layer_sizes=architecture,
                alpha=0.01,
            )
            architecture_rows.append({"hidden_layer_sizes": str(architecture), **metrics})
        architecture_df = pd.DataFrame(architecture_rows)
        architecture_df.to_csv(
            arch_dir / "neural_network_architecture_validation_entropy.csv", index=False
        )
        self._plot_sweep(
            architecture_df,
            "hidden_layer_sizes",
            "Task 2.3.1: Neural Network architecture",
            arch_dir / "architecture_validation_vs_entropy.png",
        )

        early_rows = []
        for architecture_index, architecture in enumerate([(4, 2), (32, 16), (100, 50)]):
            for enabled in [True, False]:
                print(
                    "Task 2.3.2: Neural Network "
                    f"architecture={architecture}, early_stopping={enabled}"
                )
                metrics, _ = self._evaluate_setting(
                    "neural_network",
                    f"neural_network_{architecture}_early_stopping_{enabled}",
                    early_dir,
                    seed_offset=2500 + 2 * architecture_index + int(enabled),
                    hidden_layer_sizes=architecture,
                    alpha=0.01,
                    early_stopping=enabled,
                )
                early_rows.append({
                    "hidden_layer_sizes": str(architecture),
                    "early_stopping": enabled,
                    **metrics,
                })
        early_df = pd.DataFrame(early_rows)
        early_df.to_csv(early_dir / "early_stopping_validation_performance.csv", index=False)

        fig, axes = plt.subplots(1, 3, figsize=(15, 4.8), constrained_layout=True)
        colors = {True: "#2f6690", False: "#c05a47"}
        metrics_to_plot = [
            ("validation_accuracy", "Validation accuracy"),
            ("validation_roc_auc", "Validation ROC AUC"),
            ("ks_entropy_bits_per_transition", "KS entropy (bits/transition)"),
        ]
        positions = np.arange(3)
        for axis, (metric, label) in zip(axes, metrics_to_plot):
            for offset, enabled in [(-0.16, True), (0.16, False)]:
                subset = early_df[early_df["early_stopping"].eq(enabled)]
                axis.bar(
                    positions + offset,
                    subset[metric],
                    width=0.31,
                    color=colors[enabled],
                    label=f"early_stopping={enabled}",
                )
            axis.set_xticks(positions, ["(4, 2)", "(32, 16)", "(100, 50)"])
            axis.set_ylabel(label)
            axis.grid(axis="y", alpha=0.25)
        axes[0].legend()
        fig.suptitle(f"Task 2.3.2: early-stopping verification - {self.config.dataset_title}")
        self._save_show(fig, early_dir / "early_stopping_validation_comparison.png")
        display(alpha_df[["alpha", "validation_accuracy", "validation_roc_auc", "ks_entropy_bits_per_transition"]].round(5))
        display(architecture_df[["hidden_layer_sizes", "validation_accuracy", "validation_roc_auc", "ks_entropy_bits_per_transition"]].round(5))
        display(early_df[[
            "hidden_layer_sizes", "early_stopping", "training_iterations",
            "validation_accuracy", "validation_roc_auc", "ks_entropy_bits_per_transition",
        ]].round(5))
        self.task2_3_artifacts = {
            "alpha": alpha_df,
            "architecture": architecture_df,
            "early_stopping": early_df,
        }
        return self.task2_3_artifacts

    def _groups_for_indices(self, selected_indices: np.ndarray) -> list[str]:
        selected = set(np.asarray(selected_indices, dtype=int).tolist())
        return [
            feature
            for feature in self.config.features
            if selected.intersection(self.group_indices[feature].tolist())
        ]

    def _indices_for_groups(self, groups: list[str]) -> np.ndarray:
        pieces = [self.group_indices[group] for group in groups if len(self.group_indices[group])]
        return np.sort(np.concatenate(pieces)).astype(int) if pieces else np.asarray([], dtype=int)

    @staticmethod
    def _design_rank(values: np.ndarray, selected_indices: np.ndarray) -> int:
        if len(selected_indices) == 0:
            return 1
        design = np.column_stack([np.ones(len(values)), values[:, selected_indices]])
        return int(np.linalg.matrix_rank(design))

    def _fit_post_lasso(self, c_value: float) -> dict:
        selector = LogisticRegression(
            C=float(c_value),
            l1_ratio=1.0,
            solver="liblinear",
            max_iter=5000,
            random_state=self.config.random_state,
        )
        selector.fit(self.X_train, self.y_train)
        selected_indices = np.flatnonzero(np.abs(selector.coef_[0]) > 1e-8)
        if len(selected_indices) == 0:
            probability = float(np.mean(self.y_train))
            model = None
            train_probabilities = np.full(len(self.y_train), probability)
            validation_probabilities = np.full(len(self.y_validation), probability)
        else:
            model = LogisticRegression(
                C=np.inf,
                solver="lbfgs",
                max_iter=5000,
                random_state=self.config.random_state,
            )
            model.fit(self.X_train[:, selected_indices], self.y_train)
            train_probabilities = model.predict_proba(self.X_train[:, selected_indices])[:, 1]
            validation_probabilities = model.predict_proba(self.X_validation[:, selected_indices])[:, 1]
        return {
            "selector": selector,
            "selected_indices": selected_indices,
            "selected_groups": self._groups_for_indices(selected_indices),
            "model": model,
            "train_probabilities": np.asarray(train_probabilities, dtype=float),
            "validation_probabilities": np.asarray(validation_probabilities, dtype=float),
        }

    def _linear_grouped_shap(
        self,
        model,
        selected_indices: np.ndarray,
        cases: np.ndarray,
        background: np.ndarray,
    ) -> np.ndarray:
        full_values = np.zeros((len(cases), self.X_train.shape[1]), dtype=float)
        if model is not None and len(selected_indices):
            baseline = np.mean(background[:, selected_indices], axis=0)
            full_values[:, selected_indices] = (
                cases[:, selected_indices] - baseline
            ) * np.asarray(model.coef_[0], dtype=float)
        return self._aggregate_shap(full_values)

    def run_task2_4(self) -> pd.DataFrame:
        """L1 support path with post-LASSO refitting, DFG measures, AIC, and BIC."""
        output_dir = self.root / "task2_4_outputs"
        output_dir.mkdir(exist_ok=True)
        c_values = [
            0.0001, 0.0003, 0.001, 0.003, 0.01, 0.03,
            0.1, 0.3, 1.0, 3.0, 10.0, 100.0,
        ]
        rows = []
        support_rows = []
        artifacts: dict[float, dict] = {}
        probe_cases = self.X_validation[self.probe_indices]
        background = self.X_train[self.background_indices]
        for c_value in c_values:
            print(f"Task 2.4: L1 C={c_value:g} with post-LASSO refitting")
            fitted = self._fit_post_lasso(c_value)
            selected_indices = fitted["selected_indices"]
            selected_groups = fitted["selected_groups"]
            grouped_shap = self._linear_grouped_shap(
                fitted["model"], selected_indices, probe_cases, background
            )
            feature_log, open_traces, closed_traces, trace_lookup = self._feature_log_and_traces(
                self.probe_case_ids,
                self.probe_outcomes,
                grouped_shap,
                included_features=selected_groups,
            )
            open_graph = build_dfg(open_traces)
            closed_graph = build_dfg(closed_traces)
            train_probability = np.clip(fitted["train_probabilities"], 1e-12, 1 - 1e-12)
            log_likelihood = float(np.sum(
                self.y_train * np.log(train_probability)
                + (1 - self.y_train) * np.log(1 - train_probability)
            ))
            parameter_rank = self._design_rank(self.X_train, selected_indices)
            aic = 2 * parameter_rank - 2 * log_likelihood
            aicc_correction = (
                2 * parameter_rank * (parameter_rank + 1)
                / (len(self.y_train) - parameter_rank - 1)
                if len(self.y_train) > parameter_rank + 1
                else np.inf
            )
            row = {
                "C": c_value,
                "setting": f"C={c_value:g}",
                "selected_transformed_feature_count": len(selected_indices),
                "selected_original_feature_group_count": len(selected_groups),
                "selected_original_feature_groups": " | ".join(selected_groups),
                "design_rank_p": parameter_rank,
                "training_log_likelihood": log_likelihood,
                "AIC": aic,
                "AICc": aic + aicc_correction,
                "BIC": math.log(len(self.y_train)) * parameter_rank - 2 * log_likelihood,
                **predictive_metrics(
                    self.y_validation, fitted["validation_probabilities"], "validation"
                ),
                **self._graph_measure_row(open_graph, closed_graph),
                "post_selection_information_criteria": True,
                "test_cases_used": False,
            }
            rows.append(row)
            for transformed_index in selected_indices:
                transformed_name = str(self.transformed_names[transformed_index])
                matching_groups = [
                    group
                    for group in self.config.features
                    if transformed_index in self.group_indices[group]
                ]
                support_rows.append({
                    "C": c_value,
                    "transformed_feature_index": int(transformed_index),
                    "transformed_feature": transformed_name,
                    "feature_group": matching_groups[0] if matching_groups else "",
                    "selector_coefficient": float(fitted["selector"].coef_[0, transformed_index]),
                })
            stem = f"c_{_safe_name(f'{c_value:g}')}"
            feature_log.to_csv(output_dir / f"{stem}_feature_log.csv", index=False)
            self._write_graph(
                open_graph,
                output_dir / f"{stem}_open_dfg.graphml",
                {"C": c_value, "selected_groups": " | ".join(selected_groups)},
            )
            self._write_graph(
                closed_graph,
                output_dir / f"{stem}_restart_closed_dfg.graphml",
                {"C": c_value, "selected_groups": " | ".join(selected_groups)},
            )
            artifacts[c_value] = {
                **fitted,
                "grouped_shap": grouped_shap,
                "feature_log": feature_log,
                "open_traces": open_traces,
                "closed_traces": closed_traces,
                "trace_lookup": trace_lookup,
                "open_graph": open_graph,
                "closed_graph": closed_graph,
            }
        result = pd.DataFrame(rows).sort_values("C").reset_index(drop=True)
        full_indices = self._indices_for_groups(self.config.features)
        full_model = LogisticRegression(
            C=np.inf,
            solver="lbfgs",
            max_iter=5000,
            random_state=self.config.random_state,
        ).fit(self.X_train[:, full_indices], self.y_train)
        full_grouped_shap = self._linear_grouped_shap(
            full_model, full_indices, probe_cases, background
        )
        _, full_open_traces, _, _ = self._feature_log_and_traces(
            self.probe_case_ids,
            self.probe_outcomes,
            full_grouped_shap,
            included_features=self.config.features,
        )
        full_graph = build_dfg(full_open_traces)
        result["our_similarity_measure_to_full_support_dfg"] = [
            l1_dfg_similarity(artifacts[c_value]["open_graph"], full_graph)
            for c_value in result["C"]
        ]
        result["supervisor_formula_similarity_to_full_support_dfg"] = [
            supervisor_dfg_similarity(artifacts[c_value]["open_graph"], full_graph)
            for c_value in result["C"]
        ]
        result["our_similarity_measure_to_previous"] = np.nan
        for index in range(1, len(result)):
            previous_c = float(result.loc[index - 1, "C"])
            current_c = float(result.loc[index, "C"])
            result.loc[index, "our_similarity_measure_to_previous"] = l1_dfg_similarity(
                artifacts[previous_c]["open_graph"], artifacts[current_c]["open_graph"]
            )
        result["delta_AIC_from_minimum"] = result["AIC"] - result["AIC"].min()
        result["delta_AICc_from_minimum"] = result["AICc"] - result["AICc"].min()
        result["delta_BIC_from_minimum"] = result["BIC"] - result["BIC"].min()
        result.to_csv(output_dir / "hyperparameter_model_dfg_measures.csv", index=False)
        pd.DataFrame(support_rows).to_csv(output_dir / "l1_transformed_feature_support.csv", index=False)

        x = result["C"].to_numpy(dtype=float)
        fig, axes = plt.subplots(3, 3, figsize=(18, 14), constrained_layout=True)
        axes = axes.ravel()
        axes[0].plot(x, 100 * result["validation_accuracy"], marker="o", label="Accuracy")
        axes[0].plot(x, 100 * result["validation_balanced_accuracy"], marker="s", label="Balanced accuracy")
        axes[0].set_ylabel("Validation score (%)")
        axes[0].legend()
        axes[1].plot(x, result["validation_roc_auc"], marker="o", color="#3a7d44")
        axes[1].set_ylabel("Validation ROC AUC")
        axes[2].step(x, result["selected_original_feature_group_count"], where="mid", label="Original groups")
        axes[2].step(x, result["selected_transformed_feature_count"], where="mid", label="Transformed columns")
        axes[2].set_ylabel("Selected features")
        axes[2].legend()
        axes[3].plot(x, result["our_similarity_measure_to_full_support_dfg"], marker="o", color="#2f6690")
        axes[3].set_ylabel("Similarity to full-support DFG")
        axes[3].set_title("Normalized-frequency L1 similarity")
        axes[4].plot(x, result["open_dfg_density"], marker="o", color="#c05a47")
        axes[4].set_ylabel("Directed density")
        axes[5].plot(x, result["directed_reachable_diameter"], marker="o", color="#7a5195")
        axes[5].set_ylabel("Directed reachable diameter")
        axes[6].plot(x, result["mean_out_closeness"], marker="o", color="#3a7d44")
        axes[6].set_ylabel("Mean outward closeness")
        axes[7].plot(x, result["mean_betweenness"], marker="o", label="Betweenness")
        axes[7].plot(x, result["mean_undirected_eigenvector"], marker="s", label="Eigenvector")
        axes[7].set_ylabel("Mean centrality")
        axes[7].legend()
        axes[8].plot(x, result["delta_AIC_from_minimum"], marker="o", label="Delta AIC")
        axes[8].plot(x, result["delta_AICc_from_minimum"], marker="^", label="Delta AICc")
        axes[8].plot(x, result["delta_BIC_from_minimum"], marker="s", label="Delta BIC")
        axes[8].set_ylabel("Difference from minimum")
        axes[8].legend()
        for axis in axes:
            axis.set_xscale("log")
            axis.set_xlabel("L1 inverse regularization C")
            axis.grid(alpha=0.25)
        fig.suptitle(
            f"Task 2.4: hyperparameter, performance, DFG measures, AIC and BIC - {self.config.dataset_title}"
        )
        self._save_show(fig, output_dir / "task2_4_nine_measure_comparison.png", dpi=220)
        display(result[[
            "C", "selected_original_feature_group_count", "selected_transformed_feature_count",
            "validation_accuracy", "validation_balanced_accuracy", "validation_roc_auc",
            "ks_entropy_bits_per_transition", "our_similarity_measure_to_full_support_dfg",
            "AIC", "AICc", "BIC",
        ]].round(5))
        self.task2_4_artifacts = {
            "results": result,
            "supports": pd.DataFrame(support_rows),
            "settings": artifacts,
            "full_reference_graph": full_graph,
        }
        return result

    @staticmethod
    def _minmax(values: np.ndarray) -> np.ndarray:
        array = np.asarray(values, dtype=float)
        lower = float(np.nanmin(array))
        upper = float(np.nanmax(array))
        if not np.isfinite(lower) or not np.isfinite(upper) or upper - lower <= 1e-15:
            return np.zeros_like(array)
        return (array - lower) / (upper - lower)

    def _fit_nested_groups(self, groups: list[str], *, solver_tolerance: float = 1e-4) -> dict:
        indices = self._indices_for_groups(groups)
        model = LogisticRegression(
            C=np.inf,
            solver="lbfgs",
            max_iter=5000,
            tol=solver_tolerance,
            random_state=self.config.random_state,
        )
        model.fit(self.X_train[:, indices], self.y_train)
        train_probabilities = model.predict_proba(self.X_train[:, indices])[:, 1]
        validation_probabilities = model.predict_proba(self.X_validation[:, indices])[:, 1]
        grouped_shap = self._linear_grouped_shap(
            model,
            indices,
            self.X_validation[self.probe_indices],
            self.X_train[self.background_indices],
        )
        feature_log, open_traces, closed_traces, trace_lookup = self._feature_log_and_traces(
            self.probe_case_ids,
            self.probe_outcomes,
            grouped_shap,
            included_features=groups,
        )
        open_graph = build_dfg(open_traces)
        closed_graph = build_dfg(closed_traces)
        analysis_traces = feature_only_traces(open_traces)
        analysis_closed_traces = [[*trace, "START"] for trace in analysis_traces]
        analysis_graph = build_dfg(analysis_traces)
        analysis_closed_graph = build_dfg(analysis_closed_traces)
        probabilities = np.clip(train_probabilities, 1e-12, 1 - 1e-12)
        log_likelihood = float(np.sum(
            self.y_train * np.log(probabilities)
            + (1 - self.y_train) * np.log(1 - probabilities)
        ))
        rank = self._design_rank(self.X_train, indices)
        aic = 2 * rank - 2 * log_likelihood
        aicc = (
            aic + 2 * rank * (rank + 1) / (len(self.y_train) - rank - 1)
            if len(self.y_train) > rank + 1
            else np.inf
        )
        return {
            "groups": list(groups),
            "indices": indices,
            "model": model,
            "train_probabilities": train_probabilities,
            "validation_probabilities": validation_probabilities,
            "validation_predictions": (validation_probabilities >= 0.5).astype(int),
            "grouped_shap": grouped_shap,
            "feature_log": feature_log,
            "open_traces": open_traces,
            "closed_traces": closed_traces,
            "trace_lookup": trace_lookup,
            "open_graph": open_graph,
            "closed_graph": closed_graph,
            "analysis_traces": analysis_traces,
            "analysis_closed_traces": analysis_closed_traces,
            "analysis_graph": analysis_graph,
            "analysis_closed_graph": analysis_closed_graph,
            "design_rank_p": rank,
            "training_log_likelihood": log_likelihood,
            "AIC": aic,
            "AICc": aicc,
            "BIC": math.log(len(self.y_train)) * rank - 2 * log_likelihood,
        }

    def _dfg_knee_path(self, measure_frame: pd.DataFrame) -> pd.DataFrame:
        frame = measure_frame.sort_values("feature_group_count").reset_index(drop=True).copy()
        signature_columns = [
            "open_dfg_nodes",
            "rank_excess_edge_occupancy",
            "effective_transition_dimension_per_feature",
            "normalized_ks_entropy",
            "branching_state_entropy_bits",
            "information_distance_per_rank_step",
            "out_closeness_concentration",
            "betweenness_concentration",
            "eigenvector_concentration",
        ]
        scaled = np.column_stack([
            self._minmax(frame[column].to_numpy(dtype=float))
            for column in signature_columns
        ])
        step = np.zeros(len(frame), dtype=float)
        if len(frame) > 1:
            step[1:] = np.linalg.norm(np.diff(scaled, axis=0), axis=1) / math.sqrt(len(signature_columns))
        cumulative = np.cumsum(step)
        path = cumulative / cumulative[-1] if cumulative[-1] > 0 else np.linspace(0, 1, len(frame))
        similarity = frame["our_similarity_measure_to_full_dfg"].to_numpy(dtype=float)
        baseline = similarity[0] + (similarity[-1] - similarity[0]) * path
        knee_score = similarity - baseline
        positive_knee_detected = False
        if len(knee_score) > 2:
            interior = np.arange(1, len(knee_score) - 1)
            selected_position = int(interior[np.argmax(knee_score[interior])])
            positive_knee_detected = bool(knee_score[selected_position] > 1e-12)
            if not positive_knee_detected:
                selected_position = len(frame) - 1
        else:
            selected_position = len(frame) - 1
        selection_method = (
            "maximum positive DFG knee above the endpoint chord"
            if positive_knee_detected
            else "no positive interior DFG knee; retain the full feature set"
        )
        frame["dfg_signature_step_change"] = step
        frame["dfg_cumulative_path"] = path
        frame["dfg_knee_score"] = knee_score
        frame["positive_interior_knee_detected"] = positive_knee_detected
        frame["dfg_selection_method"] = selection_method
        frame["is_selected_dfg_count"] = False
        frame.loc[selected_position, "is_selected_dfg_count"] = True
        frame["is_selected_dfg_knee"] = False
        frame.loc[selected_position, "is_selected_dfg_knee"] = True
        return frame

    def run_task3(self) -> pd.DataFrame:
        """Fit every nested feature-group count and select a DFG-only knee."""
        if not self.task2_4_artifacts:
            self.run_task2_4()
        output_dir = self.root / "task3_outputs"
        output_dir.mkdir(exist_ok=True)
        support = self.task2_4_artifacts["supports"].copy()
        entry_rows = []
        for feature in self.config.features:
            values = support.loc[support["feature_group"].eq(feature), "C"]
            entry_rows.append({
                "feature_group": feature,
                "entry_C": float(values.min()) if len(values) else np.inf,
            })

        all_indices = self._indices_for_groups(self.config.features)
        full_model = LogisticRegression(
            C=np.inf,
            solver="lbfgs",
            max_iter=5000,
            random_state=self.config.random_state,
        ).fit(self.X_train[:, all_indices], self.y_train)
        full_shap = self._linear_grouped_shap(
            full_model,
            all_indices,
            self.X_train[self.ranking_indices],
            self.X_train[self.background_indices],
        )
        mean_abs = np.mean(np.abs(full_shap), axis=0)
        ranking = pd.DataFrame(entry_rows)
        ranking["full_model_mean_abs_shap"] = [
            float(mean_abs[self.config.features.index(feature)])
            for feature in ranking["feature_group"]
        ]
        ranking["original_position"] = [
            self.config.features.index(feature) for feature in ranking["feature_group"]
        ]
        ranking = ranking.sort_values(
            ["full_model_mean_abs_shap", "entry_C", "original_position"],
            ascending=[False, True, True],
        ).reset_index(drop=True)
        ranking["ranking_source"] = (
            "training-cohort full-model mean absolute grouped SHAP; L1 entry C breaks ties"
        )
        ranking.insert(0, "feature_rank", np.arange(1, len(ranking) + 1))
        feature_order = ranking["feature_group"].tolist()
        ranking.to_csv(output_dir / "feature_group_ranking.csv", index=False)

        rows = []
        artifacts: dict[int, dict] = {}
        for count in range(1, len(feature_order) + 1):
            groups = feature_order[:count]
            print(f"Task 3: fitting k={count} nested groups: {', '.join(groups)}")
            artifact = self._fit_nested_groups(groups)
            measures = self._graph_measure_row(
                artifact["analysis_graph"], artifact["analysis_closed_graph"]
            )
            row = {
                "feature_group_count": count,
                "included_feature_groups": " | ".join(groups),
                "transformed_feature_count": len(artifact["indices"]),
                "design_rank_p": artifact["design_rank_p"],
                "training_log_likelihood": artifact["training_log_likelihood"],
                "AIC": artifact["AIC"],
                "AICc": artifact["AICc"],
                "BIC": artifact["BIC"],
                **predictive_metrics(
                    self.y_validation, artifact["validation_probabilities"], "validation"
                ),
                **measures,
                "dfg_analysis_scope": "feature-only START-to-END ranking graph",
                "test_cases_used": False,
            }
            rows.append(row)
            artifacts[count] = artifact
            stem = f"feature_count_{count:02d}"
            artifact["feature_log"].to_csv(output_dir / f"{stem}_feature_log.csv", index=False)
            self._write_graph(
                artifact["open_graph"],
                output_dir / f"{stem}_ground_truth_endpoint_open_dfg.graphml",
                {
                    "feature_group_count": count,
                    "included_groups": " | ".join(groups),
                    "analysis_scope": "endpoint-preserving descriptive export",
                },
            )
            self._write_graph(
                artifact["analysis_graph"],
                output_dir / f"{stem}_feature_only_open_dfg.graphml",
                {
                    "feature_group_count": count,
                    "included_groups": " | ".join(groups),
                    "analysis_scope": "primary Task 3 feature-only graph",
                },
            )
            self._write_graph(
                artifact["analysis_closed_graph"],
                output_dir / f"{stem}_feature_only_restart_closed_dfg.graphml",
                {
                    "feature_group_count": count,
                    "included_groups": " | ".join(groups),
                    "analysis_scope": "primary Task 3 feature-only graph",
                },
            )

        result = pd.DataFrame(rows).sort_values("feature_group_count").reset_index(drop=True)
        full_graph = artifacts[len(feature_order)]["analysis_graph"]
        result["our_similarity_measure_to_full_dfg"] = [
            l1_dfg_similarity(artifacts[count]["analysis_graph"], full_graph)
            for count in result["feature_group_count"]
        ]
        result["supervisor_formula_similarity_to_full_dfg"] = [
            supervisor_dfg_similarity(artifacts[count]["analysis_graph"], full_graph)
            for count in result["feature_group_count"]
        ]
        result["our_similarity_measure_to_previous"] = np.nan
        for position in range(1, len(result)):
            previous_count = int(result.loc[position - 1, "feature_group_count"])
            count = int(result.loc[position, "feature_group_count"])
            result.loc[position, "our_similarity_measure_to_previous"] = l1_dfg_similarity(
                artifacts[previous_count]["analysis_graph"], artifacts[count]["analysis_graph"]
            )
        result["delta_AIC_from_minimum"] = result["AIC"] - result["AIC"].min()
        result["delta_AICc_from_minimum"] = result["AICc"] - result["AICc"].min()
        result["delta_BIC_from_minimum"] = result["BIC"] - result["BIC"].min()
        path = self._dfg_knee_path(result)
        point_selected_count = int(
            path.loc[path["is_selected_dfg_knee"], "feature_group_count"].iloc[0]
        )

        full_analysis_traces = artifacts[len(feature_order)]["analysis_traces"]
        projected_full_traces = {
            count: project_feature_traces(
                full_analysis_traces,
                {self._feature_event(feature) for feature in feature_order[:count]},
            )
            for count in range(1, len(feature_order) + 1)
        }
        result["our_similarity_measure_to_projected_full_dfg"] = [
            l1_dfg_similarity(
                artifacts[int(count)]["analysis_graph"],
                build_dfg(projected_full_traces[int(count)]),
            )
            for count in result["feature_group_count"]
        ]
        result["model_reranking_l1_distance_to_projected_full_dfg"] = (
            1.0 - result["our_similarity_measure_to_projected_full_dfg"]
        )

        bootstrap_rng = np.random.default_rng(self.config.random_state + 3301)
        bootstrap_rows = []
        equivalence_rows = []
        case_count = len(self.probe_case_ids)
        for bootstrap_id in range(self.config.task3_bootstraps):
            sampled = bootstrap_rng.choice(case_count, size=case_count, replace=True)
            replicate_rows = []
            replicate_graphs = {}
            for count in range(1, len(feature_order) + 1):
                open_graph = build_dfg(
                    [artifacts[count]["analysis_traces"][index] for index in sampled]
                )
                closed_graph = build_dfg(
                    [artifacts[count]["analysis_closed_traces"][index] for index in sampled]
                )
                replicate_graphs[count] = open_graph
                replicate_rows.append({
                    "feature_group_count": count,
                    **self._graph_measure_row(open_graph, closed_graph),
                })
                projected_graph = build_dfg(
                    [projected_full_traces[count][index] for index in sampled]
                )
                null_left = _stratified_bootstrap_indices(self.probe_outcomes, bootstrap_rng)
                null_right = _stratified_bootstrap_indices(self.probe_outcomes, bootstrap_rng)
                null_left_graph = build_dfg(
                    [projected_full_traces[count][index] for index in null_left]
                )
                null_right_graph = build_dfg(
                    [projected_full_traces[count][index] for index in null_right]
                )
                equivalence_rows.append({
                    "bootstrap_id": bootstrap_id + 1,
                    "feature_group_count": count,
                    "paired_candidate_vs_projected_full_l1_distance": (
                        1.0 - l1_dfg_similarity(open_graph, projected_graph)
                    ),
                    "finite_sample_null_l1_distance": (
                        1.0 - l1_dfg_similarity(null_left_graph, null_right_graph)
                    ),
                })
            replicate = pd.DataFrame(replicate_rows)
            replicate_full = replicate_graphs[len(feature_order)]
            replicate["our_similarity_measure_to_full_dfg"] = [
                l1_dfg_similarity(replicate_graphs[count], replicate_full)
                for count in replicate["feature_group_count"]
            ]
            replicate_path = self._dfg_knee_path(replicate)
            replicate_selected = int(
                replicate_path.loc[
                    replicate_path["is_selected_dfg_knee"], "feature_group_count"
                ].iloc[0]
            )
            for row in replicate_path.itertuples(index=False):
                bootstrap_rows.append({
                    "bootstrap_id": bootstrap_id + 1,
                    "candidate_feature_count": int(row.feature_group_count),
                    "dfg_cumulative_path": float(row.dfg_cumulative_path),
                    "our_similarity_measure_to_full_dfg": float(row.our_similarity_measure_to_full_dfg),
                    "dfg_knee_score": float(row.dfg_knee_score),
                    "selected_feature_count": replicate_selected,
                })
        bootstrap_df = pd.DataFrame(bootstrap_rows)
        frequency = (
            bootstrap_df[["bootstrap_id", "selected_feature_count"]]
            .drop_duplicates()
            .groupby("selected_feature_count")
            .size()
            .rename("selection_count")
            .reset_index()
        )
        frequency["selection_frequency"] = frequency["selection_count"] / self.config.task3_bootstraps
        curve_rows = []
        for count, group in bootstrap_df.groupby("candidate_feature_count"):
            row = {"feature_group_count": int(count)}
            for column in [
                "dfg_cumulative_path",
                "our_similarity_measure_to_full_dfg",
                "dfg_knee_score",
            ]:
                stats = _interval(group[column].to_numpy())
                row.update({f"{column}_{key}": value for key, value in stats.items()})
            curve_rows.append(row)
        curve_summary = pd.DataFrame(curve_rows)

        equivalence_df = pd.DataFrame(equivalence_rows)
        equivalence_summary_rows = []
        for count, group in equivalence_df.groupby("feature_group_count"):
            paired_stats = _interval(
                group["paired_candidate_vs_projected_full_l1_distance"].to_numpy(dtype=float)
            )
            null_values = group["finite_sample_null_l1_distance"].to_numpy(dtype=float)
            observed_distance = float(
                result.loc[
                    result["feature_group_count"].eq(int(count)),
                    "model_reranking_l1_distance_to_projected_full_dfg",
                ].iloc[0]
            )
            noise_limit = float(np.quantile(null_values, 0.95))
            equivalence_summary_rows.append({
                "feature_group_count": int(count),
                "observed_model_reranking_l1_distance": observed_distance,
                "paired_distance_bootstrap_mean": paired_stats["mean"],
                "paired_distance_bootstrap_p025": paired_stats["p025"],
                "paired_distance_bootstrap_p975": paired_stats["p975"],
                "finite_sample_null_distance_p95": noise_limit,
                "within_finite_sample_DFG_noise": bool(observed_distance <= noise_limit + 1e-15),
                "identifiable_ranking_graph": bool(int(count) >= 2),
            })
        equivalence_summary = pd.DataFrame(equivalence_summary_rows)
        identifiable_equivalent = equivalence_summary[
            equivalence_summary["within_finite_sample_DFG_noise"]
            & equivalence_summary["identifiable_ranking_graph"]
        ]
        projected_equivalence_count = (
            int(identifiable_equivalent["feature_group_count"].min())
            if len(identifiable_equivalent)
            else len(feature_order)
        )

        modal_count = int(
            frequency.sort_values(
                ["selection_frequency", "selected_feature_count"], ascending=[False, True]
            ).iloc[0]["selected_feature_count"]
        )
        point_positive = bool(path["positive_interior_knee_detected"].iloc[0])
        point_curve = curve_summary[
            curve_summary["feature_group_count"].eq(point_selected_count)
        ]
        knee_lower_above_zero = bool(
            len(point_curve)
            and float(point_curve.iloc[0]["dfg_knee_score_p025"]) > 0.0
        )
        bootstrap_confirmed_knee = bool(
            point_positive and knee_lower_above_zero and modal_count == point_selected_count
        )
        selected_count = point_selected_count if bootstrap_confirmed_knee else len(feature_order)
        robust_selection_rule = (
            "bootstrap-confirmed positive DFG knee above the endpoint chord"
            if bootstrap_confirmed_knee
            else "no bootstrap-confirmed interior DFG knee; retain the full feature set"
        )
        path["is_selected_dfg_count"] = path["feature_group_count"].eq(selected_count)
        path["bootstrap_confirmed_primary_selection"] = bootstrap_confirmed_knee
        path["robust_dfg_selection_method"] = robust_selection_rule

        sensitivity_rows = []
        signature_sets = {
            "all_DFG_measures": None,
            "size_connectivity": [
                "open_dfg_nodes", "rank_excess_edge_occupancy",
                "effective_transition_dimension_per_feature",
            ],
            "entropy_distance": [
                "normalized_ks_entropy", "branching_state_entropy_bits",
                "information_distance_per_rank_step",
            ],
            "centrality": [
                "out_closeness_concentration", "betweenness_concentration",
                "eigenvector_concentration",
            ],
        }
        for name, columns in signature_sets.items():
            if columns is None:
                sensitivity_count = selected_count
            else:
                subset = result.copy()
                scaled = np.column_stack([
                    self._minmax(subset[column].to_numpy(dtype=float)) for column in columns
                ])
                step = np.zeros(len(subset))
                step[1:] = np.linalg.norm(np.diff(scaled, axis=0), axis=1) / math.sqrt(len(columns))
                cumulative = np.cumsum(step)
                path_values = cumulative / cumulative[-1] if cumulative[-1] else np.linspace(0, 1, len(subset))
                similarity = subset["our_similarity_measure_to_full_dfg"].to_numpy(dtype=float)
                baseline = similarity[0] + (similarity[-1] - similarity[0]) * path_values
                score = similarity - baseline
                candidates = np.arange(1, len(score) - 1) if len(score) > 2 else np.asarray([], dtype=int)
                if len(candidates) and float(np.max(score[candidates])) > 1e-12:
                    sensitivity_count = int(
                        subset.iloc[int(candidates[np.argmax(score[candidates])])]["feature_group_count"]
                    )
                else:
                    sensitivity_count = int(subset["feature_group_count"].max())
            sensitivity_rows.append({"signature": name, "selected_feature_count": sensitivity_count})
        sensitivity = pd.DataFrame(sensitivity_rows)
        selection_summary = pd.DataFrame([{
            "selected_feature_count": selected_count,
            "selected_feature_groups": " | ".join(feature_order[:selected_count]),
            "selection_rule": robust_selection_rule,
            "point_estimate_knee_feature_count": point_selected_count,
            "point_estimate_knee_rule": str(path["dfg_selection_method"].iloc[0]),
            "positive_interior_knee_detected": bool(
                path["positive_interior_knee_detected"].iloc[0]
            ),
            "bootstrap_confirmed_positive_knee": bootstrap_confirmed_knee,
            "point_knee_score_bootstrap_p025": (
                float(point_curve.iloc[0]["dfg_knee_score_p025"])
                if len(point_curve)
                else np.nan
            ),
            "maximum_interior_knee_score": float(
                path["dfg_knee_score"].iloc[1:-1].max()
            ) if len(path) > 2 else np.nan,
            "bootstrap_modal_feature_count": modal_count,
            "bootstrap_support_for_primary_selection": float(
                frequency.loc[
                    frequency["selected_feature_count"].eq(selected_count), "selection_frequency"
                ].iloc[0]
            ) if (frequency["selected_feature_count"] == selected_count).any() else 0.0,
            "projected_full_noise_equivalence_diagnostic_count": projected_equivalence_count,
            "projected_diagnostic_interpretation": (
                "smallest k>=2 whose refitted ranking DFG differs from the aligned full-model "
                "projection by no more than the 95th percentile of finite-sample DFG noise; "
                "diagnostic only because projection does not measure omitted-feature utility"
            ),
        }])

        result = result.merge(equivalence_summary, on="feature_group_count", how="left")
        result.to_csv(output_dir / "nested_feature_group_model_dfg_measures.csv", index=False)
        path.to_csv(output_dir / "dfg_only_step_changes.csv", index=False)
        bootstrap_df.to_csv(output_dir / "dfg_only_bootstrap_replicates.csv", index=False)
        equivalence_df.to_csv(
            output_dir / "projected_full_dfg_equivalence_bootstrap_replicates.csv", index=False
        )
        equivalence_summary.to_csv(
            output_dir / "projected_full_dfg_equivalence_summary.csv", index=False
        )
        frequency.to_csv(output_dir / "dfg_only_bootstrap_selection_frequency.csv", index=False)
        curve_summary.to_csv(output_dir / "dfg_only_bootstrap_curve_intervals.csv", index=False)
        sensitivity.to_csv(output_dir / "dfg_only_sensitivity_checks.csv", index=False)
        selection_summary.to_csv(output_dir / "dfg_only_selection_summary.csv", index=False)

        x = result["feature_group_count"].to_numpy(dtype=int)
        fig, axes = plt.subplots(2, 3, figsize=(17, 10), constrained_layout=True)
        axes = axes.ravel()
        axes[0].plot(x, 100 * result["validation_accuracy"], marker="o", label="Accuracy")
        axes[0].plot(x, 100 * result["validation_balanced_accuracy"], marker="s", label="Balanced accuracy")
        axes[0].set_ylabel("Validation score (%)")
        axes[0].legend()
        axes[1].plot(x, result["validation_roc_auc"], marker="o", color="#3a7d44")
        axes[1].set_ylabel("Validation ROC AUC")
        axes[2].plot(x, result["ks_entropy_bits_per_transition"], marker="o", color="#b56576")
        axes[2].set_ylabel("KS entropy (bits/transition)")
        axes[3].plot(x, result["our_similarity_measure_to_full_dfg"], marker="o", color="#2f6690")
        axes[3].set_ylabel("Similarity to full DFG")
        axes[3].set_title("Normalized-frequency L1 similarity")
        axes[4].plot(x, result["open_dfg_density"], marker="o", label="Density")
        edge_axis = axes[4].twinx()
        edge_axis.plot(x, result["open_dfg_edges"], marker="s", color="#c05a47", label="Edges")
        axes[4].set_ylabel("Directed density")
        edge_axis.set_ylabel("Edges")
        axes[5].plot(x, result["delta_AIC_from_minimum"], marker="o", label="Delta AIC")
        axes[5].plot(x, result["delta_AICc_from_minimum"], marker="^", label="Delta AICc")
        axes[5].plot(x, result["delta_BIC_from_minimum"], marker="s", label="Delta BIC")
        axes[5].set_ylabel("Difference from minimum")
        axes[5].legend()
        for axis in axes:
            axis.axvline(selected_count, color="black", linestyle="--", alpha=0.6)
            axis.set_xlabel("Number of original feature groups")
            axis.grid(alpha=0.25)
        fig.suptitle(f"Task 3: all nested feature settings - {self.config.dataset_title}")
        self._save_show(fig, output_dir / "task3_all_setting_comparison.png", dpi=220)

        fig, axes = plt.subplots(2, 3, figsize=(17, 10), constrained_layout=True)
        axes = axes.ravel()
        axes[0].plot(path["dfg_cumulative_path"], path["our_similarity_measure_to_full_dfg"], marker="o")
        axes[0].set_xlabel("Cumulative DFG-signature path")
        axes[0].set_ylabel("Normalized-frequency L1 similarity\nto full DFG")
        axes[1].plot(x, path["dfg_signature_step_change"], marker="o", color="#c05a47")
        axes[1].set_ylabel("DFG signature step change")
        axes[2].plot(x, path["dfg_knee_score"], marker="o", color="#3a7d44")
        axes[2].set_ylabel("Knee score above endpoint chord")
        axes[2].axhline(0.0, color="black", linewidth=0.8, alpha=0.5)
        axes[3].bar(frequency["selected_feature_count"].astype(str), frequency["selection_frequency"], color="#2f6690")
        axes[3].set_ylabel("Bootstrap selection frequency")
        axes[4].plot(x, result["mean_out_closeness"], marker="o", label="Closeness")
        axes[4].plot(x, result["mean_betweenness"], marker="s", label="Betweenness")
        axes[4].plot(x, result["mean_undirected_eigenvector"], marker="^", label="Eigenvector")
        axes[4].set_ylabel("Mean centrality")
        axes[4].legend()
        axes[5].plot(
            equivalence_summary["feature_group_count"],
            equivalence_summary["observed_model_reranking_l1_distance"],
            marker="o",
            label="Refitted vs projected full DFG",
        )
        axes[5].plot(
            equivalence_summary["feature_group_count"],
            equivalence_summary["finite_sample_null_distance_p95"],
            marker="s",
            label="Finite-sample noise p95",
        )
        axes[5].axvline(
            projected_equivalence_count,
            color="#7a5195",
            linestyle=":",
            label=f"Projected diagnostic k={projected_equivalence_count}",
        )
        axes[5].set_xlabel("Number of original feature groups")
        axes[5].set_ylabel("Normalized-frequency L1 distance")
        axes[5].legend(fontsize=8)
        for axis in axes:
            axis.grid(alpha=0.25)
        for axis in axes[1:3]:
            axis.axvline(selected_count, color="black", linestyle="--", alpha=0.6)
            axis.set_xlabel("Number of original feature groups")
        fig.suptitle(f"Task 3: DFG-only feature-count decision - {self.config.dataset_title}")
        self._save_show(fig, output_dir / "task3_dfg_only_feature_count_decision.png", dpi=220)
        display(ranking)
        display(selection_summary)
        display(frequency)
        self.task3_artifacts = {
            "ranking": ranking,
            "feature_order": feature_order,
            "results": result,
            "path": path,
            "settings": artifacts,
            "selected_count": selected_count,
            "point_selected_count": point_selected_count,
            "projected_equivalence_count": projected_equivalence_count,
            "bootstrap": bootstrap_df,
            "frequency": frequency,
            "equivalence": equivalence_summary,
        }
        return result

    @staticmethod
    def _mean_rank_agreement(reference: np.ndarray, candidate: np.ndarray) -> float:
        reference = np.abs(np.asarray(reference, dtype=float))
        candidate = np.abs(np.asarray(candidate, dtype=float))
        feature_count = reference.shape[1]
        if feature_count <= 1:
            return 1.0
        reference_order = np.argsort(-reference, axis=1, kind="stable")
        candidate_order = np.argsort(-candidate, axis=1, kind="stable")
        reference_rank = np.empty_like(reference_order, dtype=float)
        candidate_rank = np.empty_like(candidate_order, dtype=float)
        rows = np.arange(len(reference))[:, None]
        reference_rank[rows, reference_order] = np.arange(feature_count)
        candidate_rank[rows, candidate_order] = np.arange(feature_count)
        reference_centered = reference_rank - reference_rank.mean(axis=1, keepdims=True)
        candidate_centered = candidate_rank - candidate_rank.mean(axis=1, keepdims=True)
        denominator = np.sqrt(
            np.sum(reference_centered**2, axis=1) * np.sum(candidate_centered**2, axis=1)
        )
        correlations = np.divide(
            np.sum(reference_centered * candidate_centered, axis=1),
            denominator,
            out=np.ones(len(reference), dtype=float),
            where=denominator > 0,
        )
        return float(np.mean(correlations))

    def run_task4(self) -> pd.DataFrame:
        """Compare DFG complexity with retraining stability across nested models."""
        if not self.task3_artifacts:
            self.run_task3()
        output_dir = self.root / "task4_outputs"
        output_dir.mkdir(exist_ok=True)
        feature_order = self.task3_artifacts["feature_order"]
        reference_settings = self.task3_artifacts["settings"]
        bootstrap_rng = np.random.default_rng(self.config.random_state + 4401)
        rows = []
        edge_probability_sums: dict[int, defaultdict] = {
            count: defaultdict(float) for count in range(1, len(feature_order) + 1)
        }
        edge_presence: dict[int, Counter] = {
            count: Counter() for count in range(1, len(feature_order) + 1)
        }
        probe_cases = self.X_validation[self.probe_indices]
        for bootstrap_id in range(self.config.task4_retraining_bootstraps):
            sampled = _stratified_bootstrap_indices(self.y_train, bootstrap_rng)
            bootstrap_X = self.X_train[sampled]
            bootstrap_y = self.y_train[sampled]
            for count in range(1, len(feature_order) + 1):
                groups = feature_order[:count]
                indices = self._indices_for_groups(groups)
                model = LogisticRegression(
                    C=np.inf,
                    solver="lbfgs",
                    max_iter=5000,
                    random_state=self.config.random_state + bootstrap_id,
                )
                model.fit(bootstrap_X[:, indices], bootstrap_y)
                validation_probabilities = model.predict_proba(self.X_validation[:, indices])[:, 1]
                grouped_shap = self._linear_grouped_shap(
                    model,
                    indices,
                    probe_cases,
                    self.X_train[self.background_indices],
                )
                _, endpoint_traces, _, _ = self._feature_log_and_traces(
                    self.probe_case_ids,
                    self.probe_outcomes,
                    grouped_shap,
                    included_features=groups,
                )
                open_traces = feature_only_traces(endpoint_traces)
                closed_traces = [[*trace, "START"] for trace in open_traces]
                open_graph = build_dfg(open_traces)
                closed_graph = build_dfg(closed_traces)
                reference = reference_settings[count]
                train_probabilities = np.clip(
                    model.predict_proba(bootstrap_X[:, indices])[:, 1], 1e-12, 1 - 1e-12
                )
                training_log_likelihood = float(np.sum(
                    bootstrap_y * np.log(train_probabilities)
                    + (1 - bootstrap_y) * np.log(1 - train_probabilities)
                ))
                design_rank = self._design_rank(bootstrap_X, indices)
                branching_penalty = dfg_branching_penalty(open_graph)
                normalized = normalized_edge_weights(open_graph)
                for edge, probability in normalized.items():
                    edge_probability_sums[count][edge] += probability
                    edge_presence[count][edge] += 1
                rows.append({
                    "bootstrap_id": bootstrap_id + 1,
                    "feature_group_count": count,
                    "validation_accuracy": accuracy_score(
                        self.y_validation, validation_probabilities >= 0.5
                    ),
                    "validation_roc_auc": roc_auc_score(
                        self.y_validation, validation_probabilities
                    ),
                    "l1_similarity_to_reference_dfg": l1_dfg_similarity(
                        open_graph, reference["analysis_graph"]
                    ),
                    "supervisor_similarity_to_reference_dfg": supervisor_dfg_similarity(
                        open_graph, reference["analysis_graph"]
                    ),
                    "mean_case_rank_spearman": self._mean_rank_agreement(
                        reference["grouped_shap"][:, [self.config.features.index(group) for group in groups]],
                        grouped_shap[:, [self.config.features.index(group) for group in groups]],
                    ),
                    "top_feature_agreement": float(np.mean(
                        np.argmax(
                            np.abs(reference["grouped_shap"][:, [self.config.features.index(group) for group in groups]]),
                            axis=1,
                        )
                        == np.argmax(
                            np.abs(grouped_shap[:, [self.config.features.index(group) for group in groups]]),
                            axis=1,
                        )
                    )),
                    "bootstrap_training_log_likelihood": training_log_likelihood,
                    "bootstrap_design_rank_p": design_rank,
                    "bootstrap_BIC": (
                        math.log(len(bootstrap_y)) * design_rank - 2 * training_log_likelihood
                    ),
                    **branching_penalty,
                    **self._graph_measure_row(open_graph, closed_graph),
                })
            if (bootstrap_id + 1) % 10 == 0 or bootstrap_id == 0:
                print(
                    f"Task 4 retraining bootstrap {bootstrap_id + 1}/"
                    f"{self.config.task4_retraining_bootstraps}"
                )
        replicates = pd.DataFrame(rows)
        summary_rows = []
        metrics = [
            "validation_accuracy",
            "validation_roc_auc",
            "l1_similarity_to_reference_dfg",
            "supervisor_similarity_to_reference_dfg",
            "mean_case_rank_spearman",
            "top_feature_agreement",
            "ks_entropy_bits_per_transition",
            "normalized_ks_entropy",
            "branching_state_entropy_bits",
            "rank_excess_edge_occupancy",
            "effective_transition_dimension_per_feature",
            "open_dfg_edges",
            "open_dfg_density",
            "information_distance_p95",
            "bootstrap_BIC",
            "frequency_sensitive_dfg_penalty",
        ]
        task3_results = self.task3_artifacts["results"].set_index("feature_group_count")
        for count, group in replicates.groupby("feature_group_count"):
            row = {
                "feature_group_count": int(count),
                "included_feature_groups": " | ".join(feature_order[: int(count)]),
                "reference_ks_entropy": float(
                    task3_results.loc[int(count), "ks_entropy_bits_per_transition"]
                ),
                "reference_open_dfg_edges": float(
                    task3_results.loc[int(count), "open_dfg_edges"]
                ),
                "reference_normalized_ks_entropy": float(
                    task3_results.loc[int(count), "normalized_ks_entropy"]
                ),
                "reference_rank_excess_edge_occupancy": float(
                    task3_results.loc[int(count), "rank_excess_edge_occupancy"]
                ),
                "reference_effective_transition_dimension_per_feature": float(
                    task3_results.loc[
                        int(count), "effective_transition_dimension_per_feature"
                    ]
                ),
            }
            for metric in metrics:
                stats = _interval(group[metric].to_numpy(dtype=float))
                row.update({f"{metric}_{key}": value for key, value in stats.items()})
            summary_rows.append(row)
        summary = pd.DataFrame(summary_rows).sort_values("feature_group_count")
        summary["reference_size_adjusted_dfg_complexity"] = np.mean(
            np.column_stack([
                self._minmax(summary["reference_rank_excess_edge_occupancy"]),
                self._minmax(summary["reference_normalized_ks_entropy"]),
                self._minmax(summary["reference_effective_transition_dimension_per_feature"]),
            ]),
            axis=1,
        )

        correlation_rows = []
        complexity_metrics = [
            "reference_ks_entropy",
            "reference_open_dfg_edges",
            "reference_size_adjusted_dfg_complexity",
            "feature_group_count",
        ]
        stability_metrics = [
            "l1_similarity_to_reference_dfg_mean",
            "mean_case_rank_spearman_mean",
            "top_feature_agreement_mean",
        ]
        for complexity in complexity_metrics:
            for stability in stability_metrics:
                statistic = spearmanr(summary[complexity], summary[stability])
                correlation_rows.append({
                    "complexity_measure": complexity,
                    "stability_measure": stability,
                    "spearman_rho": float(statistic.statistic),
                    "two_sided_p_value": float(statistic.pvalue),
                    "feature_count_settings": len(summary),
                    "inference_scope": (
                        "descriptive only; nested feature-count settings are dependent"
                    ),
                })
        correlations = pd.DataFrame(correlation_rows)

        for count in range(1, len(feature_order) + 1):
            consensus = nx.DiGraph()
            edges = set(edge_probability_sums[count]).union(edge_presence[count])
            for edge in edges:
                mean_probability = (
                    edge_probability_sums[count][edge]
                    / self.config.task4_retraining_bootstraps
                )
                consensus.add_edge(
                    edge[0],
                    edge[1],
                    weight=float(mean_probability),
                    mean_normalized_frequency=float(mean_probability),
                    bootstrap_presence_frequency=float(
                        edge_presence[count][edge]
                        / self.config.task4_retraining_bootstraps
                    ),
                )
            self._write_graph(
                consensus,
                output_dir / f"feature_count_{count:02d}_bootstrap_consensus_open_dfg.graphml",
                {"feature_group_count": count, "bootstrap_count": self.config.task4_retraining_bootstraps},
            )
        replicates.to_csv(output_dir / "retraining_bootstrap_replicates.csv", index=False)
        summary.to_csv(output_dir / "complexity_stability_summary.csv", index=False)
        correlations.to_csv(output_dir / "complexity_stability_correlations.csv", index=False)
        pd.DataFrame([{
            "bootstrap_type": (
                "paired stratified training-case bootstrap with fixed preprocessing map "
                "and fixed training-derived nested feature order"
            ),
            "retraining_bootstraps": self.config.task4_retraining_bootstraps,
            "stability_reference": "original-training nested model at the same feature count",
            "feature_order_scope": (
                "Task 3 training-derived feature order held fixed; Task 4 isolates coefficient, "
                "local-ranking, and DFG variation conditional on the nested feature sets"
            ),
            "explanation_background": (
                "fixed training background shared by reference and bootstrap models; "
                "stability isolates retraining rather than masker drift"
            ),
            "dfg_scope": "feature-only START-to-END ranking graph",
        }]).to_csv(output_dir / "method_summary.csv", index=False)

        x = summary["feature_group_count"].to_numpy(dtype=float)
        fig, axes = plt.subplots(2, 3, figsize=(17, 10), constrained_layout=True)
        axes = axes.ravel()
        plot_specs = [
            (
                "reference_size_adjusted_dfg_complexity",
                "Reference size-adjusted DFG complexity",
                "#b56576",
            ),
            ("l1_similarity_to_reference_dfg_mean", "Mean DFG stability (L1 similarity)", "#2f6690"),
            ("mean_case_rank_spearman_mean", "Mean case-rank stability", "#3a7d44"),
            ("top_feature_agreement_mean", "Top-feature agreement", "#7a5195"),
            ("validation_accuracy_mean", "Bootstrap validation accuracy", "#c05a47"),
        ]
        for axis, (column, label, color) in zip(axes[:5], plot_specs):
            axis.plot(x, summary[column], marker="o", color=color)
            lower_column = column.replace("_mean", "_p025") if column.endswith("_mean") else None
            upper_column = column.replace("_mean", "_p975") if column.endswith("_mean") else None
            if lower_column in summary and upper_column in summary:
                axis.fill_between(x, summary[lower_column], summary[upper_column], color=color, alpha=0.16)
            axis.set_ylabel(label)
            axis.set_xlabel("Number of original feature groups")
            axis.grid(alpha=0.25)
        axes[5].scatter(
            summary["reference_size_adjusted_dfg_complexity"],
            summary["l1_similarity_to_reference_dfg_mean"],
            c=x,
            cmap="viridis",
            s=55,
        )
        for row in summary.itertuples(index=False):
            axes[5].annotate(
                str(int(row.feature_group_count)),
                (
                    row.reference_size_adjusted_dfg_complexity,
                    row.l1_similarity_to_reference_dfg_mean,
                ),
                xytext=(4, 3),
                textcoords="offset points",
            )
        axes[5].set_xlabel("Reference size-adjusted DFG complexity")
        axes[5].set_ylabel("Mean DFG stability")
        axes[5].grid(alpha=0.25)
        fig.suptitle(f"Task 4: complexity compared with stability - {self.config.dataset_title}")
        self._save_show(fig, output_dir / "task4_complexity_compared_with_stability.png", dpi=220)
        display(summary.round(5))
        display(correlations.round(5))
        self.task4_artifacts = {
            "replicates": replicates,
            "summary": summary,
            "correlations": correlations,
        }
        return summary

    @staticmethod
    def _confusion_class(truth: int, prediction: int) -> str:
        if int(truth) == 1 and int(prediction) == 1:
            return "TP"
        if int(truth) == 1 and int(prediction) == 0:
            return "FN"
        if int(truth) == 0 and int(prediction) == 0:
            return "TN"
        return "FP"

    def _joint_prediction_truth_log(self, artifact: dict) -> tuple[pd.DataFrame, list[list[str]]]:
        rows = []
        traces = []
        positions = {feature: index for index, feature in enumerate(self.config.features)}
        for row_index, case_id in enumerate(artifact["probe_case_ids"]):
            truth = int(artifact["probe_outcomes"][row_index])
            prediction = int(artifact["probe_predictions"][row_index])
            ranked = sorted(
                [
                    (feature, float(artifact["grouped_shap"][row_index, positions[feature]]))
                    for feature in self.config.features
                ],
                key=lambda item: (-abs(item[1]), positions[item[0]]),
            )
            events = [self._feature_event(feature) for feature, _ in ranked]
            prediction_event = f"Prediction: {self._label(prediction)}"
            truth_event = f"Ground truth: {self._label(truth)}"
            confusion = self._confusion_class(truth, prediction)
            for rank, ((feature, shap_value), event) in enumerate(zip(ranked, events), start=1):
                rows.append({
                    "CaseID": str(case_id),
                    "concept:name": event,
                    "feature_group": feature,
                    "local_shap_value": shap_value,
                    "abs_local_shap_importance": abs(shap_value),
                    "explanation_rank": rank,
                    "time:timestamp": rank,
                    "prediction": prediction,
                    "prediction_label": self._label(prediction),
                    "ground_truth": truth,
                    "ground_truth_label": self._label(truth),
                    "confusion_class": confusion,
                })
            for offset, event in enumerate([prediction_event, truth_event], start=1):
                rows.append({
                    "CaseID": str(case_id),
                    "concept:name": event,
                    "feature_group": "",
                    "local_shap_value": 0.0,
                    "abs_local_shap_importance": 0.0,
                    "explanation_rank": len(events) + offset,
                    "time:timestamp": len(events) + offset,
                    "prediction": prediction,
                    "prediction_label": self._label(prediction),
                    "ground_truth": truth,
                    "ground_truth_label": self._label(truth),
                    "confusion_class": confusion,
                })
            traces.append(["START", *events, prediction_event, truth_event])
        return pd.DataFrame(rows), traces

    def _subgroup_comparison(
        self,
        model_kind: str,
        feature_only_traces: list[list[str]],
        group_a_positions: np.ndarray,
        group_b_positions: np.ndarray,
        group_a_label: str,
        group_b_label: str,
        output_dir: Path,
        seed: int,
    ) -> dict:
        group_a_positions = np.asarray(group_a_positions, dtype=int)
        group_b_positions = np.asarray(group_b_positions, dtype=int)
        if len(group_a_positions) == 0 or len(group_b_positions) == 0:
            return {
                "summary": {
                    "model": model_kind,
                    "model_label": self.MODEL_LABELS[model_kind],
                    "group_a": group_a_label,
                    "group_b": group_b_label,
                    "group_a_cases": len(group_a_positions),
                    "group_b_cases": len(group_b_positions),
                    "observed_l1_distance": np.nan,
                    "observed_l1_similarity": np.nan,
                    "observed_supervisor_similarity": np.nan,
                    "bootstrap_l1_distance_mean": np.nan,
                    "bootstrap_l1_distance_p025": np.nan,
                    "bootstrap_l1_distance_p975": np.nan,
                    "permutation_p_value": np.nan,
                    "status": "comparison unavailable because one subgroup is empty",
                },
                "bootstrap": [],
                "permutation": [],
            }
        graph_a = build_dfg([feature_only_traces[index] for index in group_a_positions])
        graph_b = build_dfg([feature_only_traces[index] for index in group_b_positions])
        observed_similarity = l1_dfg_similarity(graph_a, graph_b)
        observed_distance = 1.0 - observed_similarity
        observed_supervisor = supervisor_dfg_similarity(graph_a, graph_b)
        rng = np.random.default_rng(seed)
        bootstrap_rows = []
        distances = []
        for replicate in range(self.config.task5_bootstraps):
            sampled_a = rng.choice(group_a_positions, size=len(group_a_positions), replace=True)
            sampled_b = rng.choice(group_b_positions, size=len(group_b_positions), replace=True)
            bootstrap_a = build_dfg([feature_only_traces[index] for index in sampled_a])
            bootstrap_b = build_dfg([feature_only_traces[index] for index in sampled_b])
            similarity = l1_dfg_similarity(bootstrap_a, bootstrap_b)
            distance = 1.0 - similarity
            distances.append(distance)
            bootstrap_rows.append({
                "bootstrap_id": replicate + 1,
                "model": model_kind,
                "l1_distance": distance,
                "l1_similarity": similarity,
                "supervisor_similarity": supervisor_dfg_similarity(bootstrap_a, bootstrap_b),
            })
        pooled = np.concatenate([group_a_positions, group_b_positions])
        null_distances = []
        permutation_rows = []
        for replicate in range(self.config.task5_permutations):
            shuffled = rng.permutation(pooled)
            permuted_a = shuffled[: len(group_a_positions)]
            permuted_b = shuffled[len(group_a_positions) :]
            permuted_graph_a = build_dfg([feature_only_traces[index] for index in permuted_a])
            permuted_graph_b = build_dfg([feature_only_traces[index] for index in permuted_b])
            distance = 1.0 - l1_dfg_similarity(permuted_graph_a, permuted_graph_b)
            null_distances.append(distance)
            permutation_rows.append({
                "permutation_id": replicate + 1,
                "model": model_kind,
                "null_l1_distance": distance,
            })
        p_value = (
            1 + int(np.sum(np.asarray(null_distances) >= observed_distance - 1e-15))
        ) / (self.config.task5_permutations + 1)
        distance_interval = _interval(distances)
        self._write_graph(
            graph_a,
            output_dir / f"{model_kind}_{_safe_name(group_a_label).lower()}_feature_only_dfg.graphml",
            {"model": self.MODEL_LABELS[model_kind], "group": group_a_label},
        )
        self._write_graph(
            graph_b,
            output_dir / f"{model_kind}_{_safe_name(group_b_label).lower()}_feature_only_dfg.graphml",
            {"model": self.MODEL_LABELS[model_kind], "group": group_b_label},
        )
        edge_a = normalized_edge_weights(graph_a)
        edge_b = normalized_edge_weights(graph_b)
        edge_rows = []
        for edge in sorted(set(edge_a).union(edge_b)):
            edge_rows.append({
                "model": model_kind,
                "source": edge[0],
                "target": edge[1],
                "group_a_normalized_frequency": edge_a.get(edge, 0.0),
                "group_b_normalized_frequency": edge_b.get(edge, 0.0),
                "absolute_difference": abs(edge_a.get(edge, 0.0) - edge_b.get(edge, 0.0)),
            })
        pd.DataFrame(edge_rows).to_csv(
            output_dir / f"{model_kind}_normalized_edge_frequency_comparison.csv", index=False
        )
        return {
            "summary": {
                "model": model_kind,
                "model_label": self.MODEL_LABELS[model_kind],
                "group_a": group_a_label,
                "group_b": group_b_label,
                "group_a_cases": len(group_a_positions),
                "group_b_cases": len(group_b_positions),
                "observed_l1_distance": observed_distance,
                "observed_l1_similarity": observed_similarity,
                "observed_supervisor_similarity": observed_supervisor,
                "bootstrap_l1_distance_mean": distance_interval["mean"],
                "bootstrap_l1_distance_p025": distance_interval["p025"],
                "bootstrap_l1_distance_p975": distance_interval["p975"],
                "permutation_p_value": p_value,
                "status": (
                    "small subgroup below 30 cases; interpret interval and permutation result cautiously"
                    if min(len(group_a_positions), len(group_b_positions)) < 30
                    else "ok"
                ),
                **{f"group_a_{key}": value for key, value in open_graph_measures(graph_a).items()},
                **{f"group_b_{key}": value for key, value in open_graph_measures(graph_b).items()},
            },
            "bootstrap": bootstrap_rows,
            "permutation": permutation_rows,
        }

    def run_task5(self) -> pd.DataFrame:
        """Compare model decisions with ground truth and test subgroup DFG differences."""
        if not self.task1_artifacts:
            self.run_task1()
        output_dir = self.root / "task5_outputs"
        subgroup_dirs = {
            "Task 5.1": self.root / "task5_1_accepted_outputs",
            "Task 5.2": self.root / "task5_2_rejected_outputs",
            "Task 5.3": self.root / "task5_3_accepted_rejected_outputs",
        }
        output_dir.mkdir(exist_ok=True)
        for directory in subgroup_dirs.values():
            directory.mkdir(exist_ok=True)

        summary_rows = []
        case_rows = []
        importance_rows = []
        calibration_rows = []
        threshold_rows = []
        bootstrap_rows = []
        confusion_matrices = {}
        subgroup_rows = []
        subgroup_bootstrap_rows = []
        subgroup_permutation_rows = []
        comparisons = [
            (
                "Task 5.1",
                "Accepted - correct prediction (TP)",
                "Accepted - incorrect prediction (FN)",
                lambda truth, pred: np.flatnonzero((truth == 1) & (pred == 1)),
                lambda truth, pred: np.flatnonzero((truth == 1) & (pred == 0)),
            ),
            (
                "Task 5.2",
                "Rejected - correct prediction (TN)",
                "Rejected - incorrect prediction (FP)",
                lambda truth, pred: np.flatnonzero((truth == 0) & (pred == 0)),
                lambda truth, pred: np.flatnonzero((truth == 0) & (pred == 1)),
            ),
            (
                "Task 5.3",
                "Ground truth accepted",
                "Ground truth rejected",
                lambda truth, pred: np.flatnonzero(truth == 1),
                lambda truth, pred: np.flatnonzero(truth == 0),
            ),
        ]
        shared_bootstrap_rng = np.random.default_rng(self.config.random_state + 5501)
        shared_bootstrap_indices = [
            _stratified_bootstrap_indices(self.probe_outcomes, shared_bootstrap_rng)
            for _ in range(self.config.task5_bootstraps)
        ]
        for model_index, (kind, artifact) in enumerate(self.task1_artifacts.items()):
            truth = artifact["probe_outcomes"].astype(int)
            predictions = artifact["probe_predictions"].astype(int)
            probabilities = artifact["probe_probabilities"].astype(float)
            prediction_traces = [
                [*trace[:-1], f"Outcome: {self._label(prediction)}"]
                for trace, prediction in zip(artifact["open_traces"], predictions)
            ]
            prediction_graph = build_dfg(prediction_traces)
            ground_truth_graph = artifact["open_graph"]
            joint_log, joint_traces = self._joint_prediction_truth_log(artifact)
            joint_graph = build_dfg(joint_traces)
            joint_log.to_csv(
                output_dir / f"{kind}_shap_prediction_ground_truth_feature_log.csv",
                index=False,
            )
            self._write_xes(
                joint_log,
                output_dir / f"{kind}_shap_prediction_ground_truth_feature_log.xes",
            )
            self._write_graph(
                prediction_graph,
                output_dir / f"{kind}_prediction_endpoint_open_dfg.graphml",
                {"model": self.MODEL_LABELS[kind], "endpoint": "prediction"},
            )
            self._write_graph(
                ground_truth_graph,
                output_dir / f"{kind}_ground_truth_endpoint_open_dfg.graphml",
                {"model": self.MODEL_LABELS[kind], "endpoint": "ground truth"},
            )
            self._write_graph(
                joint_graph,
                output_dir / f"{kind}_prediction_then_ground_truth_open_dfg.graphml",
                {"model": self.MODEL_LABELS[kind], "endpoint": "prediction then ground truth"},
            )
            matrix = confusion_matrix(truth, predictions, labels=[0, 1])
            confusion_matrices[kind] = matrix
            summary_rows.append({
                "model": kind,
                "model_label": self.MODEL_LABELS[kind],
                **predictive_metrics(truth, probabilities, "probe"),
                **quantile_calibration_error(truth, probabilities),
                "true_negative": int(matrix[0, 0]),
                "false_positive": int(matrix[0, 1]),
                "false_negative": int(matrix[1, 0]),
                "true_positive": int(matrix[1, 1]),
                "predicted_acceptance_rate": float(predictions.mean()),
                "ground_truth_acceptance_rate": float(truth.mean()),
                "acceptance_rate_gap_prediction_minus_truth": float(predictions.mean() - truth.mean()),
                "prediction_ground_truth_dfg_similarity": l1_dfg_similarity(
                    prediction_graph, ground_truth_graph
                ),
                "prediction_ground_truth_supervisor_similarity": supervisor_dfg_similarity(
                    prediction_graph, ground_truth_graph
                ),
            })
            for row_index, case_id in enumerate(artifact["probe_case_ids"]):
                case_rows.append({
                    "CaseID": str(case_id),
                    "model": kind,
                    "ground_truth": int(truth[row_index]),
                    "ground_truth_label": self._label(int(truth[row_index])),
                    "prediction": int(predictions[row_index]),
                    "prediction_label": self._label(int(predictions[row_index])),
                    "acceptance_probability": float(probabilities[row_index]),
                    "confusion_class": self._confusion_class(truth[row_index], predictions[row_index]),
                })
            confusion_classes = np.asarray([
                self._confusion_class(t, p) for t, p in zip(truth, predictions)
            ])
            for confusion_class in ["TP", "FN", "TN", "FP"]:
                mask = confusion_classes == confusion_class
                for feature_index, feature in enumerate(self.config.features):
                    importance_rows.append({
                        "model": kind,
                        "confusion_class": confusion_class,
                        "feature_group": feature,
                        "cases": int(mask.sum()),
                        "mean_abs_local_shap": float(
                            np.mean(np.abs(artifact["grouped_shap"][mask, feature_index]))
                        ) if mask.any() else np.nan,
                        "mean_signed_local_shap": float(
                            np.mean(artifact["grouped_shap"][mask, feature_index])
                        ) if mask.any() else np.nan,
                    })
            bins = np.linspace(0.0, 1.0, 11)
            bin_ids = np.clip(np.digitize(probabilities, bins, right=True) - 1, 0, 9)
            for bin_index in range(10):
                mask = bin_ids == bin_index
                if mask.any():
                    calibration_rows.append({
                        "model": kind,
                        "bin": bin_index + 1,
                        "lower_probability": bins[bin_index],
                        "upper_probability": bins[bin_index + 1],
                        "cases": int(mask.sum()),
                        "mean_predicted_probability": float(probabilities[mask].mean()),
                        "observed_acceptance_rate": float(truth[mask].mean()),
                    })
            for threshold in np.round(np.arange(0.20, 0.801, 0.05), 2):
                threshold_predictions = (probabilities >= threshold).astype(int)
                threshold_rows.append({
                    "model": kind,
                    "threshold": float(threshold),
                    "accuracy": float(accuracy_score(truth, threshold_predictions)),
                    "balanced_accuracy": float(balanced_accuracy_score(truth, threshold_predictions)),
                    "predicted_acceptance_rate": float(threshold_predictions.mean()),
                    "false_positive_rate": float(
                        np.mean(threshold_predictions[truth == 0] == 1)
                    ),
                    "false_negative_rate": float(
                        np.mean(threshold_predictions[truth == 1] == 0)
                    ),
                })
            for bootstrap_id, sampled in enumerate(shared_bootstrap_indices, start=1):
                sampled_truth = truth[sampled]
                sampled_probabilities = probabilities[sampled]
                bootstrap_rows.append({
                    "bootstrap_id": bootstrap_id,
                    "model": kind,
                    **predictive_metrics(sampled_truth, sampled_probabilities, "probe"),
                })

            feature_only_traces = [
                ["START", *trace[1:-1], "END"] for trace in artifact["open_traces"]
            ]
            for comparison_index, (
                task_name,
                group_a_label,
                group_b_label,
                group_a_function,
                group_b_function,
            ) in enumerate(comparisons):
                comparison = self._subgroup_comparison(
                    kind,
                    feature_only_traces,
                    group_a_function(truth, predictions),
                    group_b_function(truth, predictions),
                    group_a_label,
                    group_b_label,
                    subgroup_dirs[task_name],
                    seed=self.config.random_state + 5600 + 100 * comparison_index + model_index,
                )
                comparison["summary"]["task"] = task_name
                subgroup_rows.append(comparison["summary"])
                for row in comparison["bootstrap"]:
                    row["task"] = task_name
                    subgroup_bootstrap_rows.append(row)
                for row in comparison["permutation"]:
                    row["task"] = task_name
                    subgroup_permutation_rows.append(row)

        summary = pd.DataFrame(summary_rows)
        case_frame = pd.DataFrame(case_rows)
        importance = pd.DataFrame(importance_rows)
        calibration = pd.DataFrame(calibration_rows)
        thresholds = pd.DataFrame(threshold_rows)
        bootstraps = pd.DataFrame(bootstrap_rows)
        subgroup_summary = pd.DataFrame(subgroup_rows)
        valid_p = subgroup_summary["permutation_p_value"].notna()
        subgroup_summary["permutation_fdr_q_value"] = np.nan
        subgroup_summary.loc[valid_p, "permutation_fdr_q_value"] = _benjamini_hochberg(
            subgroup_summary.loc[valid_p, "permutation_p_value"].to_numpy(dtype=float)
        )
        subgroup_bootstraps = pd.DataFrame(subgroup_bootstrap_rows)
        subgroup_permutations = pd.DataFrame(subgroup_permutation_rows)
        bootstrap_summary_rows = []
        for model, group in bootstraps.groupby("model"):
            for metric in [
                "probe_accuracy", "probe_balanced_accuracy", "probe_roc_auc",
                "probe_log_loss", "probe_brier_score",
            ]:
                stats = _interval(group[metric].to_numpy())
                bootstrap_summary_rows.append({
                    "model": model,
                    "measure": metric,
                    **stats,
                })
        bootstrap_summary = pd.DataFrame(bootstrap_summary_rows)

        summary.to_csv(output_dir / "model_decision_ground_truth_summary.csv", index=False)
        case_frame.to_csv(output_dir / "case_level_prediction_ground_truth.csv", index=False)
        importance.to_csv(output_dir / "confusion_class_feature_importance.csv", index=False)
        calibration.to_csv(output_dir / "probability_calibration_bins.csv", index=False)
        thresholds.to_csv(output_dir / "threshold_sensitivity.csv", index=False)
        bootstraps.to_csv(output_dir / "case_bootstrap_replicates.csv", index=False)
        bootstrap_summary.to_csv(output_dir / "case_bootstrap_intervals.csv", index=False)
        subgroup_summary.to_csv(output_dir / "all_task5_subgroup_dfg_comparisons.csv", index=False)
        subgroup_bootstraps.to_csv(output_dir / "all_task5_subgroup_bootstrap_replicates.csv", index=False)
        subgroup_permutations.to_csv(output_dir / "all_task5_subgroup_permutation_replicates.csv", index=False)
        for task_name, directory in subgroup_dirs.items():
            subgroup_summary[subgroup_summary["task"].eq(task_name)].to_csv(
                directory / "dfg_comparison_summary.csv", index=False
            )
            subgroup_bootstraps[subgroup_bootstraps["task"].eq(task_name)].to_csv(
                directory / "dfg_case_bootstrap_replicates.csv", index=False
            )
            subgroup_permutations[subgroup_permutations["task"].eq(task_name)].to_csv(
                directory / "dfg_permutation_null_replicates.csv", index=False
            )

        fig, axes = plt.subplots(1, 3, figsize=(16, 4.8), constrained_layout=True)
        model_order = list(self.task1_artifacts)
        for axis, kind in zip(axes, model_order):
            image = axis.imshow(confusion_matrices[kind], cmap="Blues")
            for row in range(2):
                for column in range(2):
                    axis.text(column, row, str(confusion_matrices[kind][row, column]), ha="center", va="center")
            axis.set_xticks([0, 1], [self.config.negative_label, self.config.positive_label])
            axis.set_yticks([0, 1], [self.config.negative_label, self.config.positive_label])
            axis.set_xlabel("Prediction")
            axis.set_ylabel("Ground truth")
            axis.set_title(self.MODEL_LABELS[kind])
        fig.colorbar(image, ax=axes, shrink=0.8, label="Cases")
        fig.suptitle(f"Task 5: confusion matrices - {self.config.dataset_title}")
        self._save_show(fig, output_dir / "task5_confusion_matrices.png", dpi=220)

        fig, axes = plt.subplots(1, 3, figsize=(16, 4.8), constrained_layout=True)
        x = np.arange(len(summary))
        labels = summary["model_label"].tolist()
        axes[0].bar(x - 0.18, 100 * summary["probe_accuracy"], width=0.36, label="Accuracy")
        axes[0].bar(x + 0.18, 100 * summary["probe_balanced_accuracy"], width=0.36, label="Balanced accuracy")
        axes[0].set_xticks(x, labels, rotation=20, ha="right")
        axes[0].set_ylabel("Score (%)")
        axes[0].legend()
        axes[1].bar(x, summary["probe_roc_auc"], color="#3a7d44")
        axes[1].set_xticks(x, labels, rotation=20, ha="right")
        axes[1].set_ylabel("ROC AUC")
        axes[2].bar(x - 0.18, summary["predicted_acceptance_rate"], width=0.36, label="Predicted")
        axes[2].bar(x + 0.18, summary["ground_truth_acceptance_rate"], width=0.36, label="Ground truth")
        axes[2].set_xticks(x, labels, rotation=20, ha="right")
        axes[2].set_ylabel("Acceptance rate")
        axes[2].legend()
        for axis in axes:
            axis.grid(axis="y", alpha=0.25)
        fig.suptitle(f"Task 5: model decision compared with ground truth - {self.config.dataset_title}")
        self._save_show(fig, output_dir / "task5_prediction_ground_truth_comparison.png", dpi=220)

        fig, axes = plt.subplots(1, 3, figsize=(17, 5), constrained_layout=True)
        for axis, task_name in zip(axes, ["Task 5.1", "Task 5.2", "Task 5.3"]):
            subset = subgroup_summary[subgroup_summary["task"].eq(task_name)].reset_index(drop=True)
            positions = np.arange(len(subset))
            observed = subset["observed_l1_distance"].to_numpy(dtype=float)
            lower = subset["bootstrap_l1_distance_p025"].to_numpy(dtype=float)
            upper = subset["bootstrap_l1_distance_p975"].to_numpy(dtype=float)
            axis.vlines(positions, lower, upper, color="#2f6690", linewidth=1.6)
            axis.scatter(positions, observed, color="#2f6690", zorder=3)
            axis.set_xticks(positions, subset["model_label"], rotation=20, ha="right")
            axis.set_ylabel("Normalized-frequency L1 DFG distance")
            axis.set_title(task_name)
            axis.grid(axis="y", alpha=0.25)
            for position, row in enumerate(subset.itertuples(index=False)):
                if np.isfinite(row.permutation_fdr_q_value):
                    if position == 0:
                        horizontal_alignment = "left"
                        text_offset = (5, 10)
                    elif position == len(subset) - 1:
                        horizontal_alignment = "right"
                        text_offset = (-5, 10)
                    else:
                        horizontal_alignment = "center"
                        text_offset = (0, 10)
                    axis.annotate(
                        f"q={row.permutation_fdr_q_value:.3g}",
                        (position, row.observed_l1_distance),
                        xytext=text_offset,
                        textcoords="offset points",
                        ha=horizontal_alignment,
                    )
        fig.suptitle(f"Task 5 subgroup feature-DFG comparisons - {self.config.dataset_title}")
        self._save_show(fig, output_dir / "task5_all_subgroup_dfg_comparisons.png", dpi=220)
        display(summary.round(5))
        display(subgroup_summary[[
            "task", "model_label", "group_a_cases", "group_b_cases",
            "observed_l1_distance", "bootstrap_l1_distance_p025",
            "bootstrap_l1_distance_p975", "permutation_p_value",
            "permutation_fdr_q_value", "status",
        ]].round(5))
        self.task5_artifacts = {
            "summary": summary,
            "cases": case_frame,
            "importance": importance,
            "calibration": calibration,
            "thresholds": thresholds,
            "bootstrap_summary": bootstrap_summary,
            "subgroup_summary": subgroup_summary,
        }
        return summary

    def run_task6(self) -> pd.DataFrame:
        """Compare accuracy-DFG simplicity, feature count, AIC, and BIC."""
        if not self.task3_artifacts:
            self.run_task3()
        output_dir = self.root / "task6_outputs"
        output_dir.mkdir(exist_ok=True)
        result = self.task3_artifacts["results"].copy().sort_values("feature_group_count")
        path_columns = self.task3_artifacts["path"][[
            "feature_group_count", "dfg_signature_step_change", "dfg_cumulative_path", "dfg_knee_score"
        ]]
        result = result.merge(path_columns, on="feature_group_count", how="left")
        settings = self.task3_artifacts["settings"]
        feature_counts = result["feature_group_count"].to_numpy(dtype=int)
        bootstrap_rng = np.random.default_rng(self.config.random_state + 6601)
        bootstrap_rows = []
        for bootstrap_id in range(self.config.task6_bootstraps):
            sampled = _stratified_bootstrap_indices(self.y_validation, bootstrap_rng)
            for count in feature_counts:
                predictions = settings[int(count)]["validation_predictions"]
                bootstrap_rows.append({
                    "bootstrap_id": bootstrap_id + 1,
                    "feature_group_count": int(count),
                    "accuracy": float(accuracy_score(self.y_validation[sampled], predictions[sampled])),
                })
        bootstrap = pd.DataFrame(bootstrap_rows)
        bootstrap_wide = bootstrap.pivot(
            index="bootstrap_id", columns="feature_group_count", values="accuracy"
        )
        best_accuracy = float(result["validation_accuracy"].max())
        best_count = int(
            result.loc[result["validation_accuracy"].eq(best_accuracy), "feature_group_count"].min()
        )
        best_bootstrap = bootstrap_wide[best_count].to_numpy(dtype=float)
        best_standard_error = float(np.std(best_bootstrap, ddof=1))
        one_se_threshold = best_accuracy - best_standard_error
        interval_rows = []
        for count in feature_counts:
            values = bootstrap_wide[int(count)].to_numpy(dtype=float)
            stats = _interval(values)
            paired = values - best_bootstrap
            paired_stats = _interval(paired)
            interval_rows.append({
                "feature_group_count": int(count),
                "bootstrap_accuracy_mean": stats["mean"],
                "bootstrap_accuracy_standard_error": stats["sd"],
                "bootstrap_accuracy_p025": stats["p025"],
                "bootstrap_accuracy_p975": stats["p975"],
                "paired_accuracy_difference_from_best_mean": paired_stats["mean"],
                "paired_accuracy_difference_from_best_p025": paired_stats["p025"],
                "paired_accuracy_difference_from_best_p975": paired_stats["p975"],
            })
        intervals = pd.DataFrame(interval_rows)
        part1 = result.merge(intervals, on="feature_group_count", how="left")
        families = {
            "size_complexity": ["open_dfg_nodes", "open_dfg_edges"],
            "connectivity_complexity": [
                "rank_excess_edge_occupancy", "effective_transition_dimension_per_feature"
            ],
            "transition_uncertainty": [
                "normalized_ks_entropy", "branching_state_entropy_bits"
            ],
            "rare_transition_cost": ["information_distance_per_rank_step"],
        }
        for family, columns in families.items():
            part1[family] = np.mean(
                np.column_stack([
                    self._minmax(part1[column].to_numpy(dtype=float)) for column in columns
                ]),
                axis=1,
            )
        part1["relative_dfg_complexity_index"] = part1[list(families)].mean(axis=1)
        part1["size_adjusted_dfg_complexity_index"] = part1[[
            "connectivity_complexity", "transition_uncertainty", "rare_transition_cost"
        ]].mean(axis=1)
        part1["relative_dfg_simplicity_index"] = 1.0 - part1["relative_dfg_complexity_index"]
        part1["within_one_se_set"] = part1["validation_accuracy"] >= one_se_threshold - 1e-15
        part1["dfg_pareto_within_one_se_set"] = False
        candidate_positions = np.flatnonzero(part1["within_one_se_set"].to_numpy())
        for position in candidate_positions:
            accuracy = float(part1.loc[position, "validation_accuracy"])
            complexity = float(part1.loc[position, "relative_dfg_complexity_index"])
            dominated = False
            for other in candidate_positions:
                if other == position:
                    continue
                other_accuracy = float(part1.loc[other, "validation_accuracy"])
                other_complexity = float(part1.loc[other, "relative_dfg_complexity_index"])
                if (
                    other_accuracy >= accuracy - 1e-15
                    and other_complexity <= complexity + 1e-15
                    and (other_accuracy > accuracy + 1e-15 or other_complexity < complexity - 1e-15)
                ):
                    dominated = True
                    break
            if not dominated:
                part1.loc[position, "dfg_pareto_within_one_se_set"] = True
        pareto = part1[part1["dfg_pareto_within_one_se_set"]].sort_values(
            ["relative_dfg_complexity_index", "validation_accuracy", "feature_group_count"],
            ascending=[True, False, True],
        )
        selected_count = int(pareto.iloc[0]["feature_group_count"])
        part1["selected_by_task6_1"] = part1["feature_group_count"].eq(selected_count)
        sensitivity_rows = []
        near_best = part1[part1["within_one_se_set"]]
        for family in families:
            selected = near_best.sort_values(
                [family, "validation_accuracy", "feature_group_count"],
                ascending=[True, False, True],
            ).iloc[0]
            sensitivity_rows.append({
                "complexity_family": family,
                "selected_feature_count": int(selected["feature_group_count"]),
                "validation_accuracy": float(selected["validation_accuracy"]),
                "family_complexity": float(selected[family]),
            })
        sensitivity = pd.DataFrame(sensitivity_rows)
        selected_row = part1[part1["feature_group_count"].eq(selected_count)].iloc[0]
        selection_summary = pd.DataFrame([{
            "best_observed_accuracy_feature_count": best_count,
            "best_observed_validation_accuracy": best_accuracy,
            "best_accuracy_bootstrap_standard_error": best_standard_error,
            "one_se_accuracy_threshold": one_se_threshold,
            "one_se_feature_counts": " | ".join(
                near_best["feature_group_count"].astype(int).astype(str)
            ),
            "selected_feature_count": selected_count,
            "selected_feature_groups": selected_row["included_feature_groups"],
            "selected_validation_accuracy": float(selected_row["validation_accuracy"]),
            "accuracy_regret_percentage_points": 100 * (
                best_accuracy - float(selected_row["validation_accuracy"])
            ),
            "selection_rule": "minimum DFG complexity on the accuracy-DFG Pareto frontier inside the one-SE set",
            "test_evaluated_after_selection": True,
        }])
        selected_test_probabilities = settings[selected_count]["model"].predict_proba(
            self.X_test[:, settings[selected_count]["indices"]]
        )[:, 1]
        selected_test_metrics = predictive_metrics(
            self.y_test, selected_test_probabilities, "test"
        )
        for key, value in selected_test_metrics.items():
            selection_summary[key] = value

        part1.to_csv(output_dir / "task6_1_accuracy_dfg_simplicity.csv", index=False)
        bootstrap.to_csv(output_dir / "task6_1_paired_accuracy_bootstrap_replicates.csv", index=False)
        intervals.to_csv(output_dir / "task6_1_accuracy_bootstrap_intervals.csv", index=False)
        sensitivity.to_csv(output_dir / "task6_1_dfg_simplicity_sensitivity.csv", index=False)
        selection_summary.to_csv(output_dir / "task6_1_selection_summary.csv", index=False)
        measure_definitions = pd.DataFrame([
            {"family": "size_complexity", "measures": "nodes; edges", "interpretation": "larger graph"},
            {
                "family": "connectivity_complexity",
                "measures": "rank excess-edge occupancy; effective transition dimension per feature",
                "interpretation": "more branching after removing graph-size capacity",
            },
            {
                "family": "transition_uncertainty",
                "measures": "normalized KS entropy; branching-state entropy",
                "interpretation": "less predictable routing, adjusted for deterministic rank steps",
            },
            {
                "family": "rare_transition_cost",
                "measures": "information distance per rank step",
                "interpretation": "rarer transition paths after rank-length adjustment",
            },
        ])
        measure_definitions.to_csv(output_dir / "task6_1_dfg_measure_definitions.csv", index=False)

        part2 = part1.copy()
        part2["marginal_accuracy_change"] = part2["validation_accuracy"].diff()
        part2["marginal_accuracy_change_percentage_points"] = 100 * part2["marginal_accuracy_change"]
        part2["accuracy_gain_from_one_feature_percentage_points"] = 100 * (
            part2["validation_accuracy"] - part2.iloc[0]["validation_accuracy"]
        )
        part2["accuracy_regret_from_best_percentage_points"] = 100 * (
            best_accuracy - part2["validation_accuracy"]
        )
        part2["selected_by_maximum_accuracy"] = part2["feature_group_count"].eq(best_count)
        trend_rows = []
        for measure in ["validation_accuracy", "validation_roc_auc"]:
            statistic = spearmanr(part2["feature_group_count"], part2[measure])
            trend_rows.append({
                "measure": measure,
                "spearman_rho": float(statistic.statistic),
                "two_sided_p_value": float(statistic.pvalue),
                "settings": len(part2),
            })
        trends = pd.DataFrame(trend_rows)
        part2.to_csv(output_dir / "task6_2_accuracy_vs_feature_count.csv", index=False)
        trends.to_csv(output_dir / "task6_2_feature_count_trend_tests.csv", index=False)

        aic_count = int(part2.loc[part2["AIC"].idxmin(), "feature_group_count"])
        aicc_count = int(part2.loc[part2["AICc"].idxmin(), "feature_group_count"])
        bic_count = int(part2.loc[part2["BIC"].idxmin(), "feature_group_count"])
        dfg_count = int(self.task3_artifacts["selected_count"])
        part3 = part2.copy()
        part3["delta_AIC_from_minimum"] = part3["AIC"] - part3["AIC"].min()
        part3["delta_AICc_from_minimum"] = part3["AICc"] - part3["AICc"].min()
        part3["delta_BIC_from_minimum"] = part3["BIC"] - part3["BIC"].min()
        part3["selected_by_minimum_AIC"] = part3["feature_group_count"].eq(aic_count)
        part3["selected_by_minimum_AICc"] = part3["feature_group_count"].eq(aicc_count)
        part3["selected_by_minimum_BIC"] = part3["feature_group_count"].eq(bic_count)
        methods = [
            ("Task 3 DFG-only knee", dfg_count),
            ("Task 6.1 one-SE plus DFG simplicity", selected_count),
            ("Maximum validation accuracy", best_count),
            ("Minimum AIC", aic_count),
            ("Minimum AICc", aicc_count),
            ("Minimum BIC", bic_count),
        ]
        selected_test_metrics_by_count = {}
        for count in sorted({count for _, count in methods}):
            artifact = settings[int(count)]
            probabilities = artifact["model"].predict_proba(
                self.X_test[:, artifact["indices"]]
            )[:, 1]
            selected_test_metrics_by_count[int(count)] = predictive_metrics(
                self.y_test, probabilities, "test"
            )
        method_rows = []
        for method, count in methods:
            row = part3[part3["feature_group_count"].eq(count)].iloc[0]
            method_rows.append({
                "method": method,
                "selected_feature_count": count,
                "included_feature_groups": row["included_feature_groups"],
                "validation_accuracy": float(row["validation_accuracy"]),
                "validation_roc_auc": float(row["validation_roc_auc"]),
                **selected_test_metrics_by_count[int(count)],
                "relative_dfg_complexity_index": float(row["relative_dfg_complexity_index"]),
                "size_adjusted_dfg_complexity_index": float(
                    row["size_adjusted_dfg_complexity_index"]
                ),
                "AIC": float(row["AIC"]),
                "AICc": float(row["AICc"]),
                "BIC": float(row["BIC"]),
                "delta_AIC_from_global_minimum": float(row["delta_AIC_from_minimum"]),
                "delta_BIC_from_global_minimum": float(row["delta_BIC_from_minimum"]),
                "test_evaluation_scope": (
                    "evaluated only after this validation/DFG/information-criterion rule was fixed"
                ),
            })
        method_summary = pd.DataFrame(method_rows)
        part3.to_csv(output_dir / "task6_3_aic_bic_comparison.csv", index=False)
        method_summary.to_csv(output_dir / "task6_method_comparison_summary.csv", index=False)

        x = part1["feature_group_count"].to_numpy(dtype=float)
        fig, axes = plt.subplots(2, 3, figsize=(17, 10), constrained_layout=True)
        axes = axes.ravel()
        lower = 100 * part1["bootstrap_accuracy_p025"].to_numpy(dtype=float)
        upper = 100 * part1["bootstrap_accuracy_p975"].to_numpy(dtype=float)
        accuracy_percent = 100 * part1["validation_accuracy"].to_numpy(dtype=float)
        axes[0].plot(x, accuracy_percent, marker="o")
        axes[0].fill_between(x, lower, upper, alpha=0.16)
        axes[0].axhline(100 * one_se_threshold, linestyle="--", color="#c05a47", label="One-SE threshold")
        axes[0].set_ylabel("Validation accuracy (%)")
        axes[0].legend()
        axes[1].plot(x, part1["relative_dfg_complexity_index"], marker="o", color="#b56576")
        axes[1].set_ylabel("Relative DFG complexity")
        axes[2].plot(x, part1["open_dfg_nodes"], marker="o", label="Nodes")
        axes[2].plot(x, part1["open_dfg_edges"], marker="s", label="Edges")
        axes[2].set_ylabel("DFG size")
        axes[2].legend()
        axes[3].plot(x, part1["rank_excess_edge_occupancy"], marker="o", label="Excess-edge occupancy")
        axes[3].plot(
            x,
            part1["effective_transition_dimension_per_feature"],
            marker="s",
            label="Effective dimension / feature",
        )
        axes[3].set_ylabel("Size-adjusted connectivity")
        axes[3].legend()
        axes[4].plot(x, part1["normalized_ks_entropy"], marker="o", label="Normalized KS entropy")
        axes[4].plot(
            x,
            part1["branching_state_entropy_bits"],
            marker="s",
            label="Branching-state entropy",
        )
        axes[4].set_ylabel("Transition uncertainty")
        axes[4].legend()
        task6_tradeoff_scatter = axes[5].scatter(
            part1["relative_dfg_complexity_index"],
            accuracy_percent,
            c=x,
            cmap="viridis",
            s=55,
        )
        fig.colorbar(
            task6_tradeoff_scatter,
            ax=axes[5],
            label="Feature-group count",
            shrink=0.82,
        )
        for landmark_count in sorted({selected_count, best_count}):
            row = part1[part1["feature_group_count"].eq(landmark_count)].iloc[0]
            axes[5].annotate(
                f"k={landmark_count}",
                (row["relative_dfg_complexity_index"], 100 * row["validation_accuracy"]),
                xytext=(5, 6),
                textcoords="offset points",
                fontweight="bold",
            )
        axes[5].set_xlabel("Relative DFG complexity")
        axes[5].set_ylabel("Validation accuracy (%)")
        for axis in axes[:5]:
            axis.axvline(selected_count, linestyle="--", color="black", alpha=0.6)
            axis.set_xlabel("Number of original feature groups")
        for axis in axes:
            axis.grid(alpha=0.25)
        fig.suptitle(f"Task 6.1: accuracy versus DFG simplicity - {self.config.dataset_title}")
        self._save_show(fig, output_dir / "task6_1_accuracy_vs_dfg_simplicity.png", dpi=220)

        fig, axes = plt.subplots(2, 2, figsize=(14, 9), constrained_layout=True)
        axes = axes.ravel()
        axes[0].plot(x, accuracy_percent, marker="o")
        axes[0].fill_between(x, lower, upper, alpha=0.16)
        axes[0].set_ylabel("Validation accuracy (%)")
        axes[1].bar(x, part2["marginal_accuracy_change_percentage_points"].fillna(0.0), color="#c05a47")
        axes[1].axhline(0, color="black", linewidth=0.8)
        axes[1].set_ylabel("Marginal accuracy change (pp)")
        axes[2].plot(x, part2["validation_roc_auc"], marker="o", color="#3a7d44")
        axes[2].set_ylabel("Validation ROC AUC")
        axes[3].plot(x, part2["accuracy_regret_from_best_percentage_points"], marker="o", color="#7a5195")
        axes[3].set_ylabel("Accuracy regret from best (pp)")
        for axis in axes:
            axis.axvline(best_count, linestyle="--", color="black", alpha=0.6)
            axis.set_xlabel("Number of original feature groups")
            axis.grid(alpha=0.25)
        fig.suptitle(f"Task 6.2: accuracy versus number of features - {self.config.dataset_title}")
        self._save_show(fig, output_dir / "task6_2_accuracy_vs_feature_count.png", dpi=220)

        fig, axes = plt.subplots(2, 2, figsize=(14, 9), constrained_layout=True)
        axes = axes.ravel()
        axes[0].plot(x, part3["delta_AIC_from_minimum"], marker="o", label="Delta AIC")
        axes[0].plot(x, part3["delta_AICc_from_minimum"], marker="^", label="Delta AICc")
        axes[0].plot(x, part3["delta_BIC_from_minimum"], marker="s", label="Delta BIC")
        axes[0].set_ylabel("Difference from minimum")
        axes[0].legend()
        axes[1].plot(x, part3["design_rank_p"], marker="o", color="#7a5195")
        axes[1].set_ylabel("Design rank p")
        axes[2].scatter(part3["relative_dfg_complexity_index"], part3["AIC"], c=x, cmap="viridis")
        axes[2].set_xlabel("Relative DFG complexity")
        axes[2].set_ylabel("AIC")
        axes[3].scatter(part3["relative_dfg_complexity_index"], part3["BIC"], c=x, cmap="viridis")
        axes[3].set_xlabel("Relative DFG complexity")
        axes[3].set_ylabel("BIC")
        for axis in axes[:2]:
            axis.set_xlabel("Number of original feature groups")
        for axis in axes:
            axis.grid(alpha=0.25)
        fig.suptitle(f"Task 6.3: our approach compared with AIC and BIC - {self.config.dataset_title}")
        self._save_show(fig, output_dir / "task6_3_dfg_vs_aic_bic.png", dpi=220)
        display(selection_summary)
        display(trends.round(5))
        display(method_summary.round(5))
        self.task6_artifacts = {
            "part1": part1,
            "part2": part2,
            "part3": part3,
            "selection_summary": selection_summary,
            "trend_tests": trends,
            "method_summary": method_summary,
        }
        return method_summary

    def write_run_summary(self) -> pd.DataFrame:
        """Write one compact index of the completed task outputs."""
        rows = [
            {"task": "Task 1", "output_directory": "task1_outputs", "primary_file": "model_graph_summary.csv"},
            {"task": "Task 2", "output_directory": "task2_outputs", "primary_file": "baseline_model_entropy.csv"},
            {"task": "Task 2.1", "output_directory": "task2_1_outputs", "primary_file": "random_forest_depth_validation_entropy.csv"},
            {"task": "Task 2.2", "output_directory": "task2_2_outputs", "primary_file": "logistic_regression_c_validation_entropy.csv"},
            {"task": "Task 2.3", "output_directory": "task2_3_outputs", "primary_file": "neural_network_alpha_validation_entropy.csv"},
            {"task": "Task 2.3.1", "output_directory": "task2_3_1_outputs", "primary_file": "neural_network_architecture_validation_entropy.csv"},
            {"task": "Task 2.3.2", "output_directory": "task2_3_2_outputs", "primary_file": "early_stopping_validation_performance.csv"},
            {"task": "Task 2.4", "output_directory": "task2_4_outputs", "primary_file": "hyperparameter_model_dfg_measures.csv"},
            {"task": "Task 3", "output_directory": "task3_outputs", "primary_file": "dfg_only_selection_summary.csv"},
            {"task": "Task 4", "output_directory": "task4_outputs", "primary_file": "complexity_stability_summary.csv"},
            {"task": "Task 5", "output_directory": "task5_outputs", "primary_file": "model_decision_ground_truth_summary.csv"},
            {"task": "Task 6", "output_directory": "task6_outputs", "primary_file": "task6_method_comparison_summary.csv"},
        ]
        frame = pd.DataFrame(rows)
        frame.to_csv(self.root / "tasks_1_to_6_output_manifest.csv", index=False)
        display(frame)
        return frame
