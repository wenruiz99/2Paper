"""Compare calibrated likelihood-plus-graph penalties on verified Task 7.6 fits."""
from pathlib import Path
import json
import platform

import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator, PercentFormatter
import networkx as nx
import numpy as np
import pandas as pd
from IPython.display import Markdown, display

from bpi_task7_6_likelihood_ks import calibrate, envelope, select_count, objective, sha256
from bpi_task7_5_centrality import node_centralities
from bpi_task7_2_explanation_coding import _save_figure

INPUT = 'task7_6_likelihood_ks_outputs'
OUTPUT = 'task7_7_graph_measure_outputs'
MEASURES = {
    'ks_bits': ('KS entropy (reference)', 'Transition uncertainty', 'Bits per transition'),
    'edge_count': ('Edge count', 'Graph size', 'Observed directed edges'),
    'edge_surplus': ('Excess edges', 'Branching support', 'Edges beyond a chain'),
    'density': ('Directed density', 'Structural proxy', 'M / [N(N-1)]'),
    'reachable_diameter': ('Reachable diameter', 'Structural proxy', 'Maximum finite hop distance'),
    'closeness': ('Outward closeness', 'Centrality proxy', 'Feature-node mean'),
    'betweenness': ('Betweenness', 'Centrality proxy', 'Feature-node mean'),
    'eigenvector': ('Undirected eigenvector', 'Centrality proxy', 'Feature-node mean (L2 normalized)'),
    'l1_distance_full': ('L1 distance to full DFG', 'Fidelity control, not simplicity', '1 - normalized-frequency L1 similarity'),
}
CENTRALITIES = ('closeness', 'betweenness', 'eigenvector')
METRICS = ('validation_accuracy', 'validation_roc_auc', 'validation_log_loss')


def l1_distance(graph, reference):
    def normalized(g):
        total = sum(float(d['weight']) for _, _, d in g.edges(data=True))
        if total <= 0:
            raise ValueError('Positive edge mass required.')
        return {(u, v): float(d['weight']) / total for u, v, d in g.edges(data=True)}
    p, q = normalized(graph), normalized(reference)
    return .5 * sum(abs(p.get(edge, 0.) - q.get(edge, 0.)) for edge in p.keys() | q.keys())


def graph_measures(closed, reference_open=None):
    if not isinstance(closed, nx.DiGraph) or closed.is_multigraph() or not closed.has_edge('END', 'START'):
        raise ValueError('Expected a restart-closed feature-ranking DiGraph.')
    weights = nx.to_numpy_array(closed, weight='weight')
    outgoing = weights.sum(axis=1)
    if (not np.isfinite(weights).all() or (weights < 0).any() or outgoing.min() <= 0
            or not np.allclose(outgoing, outgoing[0]) or not np.allclose(outgoing, weights.sum(axis=0))):
        raise ValueError('Complete ranking paths must have equal visits and balanced flow.')
    graph = closed.copy()
    graph.remove_edge('END', 'START')
    features = [u for u in graph if u not in ('START', 'END')]
    if not features or graph.in_degree('START') or graph.out_degree('END') or list(nx.selfloop_edges(graph)):
        raise ValueError('Invalid open ranking graph boundary structure.')
    values = node_centralities(graph)
    values['node_type'] = np.where(values.node.isin(features), 'feature', 'boundary')
    p = weights / outgoing[:, None]
    positive = p > 0
    n, m = len(graph), graph.number_of_edges()
    result = {
        'ks_bits': max(0., float(-np.sum(p[positive] * np.log2(p[positive])) / n)),
        'node_count': n, 'edge_count': m, 'edge_surplus': m - (n - 1),
        'density': float(nx.density(graph)),
        'reachable_diameter': max(d for _, lengths in nx.all_pairs_shortest_path_length(graph) for v, d in lengths.items()),
    }
    for name in CENTRALITIES:
        result[name] = float(values.loc[values.node_type.eq('feature'), name].mean())
        result['all_nodes_' + name] = float(values[name].mean())
    if reference_open is not None:
        result['l1_distance_full'] = l1_distance(graph, reference_open)
    return result, values, graph


def penalty_frame(frame, measure):
    """Adapt the existing scalar-penalty calibrator; never relabel its exports as KS."""
    result = frame.copy()
    values = result[measure].to_numpy(float)
    if not np.isfinite(values).all() or (values < 0).any():
        raise ValueError('A finite nonnegative graph penalty is required.')
    result['ks_bits'] = values
    return result


def calibrate_measure(folds, measure):
    table, choices, lock = calibrate(penalty_frame(folds, measure))
    table = table.rename(columns={'mean_ks_bits': 'mean_penalty_measure', 'one_se_ks_choice': 'one_se_choice'})
    table['eligible_policies'] = int(table.within_one_se.sum())
    table['total_policies'] = len(table)
    table['one_se_loss_threshold'] = lock['one_se_threshold']
    choices = choices.rename(columns={'ks_bits': 'penalty_measure'})
    table.insert(0, 'measure', measure)
    choices.insert(0, 'measure', measure)
    return table, choices, lock


def load_candidates(root):
    """Verify saved fit evidence, retaining all prior files unchanged."""
    hashes = {}
    def record(path):
        hashes[str(path.relative_to(root))] = sha256(path)
        return path
    protocol = json.loads(record(root / INPUT / 'analysis_protocol.json').read_text())
    for name, digest in protocol['input_sha256'].items():
        if sha256(root / name) != digest:
            raise ValueError('Task 7.6 source changed: ' + name)
        hashes[name] = digest
    for name, digest in protocol['implementation_sha256'].items():
        if sha256(root / name) != digest:
            raise ValueError('Task 7.6 implementation changed: ' + name)
        hashes[name] = digest
    rows, nodes = [], []
    fold_count = int(protocol['inner_folds'])
    for fold in [*range(1, fold_count + 1), 0]:
        directory = root / INPUT / (f'inner_fold_{fold}' if fold else 'final_training')
        manifest = json.loads(record(directory / 'fit_cache.json').read_text())
        for name, digest in manifest['files'].items():
            if sha256(record(directory / name)) != digest:
                raise ValueError('Changed Task 7.6 fit artifact: ' + name)
        frame = pd.read_csv(directory / 'candidate_results.csv').sort_values('feature_group_count')
        if frame.feature_group_count.tolist() != list(range(1, len(frame) + 1)):
            raise ValueError('Every feature count is required.')
        if not (np.diff(frame.training_log_likelihood) >= -1e-4).all():
            raise ValueError('Nested likelihood decreased beyond solver tolerance.')
        full_closed = nx.read_graphml(directory / f'feature_count_{len(frame):02d}_closed_dfg.graphml')
        full_open = full_closed.copy()
        full_open.remove_edge('END', 'START')
        for row in frame.to_dict('records'):
            g = int(row['feature_group_count'])
            closed = nx.read_graphml(directory / f'feature_count_{g:02d}_closed_dfg.graphml')
            measured, node_values, _ = graph_measures(closed, full_open)
            if (not np.isclose(measured['ks_bits'], row['ks_bits'], atol=1e-10, rtol=0)
                    or measured['node_count'] != row['open_dfg_nodes'] or measured['edge_count'] != row['open_dfg_edges']):
                raise ValueError('Task 7.6 graph/metric mismatch.')
            rows.append({**row, **measured, 'fold': fold})
            node_values.insert(0, 'feature_group_count', g)
            node_values.insert(0, 'fold', fold)
            nodes.append(node_values)
    all_candidates = pd.DataFrame(rows)
    return all_candidates[all_candidates.fold.ne(0)].copy(), all_candidates[all_candidates.fold.eq(0)].copy(), pd.concat(nodes), hashes, protocol


def make_plots(final, calibration, selected, locks, sensitivity, out, show):
    n = int(final.training_cases.iloc[0])
    labels = list(MEASURES)
    primary = selected[selected.rule.eq('One-SE measure preference')].set_index('measure').loc[labels]
    reference = selected[selected.rule.eq('Minimum inner log loss')].set_index('measure').loc[labels]
    with plt.rc_context({'font.size': 10, 'axes.spines.top': False, 'axes.spines.right': False}):
        for kind, filename, heading in [
                ('profiles', 'measure_profiles.png', 'Graph measures on the same final-training candidates'),
                ('calibration', 'weight_calibration.png', 'Training-only weight calibration; fold SE is a heuristic'),
                ('paths', 'selection_paths.png', 'Final-model selection intervals; lambda has different units across measures'),
                ('objective', 'objective_differences.png', 'Each score minus its own minimum; compare within panels only')]:
            fig, axes = plt.subplots(3, 3, figsize=(15, 12), constrained_layout=True)
            for ax, measure in zip(axes.flat, labels):
                title, category, unit = MEASURES[measure]
                chosen = primary.loc[measure]
                best = reference.loc[measure]
                if kind == 'profiles':
                    ax.plot(final.feature_group_count, final[measure], 'o-', markersize=4, color='#28688f')
                    if measure in CENTRALITIES:
                        ax.plot(final.feature_group_count, final['all_nodes_' + measure], '--', color='#b36732', label='All-node mean (sensitivity)')
                        ax.legend(fontsize=8)
                    ax.set(xlabel='Feature groups (g)', ylabel=unit)
                    ax.xaxis.set_major_locator(MaxNLocator(integer=True))
                elif kind == 'calibration':
                    table = calibration[calibration.measure.eq(measure)]
                    ax.errorbar(table.lambda_final_scale, table.mean_log_loss, yerr=table.log_loss_se,
                                fmt='o-', markersize=3, capsize=2, color='#777777')
                    ax.axhline(locks[measure]['one_se_threshold'], color='#b36732', linestyle=':', label='One-SE allowance')
                    ax.axvline(best['lambda'], color='#28688f', linestyle='--', label='Minimum loss')
                    ax.axvline(chosen['lambda'], color='#288068', linestyle=':', label='One-SE')
                    ax.set_xscale('symlog', linthresh=.01)
                    ax.set(xlim=(0, max(1, table.lambda_final_scale.max() * 1.3)), xlabel='Lambda (final-size scale)', ylabel='Inner mean log loss + fold SE')
                    ax.legend(fontsize=8)
                elif kind == 'paths':
                    env = envelope(penalty_frame(final, measure))
                    right = max(1, env.alpha_lower.max() * n * 1.3, chosen['lambda'] * 1.3, best['lambda'] * 1.3)
                    ax.step(np.r_[env.alpha_lower * n, right], np.r_[env.selected_feature_group_count, env.selected_feature_group_count.iloc[-1]],
                            where='post', color='#555555')
                    ax.axvline(best['lambda'], linestyle='--', color='#28688f', label=f"Min loss: g={int(best.selected_g)}")
                    ax.axvline(chosen['lambda'], linestyle=':', color='#288068', label=f"One-SE: g={int(chosen.selected_g)}")
                    ax.set_xscale('symlog', linthresh=.01)
                    ax.set(xlim=(0, right), xlabel='Lambda (final-size scale)', ylabel='Selected feature groups')
                    ax.yaxis.set_major_locator(MaxNLocator(integer=True))
                    ax.legend(fontsize=8)
                else:
                    for weight, color, style, label in [(0, '#888888', '--', 'No graph penalty'),
                            (best['lambda'], '#28688f', '-', 'Minimum-loss weight'),
                            (chosen['lambda'], '#288068', ':', 'One-SE weight')]:
                        values = objective(final.training_log_likelihood, final[measure], weight)
                        ax.plot(final.feature_group_count, values - values.min(), 'o', markersize=3, linestyle=style, color=color, label=label)
                    ax.set(xlabel='Feature groups (g)', ylabel='Score difference')
                    ax.xaxis.set_major_locator(MaxNLocator(integer=True))
                    ax.legend(fontsize=8)
                ax.set_title(title + ('\nFidelity control, not simplicity' if measure == 'l1_distance_full' else ''))
                ax.grid(alpha=.2)
            fig.suptitle(heading, fontsize=13)
            _save_figure(fig, out / filename, show)

        fig, axes = plt.subplots(1, 3, figsize=(15, 7), constrained_layout=True)
        y = np.arange(len(labels))
        for ax, metric, title in zip(axes, METRICS, ('Validation accuracy', 'Validation ROC AUC', 'Validation log loss')):
            for index, measure in enumerate(labels):
                a, b = reference.loc[measure], primary.loc[measure]
                ax.plot([a[metric], b[metric]], [index-.12, index+.12], color='#aaaaaa')
                ax.scatter(a[metric], index-.12, color='#28688f', marker='s', s=35, label='Minimum-loss weight' if index == 0 else None)
                ax.scatter(b[metric], index+.12, color='#288068', s=35, label='One-SE weight' if index == 0 else None)
                text = f"{b[metric]:.2%}" if metric.endswith('accuracy') else f"{b[metric]:.4f}"
                ax.annotate(text, (b[metric], index+.12), xytext=(7, 0), textcoords='offset points', va='center', fontsize=8)
            values = np.r_[reference[metric], primary[metric]]
            spread = max(float(np.ptp(values)), .005)
            ax.set(xlim=(values.min()-.2*spread, values.max()+.9*spread), title=title, yticks=y,
                   yticklabels=[f"{MEASURES[m][0]} (g={int(primary.loc[m].selected_g)})" for m in labels] if metric == METRICS[0] else ['']*len(labels))
            ax.invert_yaxis()
            ax.grid(axis='x', alpha=.2)
            ax.legend(fontsize=8, loc='upper center', bbox_to_anchor=(.5, -.07))
            if metric.endswith('accuracy'):
                ax.xaxis.set_major_formatter(PercentFormatter(1, decimals=1))
        fig.suptitle('Descriptive outer-validation comparison; not used to choose a winning measure', fontsize=13)
        _save_figure(fig, out / 'validation_comparison.png', show)

        table = sensitivity.pivot(index='measure', columns='omitted_fold', values='selected_g').loc[labels]
        fig, ax = plt.subplots(figsize=(10, 7), constrained_layout=True)
        canvas = ax.imshow(table.to_numpy(), cmap='cividis', vmin=1, vmax=int(final.feature_group_count.max()), aspect='auto')
        for i in range(len(table)):
            for j in range(len(table.columns)):
                value = int(table.iloc[i, j])
                ax.text(j, i, str(value), ha='center', va='center', color='white' if value < final.feature_group_count.max()*.55 else 'black')
        ax.set(xticks=range(len(table.columns)), xticklabels=[f'Omit fold {int(f)}' for f in table.columns],
               yticks=range(len(labels)), yticklabels=[MEASURES[m][0] for m in labels],
               title='One-SE selection after omitting one calibration fold')
        fig.colorbar(canvas, ax=ax, label='Selected final-model feature groups', shrink=.8)
        _save_figure(fig, out / 'fold_omission_sensitivity.png', show)


def run_task7_7(root='.', show=True):
    root = Path(root).resolve()
    out = root / OUTPUT
    out.mkdir(exist_ok=True)
    folds, final, nodes, hashes, protocol76 = load_candidates(root)
    n = int(final.training_cases.iloc[0])
    tables, fold_tables, locks, omitted_rows, aggregation = [], [], {}, [], []
    for measure in MEASURES:
        table, fold_table, lock = calibrate_measure(folds, measure)
        for col, target in [('alpha', 'lambda_final_scale'), ('alpha_lower', 'lambda_lower_final_scale'), ('alpha_upper', 'lambda_upper_final_scale')]:
            table[target] = table[col] * n
        tables.append(table)
        fold_tables.append(fold_table)
        locks[measure] = lock
        for fold in sorted(folds.fold.unique()):
            _, _, alternative = calibrate_measure(folds[folds.fold.ne(fold)], measure)
            a = alternative['one_se_alpha']
            omitted_rows.append({'measure': measure, 'omitted_fold': int(fold), 'alpha': a, 'lambda': a*n,
                                 'selected_g': int(select_count(penalty_frame(final, measure), a).feature_group_count)})
    # All measure-specific preferences are fixed before reading outer performance into the comparison.
    (out / 'calibration_lock.json').write_text(json.dumps({'rules': locks, 'training_cases': n,
        'outer_validation_used_for_calibration': False, 'measure_family_selected': False}, indent=2), encoding='utf-8')
    calibration = pd.concat(tables, ignore_index=True)
    choices, scores, intervals = [], [], []
    for measure, lock in locks.items():
        frame = penalty_frame(final, measure)
        env = envelope(frame)
        env.insert(0, 'measure', measure)
        env['lambda_lower'], env['lambda_upper'] = env.alpha_lower * n, env.alpha_upper * n
        intervals.append(env)
        for rule, alpha in [('No graph penalty', 0.), ('Minimum inner log loss', lock['minimum_loss_alpha']),
                             ('One-SE measure preference', lock['one_se_alpha'])]:
            chosen = select_count(frame, alpha)
            original = final[final.feature_group_count.eq(chosen.feature_group_count)].iloc[0]
            weight = alpha * n
            choices.append({'measure': measure, 'measure_label': MEASURES[measure][0], 'category': MEASURES[measure][1],
                'rule': rule, 'alpha': alpha, 'lambda': weight, 'selected_g': int(chosen.feature_group_count),
                'included_feature_groups': chosen.included_feature_groups, 'penalty_measure': chosen.ks_bits,
                'negative_log_likelihood': -chosen.training_log_likelihood, 'graph_penalty': weight*chosen.ks_bits,
                'objective': -chosen.training_log_likelihood+weight*chosen.ks_bits, 'ks_bits': original.ks_bits,
                'node_count': original.node_count, 'edge_count': original.edge_count,
                **{m: original[m] for m in METRICS}})
            values = objective(final.training_log_likelihood, final[measure], weight)
            scores.extend({'measure': measure, 'rule': rule, 'feature_group_count': int(g), 'lambda': weight,
                           'score': float(value), 'delta_score': float(value-values.min())}
                          for g, value in zip(final.feature_group_count, values))
    selected = pd.DataFrame(choices)
    for measure in CENTRALITIES:
        _, _, alt = calibrate_measure(folds, 'all_nodes_' + measure)
        for rule, key in [('Minimum inner log loss', 'minimum_loss_alpha'), ('One-SE measure preference', 'one_se_alpha')]:
            original = selected[selected.measure.eq(measure) & selected.rule.eq(rule)].iloc[0]
            alternate = select_count(penalty_frame(final, 'all_nodes_' + measure), alt[key])
            aggregation.append({'measure': measure, 'rule': rule, 'feature_node_g': int(original.selected_g),
                                'all_node_g': int(alternate.feature_group_count), 'feature_node_lambda': original['lambda'],
                                'all_node_lambda': n*alt[key], 'same_selected_g': original.selected_g == alternate.feature_group_count})
    old_path = root / INPUT / 'selection_comparison.csv'
    hashes[str(old_path.relative_to(root))] = sha256(old_path)
    old = pd.read_csv(old_path)
    for old_rule, new_rule in [('Minimum inner log loss', 'Minimum inner log loss'), ('One-SE KS preference', 'One-SE measure preference')]:
        a = old[old.rule.eq(old_rule)].iloc[0]
        b = selected[selected.measure.eq('ks_bits') & selected.rule.eq(new_rule)].iloc[0]
        if a.selected_g != b.selected_g or not np.isclose(a['lambda'], b['lambda'], rtol=1e-9, atol=1e-9):
            raise AssertionError('KS reference must reproduce Task 7.6 exactly.')
    definitions = pd.DataFrame([{'measure': key, 'label': value[0], 'category': value[1], 'unit': value[2]} for key, value in MEASURES.items()])
    selected_intervals = calibration[calibration.minimum_loss_choice | calibration.one_se_choice].copy()
    outputs = {'measure_definitions.csv': definitions, 'inner_candidate_measures.csv': folds, 'final_candidate_measures.csv': final,
               'node_centralities.csv': nodes, 'lambda_calibration.csv': calibration, 'calibration_fold_choices.csv': pd.concat(fold_tables),
               'selected_calibration_intervals.csv': selected_intervals, 'selection_comparison.csv': selected,
               'candidate_scores.csv': pd.DataFrame(scores), 'final_exact_lambda_intervals.csv': pd.concat(intervals),
               'leave_one_fold_out_sensitivity.csv': pd.DataFrame(omitted_rows), 'centrality_aggregation_sensitivity.csv': pd.DataFrame(aggregation)}
    for name, table in outputs.items():
        table.to_csv(out / name, index=False)
    make_plots(final, calibration, selected, locks, outputs['leave_one_fold_out_sensitivity.csv'], out, show)
    primary = selected[selected.rule.eq('One-SE measure preference')]
    findings = 'One-SE selected groups: ' + '; '.join(f'{row.measure_label}={row.selected_g}' for row in primary.itertuples()) + '. '
    findings += ('KS reproduces Task 7.6. Weights are measure-specific representatives of intervals, not universal constants. '
                 'Density, diameter and centralities are exploratory structural penalties, not established comprehension costs. '
                 'Distance to the full graph preserves reference fidelity; it is not a simplicity penalty. No winning measure is selected from outer validation.')
    (out / 'findings.txt').write_text(findings+'\n', encoding='utf-8')
    if any(sha256(root / name) != digest for name, digest in hashes.items()):
        raise AssertionError('Task 7.6 artifacts changed during analysis.')
    protocol = {'task': '7.7', 'criterion': '-ln(L_hat_g) + lambda * M_g', 'measure_keys': list(MEASURES),
        'no_bic_or_parameter_penalty': True, 'input_task': '7.6', 'refits': False, 'test_cases_used': False,
        'outer_validation_used_to_tune_lambda': False, 'global_winner_selected': False, 'input_sha256': hashes,
        'task76_split_protocol': protocol76.get('calibration'), 'python': platform.python_version(),
        'implementation_sha256': {name: sha256(root / name) for name in [Path(__file__).name, 'bpi_task7_5_centrality.py', 'bpi_task7_6_likelihood_ks.py']},
        'feature_nodes_primary': True, 'lambda_transfer': 'alpha=lambda/n_training; lambda_final=alpha*n_final',
        'reference_graph': 'Full-feature graph from the same fold, fit, training explanation cohort and unpruned edge frequencies',
        'comparison': 'Paired candidates/folds/explanation samples across measures; minimum-loss and one-SE selections calibrated separately per measure',
        'limitations': ['Lower centrality, density or diameter is not necessarily simpler',
                       'L1 distance to full graph is a fidelity control; full model has zero distance and best nested training likelihood',
                       'Node count equals g+2, reported as size rather than duplicated as a separate penalty',
                       'One-SE is a heuristic with dependent folds, not a noninferiority claim',
                       'Hyperparameter/measure exploration is not an independent assessment of the best measure family',
                       'Historical validation/test inspection and Task 7.6 dataset-specific limitations remain',
                       'No new model-refitting or graph-sampling uncertainty estimation']}
    (out / 'analysis_protocol.json').write_text(json.dumps(protocol, indent=2), encoding='utf-8')
    if show:
        display(Markdown('**Task 7.7 findings.** '+findings))
        display_tables = [
            ('Definitions and interpretation', definitions),
            ('Selected models and outer-validation performance', selected[selected.rule.ne('No graph penalty')][
                ['measure_label', 'rule', 'lambda', 'selected_g', 'penalty_measure', 'ks_bits', 'node_count', 'edge_count', *METRICS]]),
            ('Selected calibration intervals', selected_intervals[['measure', 'alpha_lower', 'alpha_upper', 'lambda_lower_final_scale',
                'lambda_upper_final_scale', 'mean_log_loss', 'log_loss_se', 'mean_penalty_measure', 'fold_selected_groups',
                'eligible_policies', 'total_policies', 'one_se_loss_threshold', 'minimum_loss_choice', 'one_se_choice']]),
            ('Final candidate measures', final[['feature_group_count', 'node_count', *MEASURES]]),
            ('Fold-omission sensitivity', outputs['leave_one_fold_out_sensitivity.csv']),
            ('Centrality aggregation sensitivity', outputs['centrality_aggregation_sensitivity.csv'])]
        for title, table in display_tables:
            display(Markdown('**'+title+'.**'))
            shown = table.copy()
            numeric = shown.select_dtypes(include='number').columns
            shown[numeric] = shown[numeric].round(6)
            with pd.option_context('display.max_rows', 100, 'display.max_columns', 25):
                display(shown)
    print(findings, flush=True)
    return outputs


def append_task77_manifest(frame, root='.'):
    """Extend the displayed manifest without changing checksum-pinned old helpers."""
    root = Path(root).resolve()
    frame = frame[frame.task.ne('Task 7.7')].copy()
    if (root / OUTPUT / 'selection_comparison.csv').exists():
        row = {'task': 'Task 7.7', 'output_directory': OUTPUT, 'primary_file': 'selection_comparison.csv', 'available': True}
        insert = next((i for i, value in enumerate(frame.task) if value == 'Final test report'), len(frame))
        frame = pd.concat([frame.iloc[:insert], pd.DataFrame([row]), frame.iloc[insert:]], ignore_index=True)
    frame.to_csv(root / 'tasks_1_to_7_output_manifest.csv', index=False)
    return frame


def write_task77_manifest(study, show=True):
    from IPython.utils.capture import capture_output
    from multidataset_dfg_extensions import write_extended_manifest
    with capture_output():
        frame = write_extended_manifest(study)
    frame = append_task77_manifest(frame, study.root)
    if show:
        display(frame)
    return frame


if __name__ == '__main__':
    run_task7_7(show=False)
