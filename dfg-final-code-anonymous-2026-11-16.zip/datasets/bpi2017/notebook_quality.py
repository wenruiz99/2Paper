"""Portable, read-only checks of saved study results and explicit cohort loading."""
from __future__ import annotations

from dataclasses import fields
import hashlib
import json
from pathlib import Path
import platform

import networkx as nx
import numpy as np
import pandas as pd
from IPython.display import Markdown, display

from multidataset_dfg_study import StudyConfig, markov_entropy_measures, predictive_metrics, _safe_name


def load_config(root):
    row = pd.read_csv(Path(root) / 'study_protocol_configuration.csv').iloc[0]
    collections = {'features', 'numerical_features', 'categorical_features', 'feature_labels',
                   'context_features', 'sensitivity_exclusions'}
    values = {}
    for field in fields(StudyConfig):
        if field.name in row and not pd.isna(row[field.name]):
            value = row[field.name]
            values[field.name] = json.loads(value) if field.name in collections else value
    return StudyConfig(**values)


def source_filename(config):
    return {'bpi2017_after_first_offer': 'canonical_after_first_offer_final_application_outcome.csv',
            'default_credit_card_clients': 'UCI_Credit_Card.csv',
            'lendingclub': 'canonical_lendingclub_application_sample.csv'}[config.dataset_key]


def load_prepared_cases(root, config, *, verify_contract=True):
    root = Path(root)
    source = root / source_filename(config)
    if verify_contract:
        contract = json.loads((root / 'study_cohort_contract.json').read_text(encoding='utf-8'))
        if hashlib.sha256(source.read_bytes()).hexdigest() != contract['source_sha256']:
            raise ValueError('The source data changed. Create a versioned cohort and rerun the analysis; do not mix saved outputs.')
        manifest = root / config.cohort_manifest
        if hashlib.sha256(manifest.read_bytes()).hexdigest() != contract['membership_sha256']:
            raise ValueError('The pinned cohort membership changed; a new versioned study is required.')
    data = pd.read_csv(source)
    if config.dataset_key == 'default_credit_card_clients':
        targets = [c for c in data if 'default' in c.lower()]
        if len(targets) != 1 or data.ID.isna().any():
            raise ValueError('Credit-card source needs one target and nonmissing IDs.')
        outcome = pd.to_numeric(data[targets[0]], errors='raise')
        if outcome.isna().any() or set(outcome.unique()) != {0, 1}:
            raise ValueError('Credit-card default outcomes must be exactly 0 or 1.')
        data['EDUCATION'] = data.EDUCATION.replace({0: 4, 5: 4, 6: 4})
        data['MARRIAGE'] = data.MARRIAGE.replace({0: 3})
        data['CaseID'] = 'CC_' + data.ID.astype(str)
        data[config.target_column] = 1 - outcome.astype(int)
    if config.time_column:
        data[config.time_column] = pd.to_datetime(data[config.time_column], format='ISO8601', utc=True, errors='raise')
    if 'outcome_time' in data:
        data['outcome_time'] = pd.to_datetime(data.outcome_time, format='ISO8601', utc=True, errors='raise')
    return data


def audit_saved_results(root='.', *, show=True, write=True, strict=True):
    """Verify exported identities, not predictive optimality or causal validity."""
    root = Path(root).resolve()
    config = load_config(root)
    checks = []
    inputs = {}

    def read(relative, **kwargs):
        path = root / relative
        inputs[relative] = hashlib.sha256(path.read_bytes()).hexdigest()
        return pd.read_csv(path, **kwargs)

    def check(task, name, condition, detail):
        checks.append({'task': task, 'check': name, 'status': 'PASS' if bool(condition) else 'FAIL', 'detail': detail})

    def close(task, name, a, b):
        a, b = np.asarray(a, dtype=float), np.asarray(b, dtype=float)
        okay = a.shape == b.shape and np.allclose(a, b, rtol=1e-8, atol=1e-8, equal_nan=True)
        maximum = float(np.nanmax(np.abs(a-b))) if a.shape == b.shape and a.size else np.nan
        check(task, name, okay, f'Maximum absolute discrepancy: {maximum:.3g}')

    partitions = read('study_protocol_partitions.csv').set_index('partition')
    membership = read('study_cohort_membership.csv', dtype={'CaseID': str}, keep_default_na=False)
    check('Protocol', 'Unique case membership', not membership.CaseID.duplicated().any(), f'{len(membership)} source cases')
    for name in ['train', 'validation', 'test']:
        close('Protocol', name + ' case count', membership.partition.eq(name).sum(), partitions.loc[name, 'cases'])
    lock = json.loads((root / 'study_cohort_contract.json').read_text())
    actual_source_hash = hashlib.sha256((root / lock['source_file']).read_bytes()).hexdigest()
    check('Protocol', 'Source matches declared cohort', actual_source_hash == lock['source_sha256'], lock['source_file'])
    check('Protocol', 'Membership matches declared cohort', inputs['study_cohort_membership.csv'] == lock['membership_sha256'],
          'Case partitions and row order are checksum-verified')
    nested = read('task3_outputs/nested_feature_group_model_dfg_measures.csv').set_index('feature_group_count')
    n = int(partitions.loc['train', 'cases'])
    p, ell = nested.design_rank_p, nested.training_log_likelihood
    close('2.4 / 3', 'Task 3 AIC identity', nested.AIC, -2*ell + 2*p)
    close('2.4 / 3', 'Task 3 BIC identity', nested.BIC, -2*ell + p*np.log(n))
    close('2.4 / 3', 'Task 3 AICc implementation', nested.AICc, nested.AIC + 2*p*(p+1)/(n-p-1))
    post = read('task2_4_outputs/hyperparameter_model_dfg_measures.csv')
    close('2.4 / 3', 'Task 2.4 BIC identity', post.BIC, -2*post.training_log_likelihood + post.design_rank_p*np.log(n))
    check('3', 'All feature counts present', list(nested.index) == list(range(1, len(config.features)+1)),
          f'k=1,...,{len(config.features)}; groups are not encoded columns')
    check('3', 'Nested training likelihood', np.all(np.diff(ell) >= -1e-4), 'Nondecreasing within numerical tolerance')
    baseline = read('task1_outputs/model_graph_summary.csv').set_index('model')
    baseline_entropy = read('task2_outputs/baseline_model_entropy.csv')
    cohorts = []
    for kind in ['logistic_regression', 'random_forest', 'neural_network']:
        events = read(f'task1_outputs/{kind}_feature_log.csv', dtype={'CaseID': str}, keep_default_na=False)
        groups = events[events.feature_group.ne('')]
        cohorts.append(set(events.CaseID))
        sizes = groups.groupby('CaseID').feature_group.agg(['size', 'nunique'])
        check('1', kind + ' trace integrity', (sizes['size'] == len(config.features)).all() and
              (sizes['nunique'] == len(config.features)).all(), f'{len(sizes)} cases; exactly one event per declared group')
        closed = root / f'task1_outputs/{kind}_restart_closed_dfg.graphml'
        inputs[str(closed.relative_to(root))] = hashlib.sha256(closed.read_bytes()).hexdigest()
        entropy = markov_entropy_measures(nx.read_graphml(closed))
        close('1 / 2', kind + ' saved KS', baseline.loc[kind, 'ks_entropy_bits_per_transition'], entropy['ks_entropy_bits_per_transition'])
        row = baseline_entropy[(baseline_entropy.model == kind) & (baseline_entropy.endpoint == 'ground_truth')].iloc[0]
        close('1 / 2', kind + ' baseline entropy agreement', row.ks_entropy_bits_per_transition, entropy['ks_entropy_bits_per_transition'])
    check('1', 'Aligned explanation cases across models', all(s == cohorts[0] for s in cohorts), f'{len(cohorts[0])} matched validation cases')
    validation_ids = set(membership.loc[membership.partition.eq('validation'), 'CaseID'])
    check('1', 'Explanation cohort is validation-only', cohorts[0].issubset(validation_ids), 'No training/test IDs in explanation cohort')
    for task,filename in [
        ('2.1','random_forest_depth_validation_entropy.csv'),
        ('2.2','logistic_regression_c_validation_entropy.csv'),
        ('2.3','neural_network_alpha_validation_entropy.csv'),
        ('2.3.1','neural_network_architecture_validation_entropy.csv'),
        ('2.3.2','early_stopping_validation_performance.csv'),
    ]:
        folder='task'+task.replace('.','_')+'_outputs'
        sweep=read(folder+'/'+filename)
        for row in sweep.itertuples():
            stem=_safe_name(row.setting).lower()
            relative=f'{folder}/{stem}_restart_closed_dfg.graphml'
            inputs[relative]=hashlib.sha256((root / relative).read_bytes()).hexdigest()
            entropy=markov_entropy_measures(nx.read_graphml(root / relative))
            close(task,row.setting+': saved KS',row.ks_entropy_bits_per_transition,entropy['ks_entropy_bits_per_transition'])
            events=read(f'{folder}/{stem}_feature_log.csv',dtype={'CaseID':str})
            check(task,row.setting+': validation-only explanation cases',set(events.CaseID).issubset(validation_ids),
                  f'{events.CaseID.nunique()} cases')
    for k, row in nested.iterrows():
        relative = f'task3_outputs/feature_count_{k:02d}_feature_only_restart_closed_dfg.graphml'
        graph = nx.read_graphml(root / relative)
        inputs[relative] = hashlib.sha256((root / relative).read_bytes()).hexdigest()
        weights = nx.to_numpy_array(graph, weight='weight')
        close('3', f'k={k}: closed-graph flow', weights.sum(axis=0), weights.sum(axis=1))
        entropy = markov_entropy_measures(graph)
        close('3', f'k={k}: KS rate', row.ks_entropy_bits_per_transition, entropy['ks_entropy_bits_per_transition'])
        close('3', f'k={k}: cycle information', row.entropy_bits_per_case_cycle, entropy['entropy_bits_per_case_cycle'])
    stability = read('task4_outputs/complexity_stability_summary.csv').set_index('feature_group_count')
    close('4', 'Reference entropy uses current Task 3', stability.reference_ks_entropy, nested.ks_entropy_bits_per_transition)
    for name in ['validation_accuracy', 'l1_similarity_to_reference_dfg', 'ks_entropy_bits_per_transition']:
        close('4', name + ': bootstrap SE is replicate SD', stability[name+'_se'], stability[name+'_sd'])
    subgroup = read('task5_outputs/all_task5_subgroup_dfg_comparisons.csv')
    check('5', 'Nine subgroup comparisons', len(subgroup) == 9 and not subgroup.duplicated(['model','task']).any(),
          'Three models by three ground-truth/correctness comparisons')
    close('5', 'L1 distance/similarity complement', subgroup.observed_l1_distance + subgroup.observed_l1_similarity, np.ones(len(subgroup)))
    for name in ['permutation_p_value', 'permutation_fdr_q_value']:
        check('5', name + ' range', subgroup[name].dropna().between(0,1).all(), 'Undefined tests remain missing, not zero')
    for kind in ['logistic_regression', 'random_forest', 'neural_network']:
        path = f'task5_5_feature_count_outputs/{kind}/nested_performance_and_dfg.csv'
        frame = read(path)
        last = frame.sort_values('feature_group_count').iloc[-1]
        for name in ['matches_task5_4_predictions_at_full_k', 'matches_task5_4_dfg_at_full_k']:
            check('5.5', kind + ': ' + name, str(last[name]).lower() == 'true', 'Full-feature nested fit agrees with baseline')
    methods = read('task6_outputs/task6_method_comparison_summary.csv')
    for row in methods.itertuples():
        close('6', row.method + ': accuracy', row.validation_accuracy, nested.loc[row.selected_feature_count, 'validation_accuracy'])
        close('6', row.method + ': AUC', row.validation_roc_auc, nested.loc[row.selected_feature_count, 'validation_roc_auc'])
    marginal = read('task6_3_1_outputs/marginal_likelihood_and_penalties.csv')
    close('6.3.1', 'Marginal analysis uses current likelihoods', marginal.training_deviance, -2*ell)
    metric_path = read('task6_3_1_outputs/probability_metric_one_se_analysis.csv')
    for metric in ['validation_log_loss', 'validation_roc_auc']:
        subset = metric_path[metric_path.metric.eq(metric)].set_index('feature_group_count').reindex(nested.index)
        close('6.3.1', metric + ' consistency', subset.observed_value, nested[metric])
    probabilities = read('task6_3_1_outputs/validation_case_probabilities.csv', dtype={'CaseID':str})
    expected_validation = membership.loc[membership.partition.eq('validation')].sort_values('partition_position')
    check('6.3.1', 'Probability export uses the current validation cases',
          probabilities.CaseID.tolist() == expected_validation.CaseID.tolist(),
          f'{len(probabilities)} rows, checked in partition order')
    close('6.3.1', 'Probability export outcomes', probabilities.ground_truth_accepted, expected_validation.outcome)
    for k,row in nested.iterrows():
        values = probabilities[f'accepted_probability_k_{k}'].to_numpy()
        scores = predictive_metrics(probabilities.ground_truth_accepted.to_numpy(), values)
        for metric in ['validation_accuracy','validation_roc_auc','validation_log_loss']:
            close('6.3.1', f'k={k}: exported probability {metric}', scores[metric], row[metric])
    fixed=read('task6_4_fixed_k_model_outputs/fixed_k_model_performance_and_dfg_complexity.csv')
    from multidataset_dfg_extensions import _relative_complexity
    reconstructed = _relative_complexity(fixed.copy(), 'relative_fixed_k_dfg_complexity')
    close('6.4', 'Relative complexity reconstructed from raw measures', fixed.relative_fixed_k_dfg_complexity_index,
          reconstructed.relative_fixed_k_dfg_complexity_index)
    check('6.4','Matched feature identities across models',fixed.selected_feature_groups.nunique()==1 and
          fixed.fixed_feature_group_count.nunique()==1,'The same selected groups are used by all three models')
    for row in fixed.itertuples():
        relative=f'task6_4_fixed_k_model_outputs/{row.model}_k{row.fixed_feature_group_count:02d}_closed_dfg.graphml'
        inputs[relative]=hashlib.sha256((root / relative).read_bytes()).hexdigest()
        entropy=markov_entropy_measures(nx.read_graphml(root / relative))
        close('6.4',row.model+': saved KS',row.ks_entropy_bits_per_transition,entropy['ks_entropy_bits_per_transition'])
        if 'task6_4_primary_complexity' in fixed.columns:
            primary_column = ('relative_fixed_k_dfg_complexity_index' if row.task6_4_primary_complexity_measure == 'relative_composite'
                              else row.task6_4_primary_complexity_measure)
            close('6.4',row.model+': declared primary complexity',row.task6_4_primary_complexity,getattr(row,primary_column))
        else:
            check('6.4',row.model+': legacy composite export matches protocol',config.task6_4_primary_complexity_measure=='relative_composite',
                  'Older composite-only export; not a pure-KS comparison')
    architecture=read('task6_5_nn_depth_width_outputs/nn_depth_width_accuracy_dfg_complexity.csv')
    seeds=read('task6_5_nn_depth_width_outputs/nn_depth_width_seed_dfg_diagnostics.csv')
    check('6.5','Three seeds per architecture',seeds.groupby('architecture_key').training_seed.nunique().eq(3).all(),
          'Canonical graph and across-seed summaries are distinct quantities')
    for row in architecture.itertuples():
        relative=f'task6_5_nn_depth_width_outputs/{row.architecture_key}_closed_dfg.graphml'
        inputs[relative]=hashlib.sha256((root / relative).read_bytes()).hexdigest()
        entropy=markov_entropy_measures(nx.read_graphml(root / relative))
        close('6.5',row.architecture_key+': canonical KS',row.ks_entropy_bits_per_transition,entropy['ks_entropy_bits_per_transition'])
        matches=seeds[seeds.architecture_key.eq(row.architecture_key)]
        close('6.5',row.architecture_key+': mean normalized KS across seeds',row.normalized_ks_entropy_across_seed_mean,
              matches.normalized_ks_entropy.mean())
    for folder, filename, entropy_col in [
        ('task7_pure_ks_bic_outputs', 'pure_ks_entropy_penalized_bic_results.csv', 'ks_entropy_bits_per_transition'),
        ('task7_1_entropy_effective_dfg_bic_outputs', 'entropy_effective_dfg_bic_results.csv', None),
    ]:
        scores = read(folder + '/' + filename).set_index('feature_group_count').reindex(nested.index)
        close('7 / 7.1', folder + ': BIC', scores.BIC, nested.BIC)
        if entropy_col:
            close('7', 'KS uses current Task 3 graphs', scores[entropy_col], nested[entropy_col])
    results = pd.DataFrame(checks)
    if write:
        output = root / 'quality_review_outputs'
        output.mkdir(exist_ok=True)
        results.to_csv(output / 'quality_checks.csv', index=False)
        (output / 'quality_check_provenance.json').write_text(json.dumps({
            'python': platform.python_version(), 'input_sha256': inputs,
            'scope': 'Saved-artifact consistency, not full-pipeline re-estimation or independent replication.',
        }, indent=2), encoding='utf-8')
    if show:
        display(Markdown('**Saved-result checks.** These verify consistency, not that a feature count or model is optimal.'))
        display(results.groupby(['task','status'], sort=False).size().rename('checks').reset_index())
        if results.status.eq('FAIL').any():
            display(results[results.status.eq('FAIL')])
    if strict and results.status.eq('FAIL').any():
        raise ValueError('Saved-result checks failed. See quality_review_outputs/quality_checks.csv before reporting.')
    return results
