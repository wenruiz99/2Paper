"""KS-only summaries and figures for the saved Task 6.5 NN experiments."""
import json
from pathlib import Path

import matplotlib.pyplot as plt
import networkx as nx
import numpy as np
import pandas as pd
from IPython.display import Image, Markdown, display

from bpi_task7_6_likelihood_ks import sha256
from multidataset_dfg_study import markov_entropy_measures

FOLDER = 'task6_5_nn_depth_width_outputs'
MEASURE = 'ks_entropy_bits_per_transition'
MEAN = 'ks_entropy_bits_across_seed_mean'
SD = 'ks_entropy_bits_across_seed_sd'
FILES = ('nn_depth_width_accuracy_dfg_complexity.csv', 'nn_depth_width_training_seed_results.csv',
         'nn_depth_width_seed_dfg_diagnostics.csv', 'paired_accuracy_bootstrap_replicates.csv')
NOTE = r'''

**DFG complexity is KS entropy only.** Use the first-order Markov entropy rate
of the feature-only restart-closed graph, in **bits per transition**:

$$
h(G)=-\sum_u\pi_u\sum_{v:P_{uv}>0}P_{uv}\log_2P_{uv}.
$$

The complexity heatmap and accuracy-versus-complexity plot use the arithmetic
mean of the three seed-specific diagnostic KS values. No normalization,
composite graph score, or graph-size penalty enters this measure. Error bars
or standard deviations across seeds describe seed variability, not a confidence
interval. The larger canonical-seed graph has its own separately reported KS;
it is not the graph underlying the three-seed mean.

Keep the existing one-SE **accuracy** allowance, then prefer the eligible
architecture with the lowest mean diagnostic KS. Break exact KS ties by fewer
trainable parameters, then depth and initial width. The combined standard error
belongs to accuracy uncertainty, not to a combined DFG-complexity score.
Parameter count is shown separately and is not added to KS. Low KS indicates
predictable routing, not necessarily fewer nodes or edges or better human
understanding. The saved fits and predictive metrics are reused unchanged;
no test results enter this comparison.

**Calculation and figures:** [KS-only Task 6.5 implementation](task6_5_ks_entropy.py).
'''
CODE = '''from pathlib import Path
from task6_5_ks_entropy import run_task6_5_from_exports

task6_5 = run_task6_5_from_exports(root=Path.cwd(), show=True)
'''


def summarize(canonical, seeds, diagnostic, bootstrap):
    canonical, diagnostic = canonical.copy(), diagnostic.copy()
    for frame in (canonical, diagnostic):
        frame.drop(columns=[c for c in frame if c.startswith(('relative_architecture_dfg_complexity',
                                                            'relative_seed_dfg_complexity'))], inplace=True)
    if diagnostic.duplicated(['architecture_key', 'training_seed']).any() or seeds.duplicated(['architecture_key', 'training_seed']).any():
        raise ValueError('Duplicate architecture/seed observations')
    keys = set(canonical.architecture_key)
    if len(keys) != 9 or set(seeds.architecture_key) != keys or set(diagnostic.architecture_key) != keys:
        raise ValueError('Expected nine matched architectures')
    if not all(g.training_seed.nunique() == 3 for _, g in diagnostic.groupby('architecture_key')):
        raise ValueError('Three diagnostic training seeds are required per architecture')
    if set(map(tuple, diagnostic[['architecture_key','training_seed']].to_numpy())) != set(map(tuple, seeds[['architecture_key','training_seed']].to_numpy())):
        raise ValueError('Performance and explanation seeds do not align')
    if not np.isfinite(diagnostic[MEASURE]).all() or diagnostic[MEASURE].lt(-1e-12).any():
        raise ValueError('KS must be finite and nonnegative')
    seed_summary = seeds.groupby('architecture_key').agg(
        accuracy_across_seed_mean=('validation_accuracy','mean'),
        accuracy_across_seed_sd=('validation_accuracy','std'),
        roc_auc_across_seed_mean=('validation_roc_auc','mean'),
        roc_auc_across_seed_sd=('validation_roc_auc','std'))
    ks = diagnostic.groupby('architecture_key')[MEASURE].agg(['mean','std']).rename(columns={'mean':MEAN,'std':SD})
    for column in seed_summary:
        np.testing.assert_allclose(canonical[column], canonical.architecture_key.map(seed_summary[column]), atol=1e-12, rtol=0)
    canonical[MEAN] = canonical.architecture_key.map(ks[MEAN])
    canonical[SD] = canonical.architecture_key.map(ks[SD])
    # Retain generic column names for existing consumers, now explicitly in bits.
    canonical['dfg_complexity_across_seed_mean'] = canonical[MEAN]
    canonical['dfg_complexity_across_seed_sd'] = canonical[SD]
    canonical['task6_5_complexity_measure'] = MEASURE
    best = canonical.loc[canonical.accuracy_across_seed_mean.idxmax()]
    values = bootstrap.loc[bootstrap.architecture_key.eq(best.architecture_key), 'mean_accuracy_across_training_seeds']
    if len(values) < 2 or not np.isfinite(values).all():
        raise ValueError('At least two saved case-bootstrap draws are required')
    case_se = float(values.std(ddof=1))
    seed_se = float(best.accuracy_across_seed_sd/np.sqrt(3))
    allowance = float(np.hypot(case_se, seed_se))
    threshold = float(best.accuracy_across_seed_mean-allowance)
    canonical['within_one_se_set'] = canonical.accuracy_across_seed_mean.ge(threshold-1e-15)
    eligible = canonical[canonical.within_one_se_set]
    chosen = eligible.sort_values([MEAN,'trainable_parameters','depth','initial_width'],kind='stable').iloc[0]
    canonical['selected_by_one_se_dfg_simplicity'] = canonical.architecture_key.eq(chosen.architecture_key)
    selection = pd.DataFrame([dict(
        fixed_feature_group_count=int(chosen.fixed_feature_group_count), best_accuracy_architecture=best.architecture_key,
        best_validation_accuracy_across_seed_mean=best.accuracy_across_seed_mean,
        best_case_bootstrap_standard_error=case_se,best_training_seed_mean_standard_error=seed_se,
        best_combined_standard_error=allowance,one_se_threshold=threshold,
        one_se_architectures=' | '.join(eligible.architecture_key),selected_architecture=chosen.architecture_key,
        selected_hidden_layer_sizes=chosen.hidden_layer_sizes,
        selected_validation_accuracy_across_seed_mean=chosen.accuracy_across_seed_mean,
        selected_ks_entropy_bits_across_seed_mean=chosen[MEAN],
        selected_dfg_complexity_across_seed_mean=chosen[MEAN],
        complexity_measure=MEASURE,complexity_unit='bits per transition',
        selection_rule='Minimum mean diagnostic KS (bits/transition) inside the existing one-SE accuracy set; ties: parameters, depth, width',
        test_cases_used=False)])
    return canonical, diagnostic, selection


def marginals(frame, column):
    return frame.groupby(column,as_index=False).agg(
        validation_accuracy_mean=('accuracy_across_seed_mean','mean'),
        ks_entropy_bits_mean=(MEAN,'mean'), dfg_complexity_mean=(MEAN,'mean'),
        trainable_parameters_mean=('trainable_parameters','mean'))


def figures(frame, out, title, show):
    depths, widths = sorted(frame.depth.unique()), sorted(frame.initial_width.unique())
    with plt.rc_context({'font.size':10,'axes.spines.top':False,'axes.spines.right':False}):
        fig, axes = plt.subplots(1,3,figsize=(15,4.8),layout='constrained')
        for ax, column, heading, cmap in zip(axes,
                ['accuracy_across_seed_mean',MEAN,'trainable_parameters'],
                ['Mean validation accuracy','Mean KS entropy (bits/transition)','Trainable parameters'],
                ['YlGn','YlOrRd','Blues']):
            values=frame.pivot(index='depth',columns='initial_width',values=column).loc[depths,widths]
            im=ax.imshow(values,cmap=cmap,aspect='auto')
            for (i,j),number in np.ndenumerate(values.to_numpy()):
                label=f'{number:.2%}' if column=='accuracy_across_seed_mean' else f'{number:.3f}' if column==MEAN else f'{int(number):,}'
                rgba=im.cmap(im.norm(number))
                luminance=.2126*rgba[0]+.7152*rgba[1]+.0722*rgba[2]
                ax.text(j,i,label,ha='center',va='center',color='black' if luminance>.55 else 'white',fontsize=9)
            ax.set(xticks=range(len(widths)),xticklabels=widths,yticks=range(len(depths)),yticklabels=depths,
                   xlabel='Initial layer width',ylabel='Hidden layers',title=heading)
            fig.colorbar(im,ax=ax,shrink=.75)
        fig.suptitle('Task 6.5: '+title)
        save(fig,out/'task6_5_depth_width_heatmaps.png',show)
        if show:
            display(Image(filename=str(out/'task6_5_depth_width_dfg_grid.png')))
        fig,axes=plt.subplots(1,2,figsize=(13,5.2),layout='constrained')
        scatter=axes[0].scatter(frame[MEAN],100*frame.accuracy_across_seed_mean,
                                c=frame.depth,cmap='viridis',s=65,vmin=1,vmax=3)
        fig.colorbar(scatter,ax=axes[0],label='Hidden layers',ticks=[1,2,3])
        chosen=frame[frame.selected_by_one_se_dfg_simplicity].iloc[0]
        axes[0].scatter([chosen[MEAN]],[100*chosen.accuracy_across_seed_mean],s=180,facecolors='none',
                        edgecolors='#b14e3c',linewidths=1.5,label='One-SE KS choice')
        axes[0].set(xlabel='Mean diagnostic KS entropy (bits per transition)',ylabel='Mean validation accuracy (%)')
        axes[0].margins(x=.18,y=.22)
        axes[0].legend(fontsize=8,loc='best')
        axes[1].errorbar(frame.trainable_parameters,100*frame.accuracy_across_seed_mean,
                          yerr=100*frame.accuracy_across_seed_sd,fmt='o',capsize=3,color='#28688f')
        axes[1].set(xscale='log',xlabel='Trainable parameters (log scale)',ylabel='Mean validation accuracy (%)',
                    title='Error bars: SD across three training seeds')
        for ax in axes:
            ax.grid(alpha=.2)
        fig.suptitle('Task 6.5: accuracy versus KS entropy and parameter count')
        place_labels(fig,axes[0],frame)
        save(fig,out/'task6_5_accuracy_complexity_tradeoffs.png',show)


def place_labels(fig,ax,frame):
    """Place the nine architecture labels without covering labels or other points."""
    fig.canvas.draw()
    occupied=[]
    points=[ax.transData.transform((row[MEAN],100*row.accuracy_across_seed_mean)) for _,row in frame.iterrows()]
    for row in frame.sort_values('accuracy_across_seed_mean',ascending=False).itertuples():
        point=(getattr(row,MEAN),100*row.accuracy_across_seed_mean)
        label=ax.annotate(row.architecture_key,point,xytext=(4,5),textcoords='offset points',fontsize=8,
                          arrowprops=dict(arrowstyle='-',color='#888888',linewidth=.5))
        placed=False
        renderer=fig.canvas.get_renderer()
        for dx,dy in [(4,5),(4,-15),(-63,5),(-63,-15),(4,20),(4,-30),(-63,20),(-63,-30),(4,35),(-63,35)]:
            label.set_position((dx,dy))
            label.update_positions(renderer)
            # The annotation's full extent includes the leader; inspect text only.
            box=plt.Text.get_window_extent(label,renderer).expanded(1.08,1.2)
            bounds=ax.get_window_extent(renderer)
            if (bounds.contains(box.x0,box.y0) and bounds.contains(box.x1,box.y1)
                    and not any(box.overlaps(other) for other in occupied)
                    and not any(box.contains(x,y) for x,y in points)):
                occupied.append(box)
                placed=True
                break
        if not placed:
            raise ValueError('Could not place architecture label without overlap: '+row.architecture_key)


def save(fig,path,show):
    fig.savefig(path,dpi=180,bbox_inches='tight',facecolor='white')
    plt.close(fig)
    if show:
        display(Image(filename=str(path)))


def run_task6_5_from_exports(root='.',show=True):
    root=Path(root).resolve()
    out=root/FOLDER
    frames={name:pd.read_csv(out/name) for name in FILES}
    baseline=frames[FILES[0]]
    seed_table=frames[FILES[2]]
    hashes={str((out/name).relative_to(root)):sha256(out/name) for name in FILES[1:]}
    for row in baseline.itertuples():
        for suffix in ('open_dfg.graphml','closed_dfg.graphml','feature_log.csv'):
            path=out/f'{row.architecture_key}_{suffix}'
            hashes[str(path.relative_to(root))]=sha256(path)
        entropy=markov_entropy_measures(nx.read_graphml(out/f'{row.architecture_key}_closed_dfg.graphml'))
        np.testing.assert_allclose(getattr(row,MEASURE),entropy[MEASURE],atol=1e-10,rtol=0)
    canonical,diagnostic,selection=summarize(baseline,frames[FILES[1]],seed_table,frames[FILES[3]])
    depth,width=marginals(canonical,'depth'),marginals(canonical,'initial_width')
    effects=[]
    for factor,column,table in [('More hidden layers','depth',depth),('More nodes per layer','initial_width',width)]:
        first,last=table.iloc[0],table.iloc[-1]
        effects.append(dict(factor=factor,low_setting=int(first[column]),high_setting=int(last[column]),
                            average_accuracy_at_low=first.validation_accuracy_mean,average_accuracy_at_high=last.validation_accuracy_mean,
                            accuracy_change_percentage_points=100*(last.validation_accuracy_mean-first.validation_accuracy_mean),
                            average_ks_entropy_bits_at_low=first.ks_entropy_bits_mean,
                            average_ks_entropy_bits_at_high=last.ks_entropy_bits_mean,
                            ks_entropy_bits_change_low_to_high=last.ks_entropy_bits_mean-first.ks_entropy_bits_mean))
    canonical.to_csv(out/FILES[0],index=False)
    diagnostic.to_csv(out/FILES[2],index=False)
    selection.to_csv(out/'architecture_selection_summary.csv',index=False)
    depth.to_csv(out/'depth_marginal_means.csv',index=False)
    width.to_csv(out/'width_marginal_means.csv',index=False)
    pd.DataFrame(effects).to_csv(out/'depth_vs_width_marginal_effects.csv',index=False)
    # Raw diagnostic KS values are retained; only composite columns are removed.
    np.testing.assert_array_equal(diagnostic[MEASURE],seed_table[MEASURE])
    hashes[str((out/FILES[2]).relative_to(root))]=sha256(out/FILES[2])
    config=pd.read_csv(root/'study_protocol_configuration.csv').iloc[0]
    figures(canonical,out,config.dataset_title,show)
    if any(sha256(root/name)!=digest for name,digest in hashes.items()):
        raise ValueError('Saved raw inputs changed during the KS-only refresh')
    protocol=dict(task='6.5',complexity_measure=MEASURE,unit='bits per transition',composite_score_used=False,
                  canonical_graph_cases=int(config.explanation_cases),diagnostic_graph_cases=int(config.sweep_explanation_cases),
                  training_seeds=sorted(map(int,diagnostic.training_seed.unique())),
                  refitted_models=False,test_cases_used=False,
                  selection='Minimum mean diagnostic KS inside unchanged one-SE accuracy set',
                  accuracy_se='Quadrature of paired case-bootstrap SE and training-seed mean SE; heuristic',
                  input_sha256=hashes,implementation_sha256={Path(__file__).name:sha256(Path(__file__))})
    (out/'ks_only_protocol.json').write_text(json.dumps(protocol,indent=2),encoding='utf-8')
    if show:
        chosen=selection.iloc[0]
        display(Markdown(f'**KS-only choice:** {chosen.selected_architecture}, layers `{chosen.selected_hidden_layer_sizes}`, '
                         f'mean KS **{chosen.selected_ks_entropy_bits_across_seed_mean:.4f} bits/transition**, '
                         f'mean validation accuracy **{chosen.selected_validation_accuracy_across_seed_mean:.2%}**.'))
        columns=['architecture_key','hidden_layer_sizes','trainable_parameters','accuracy_across_seed_mean',
                 'accuracy_across_seed_sd',MEAN,SD,MEASURE,'within_one_se_set','selected_by_one_se_dfg_simplicity']
        display(canonical[columns].round(6))
        display(selection.round(6))
    return canonical
