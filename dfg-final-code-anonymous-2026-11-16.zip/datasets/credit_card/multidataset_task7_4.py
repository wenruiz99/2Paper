"""Task 7.4 on existing nested-model artifacts, without model retraining."""
from __future__ import annotations

import hashlib
import json
import platform
from pathlib import Path

import numpy as np
import pandas as pd
from IPython.display import Markdown, display

from bpi_task7_2_explanation_coding import load_saved_candidates, code_components
from bpi_task7_4_fit_entropy import (
    OUTPUT_DIRECTORY, METRICS, LABELS, score_candidates, selection_summary,
    sensitivity, bootstrap_graphs, figures,
)


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def run_task7_4(root=".", bootstraps=500, seed=74027, show=True):
    """Reuse each dataset's Task 3 unpenalized LR fits and paired feature logs."""
    root = Path(root).resolve()
    candidates, features, cases, hashes = load_saved_candidates(
        root, expected_feature_count=None, expected_first_feature=None)
    partitions = pd.read_csv(root / "study_protocol_partitions.csv").set_index("partition")
    config = pd.read_csv(root / "study_protocol_configuration.csv").iloc[0]
    for name in ("study_protocol_partitions.csv", "study_protocol_configuration.csv"):
        hashes[name] = sha256(root / name)
    n, m = int(partitions.loc["train", "cases"]), len(cases)
    frame = pd.DataFrame([candidate["model"] for candidate in candidates])
    if not np.allclose(frame.AIC, 2 * frame.design_rank_p - 2 * frame.training_log_likelihood,
                       rtol=0, atol=1e-7):
        raise ValueError("Saved AIC does not equal 2k - 2 ln(L_hat).")
    for index, candidate in enumerate(candidates):
        metrics, _ = code_components(candidate["counts"], len(features))
        for name in ("ks_entropy_bits_per_transition", "complete_code_cost_bits"):
            frame.loc[index, name] = metrics[name]
    frame = score_candidates(frame, n, m)
    summary = selection_summary(frame)
    intervals, path, units = sensitivity(frame, n)
    draws, frequencies = bootstrap_graphs(candidates, frame, n, m, bootstraps, seed)
    totals = frequencies.groupby("method").selection_frequency.sum()
    if not np.allclose(totals, 1) or set(totals.index) != set(LABELS):
        raise AssertionError("Bootstrap selection frequencies must sum to one per criterion.")
    outputs = {
        "candidate_scores.csv": frame, "selection_comparison.csv": summary,
        "exact_multiplier_intervals.csv": intervals, "multiplier_selection_path.csv": path,
        "unit_and_scale_sensitivity.csv": units, "graph_bootstrap_selections.csv": draws,
        "graph_bootstrap_frequencies.csv": frequencies,
    }
    out = root / OUTPUT_DIRECTORY
    out.mkdir(exist_ok=True)
    for name, table in outputs.items():
        table.to_csv(out / name, index=False)
    figures(frame, summary, path, frequencies, None, out, show,
            feature_symbol="g", parameter_symbol="k")
    if any(sha256(root / name) != digest for name, digest in hashes.items()):
        raise AssertionError("Saved inputs changed during Task 7.4.")
    chosen = summary.set_index("method").loc["product"]
    findings = (
        f"{config.dataset_title}: BIC selects g={int(chosen.BIC_choice_k)}; "
        f"BIC + D h selects g={int(chosen.selected_k)}. "
        f"Relative to BIC, validation accuracy changes by "
        f"{chosen.accuracy_difference_percentage_points:+.4f} percentage points, "
        f"ROC AUC by {chosen.auc_difference:+.4f}, and log loss by "
        f"{chosen.log_loss_difference:+.4f}. These are descriptive tradeoffs, not "
        "independent confirmation of a better selection rule. No chronological refits "
        "or test predictions are used in this new section."
    )
    (out / "findings.txt").write_text(findings + "\n", encoding="utf-8")
    protocol = {
        "task": "7.4", "dataset": str(config.dataset_key),
        "AIC": "2k - 2 ln(L_hat)", "BIC": "k ln(n) - 2 ln(L_hat)",
        "primary_formula": "BIC + [-2 ln(L_hat)] * h", "entropy_unit": "bits per transition",
        "notation": "g = feature-group count; k = parameter count including intercept (design rank).",
        "legacy_csv_notation": "selected_k and BIC_choice_k refer to feature-group count g; design_rank_p means parameter count k.",
        "training_cases": n, "explanation_cases": m,
        "validation_cases": int(partitions.loc["validation", "cases"]),
        "candidate_feature_counts": list(range(1, len(features) + 1)),
        "feature_order": features, "split_mode": str(config.split_mode),
        "bootstraps": bootstraps, "seed": seed, "python": platform.python_version(),
        "input_sha256": hashes,
        "implementation_sha256": {name: sha256(Path(__file__).with_name(name)) for name in (
            "multidataset_task7_4.py", "bpi_task7_2_explanation_coding.py", "bpi_task7_4_fit_entropy.py",
            "multidataset_dfg_extensions.py")},
        "test_predictions_read": False, "models_retrained": False,
        "chronological_refits_included": False,
        "checks": ["AIC and BIC reproduce saved training likelihood and design rank",
                   "Every feature count has the same explanation cases and complete ranked features",
                   "Reconstructed transitions equal saved GraphML; KS equals Tasks 3 and 7",
                   "KS uses log2 and enters the primary product directly in bits",
                   "Bootstrap frequencies sum to one; source checksums unchanged"],
        "limits": [
            "Exploratory coefficient-one penalty, not a derived Bayesian information criterion.",
            "No independent policy evaluation; historical validation/test inspection is not undone.",
            "Paired graph-only bootstrap fixes fits, feature order, SHAP values and training likelihood.",
            "No full-pipeline or temporal-dependence uncertainty; no Task 7.3 chronological refits available.",
            "First-order feature-only restart-closed graphs, not outcome-terminal graphs.",
            "Coding comparators reconstructed from existing logs here; no claim of completing Tasks 7.2/7.3.",
            "Minimum score wins; exact numeric ties use smaller g. C-tuned Task 6.3.2 fits are not used.",
            "Count-only control matches the full-feature product penalty; it is not an independent complexity measure.",
        ],
    }
    (out / "analysis_protocol.json").write_text(json.dumps(protocol, indent=2) + "\n", encoding="utf-8")
    if show:
        display(Markdown("**Task 7.4 findings.** " + findings))
        tables = [
            ("Selected feature counts and validation performance", "selection_comparison.csv",
             summary[["criterion", "selected_k", *METRICS, "accuracy_difference_percentage_points",
                      "auc_difference", "log_loss_difference"]].rename(columns={"selected_k": "selected_g"}).round(6)),
            ("Score components", "candidate_scores.csv",
             frame[["feature_group_count", "BIC", "training_deviance", "parameter_penalty",
                    "ks_entropy_bits_per_transition", "product_penalty", "score_product"]].round(6)),
            ("Exact multiplier intervals", "exact_multiplier_intervals.csv", intervals),
            ("Entropy-unit and scale checks", "unit_and_scale_sensitivity.csv",
             units.rename(columns={"selected_k": "selected_g", "score_at_selected_k": "score_at_selected_g"}).round(6)),
            ("Graph-only bootstrap selection frequency", "graph_bootstrap_frequencies.csv",
             frequencies.pivot(index="criterion", columns="feature_group_count", values="selection_frequency").round(3)),
        ]
        for title, filename, table in tables:
            display(Markdown(f"**{title}.** [Download CSV]({OUTPUT_DIRECTORY}/{filename})"))
            display(table)
    return outputs


def notebook_markdown(dataset_title, groups):
    text = r'''<a id="task-7-4"></a>

### Task 7.4: Predictive Fit Times KS Entropy as an Additional BIC Penalty

**Question.** Does scaling KS entropy by the training fit term change the selected
number of feature groups, and what validation-performance tradeoff follows?

**Inputs.** For DATASET_TITLE, compare all GROUP_COUNT nested feature-group counts
from Task 3. Reuse the saved unpenalized Logistic Regression fits, training-derived
feature order, validation metrics, and the same 500 validation explanation cases.
This is not the separately C-tuned Task 6.3.2 analysis. No model retraining or
test-prediction evaluation is needed to run this cell.

**Notation and primary formula.** Let $g$ denote the number of original feature
groups; $k_g$ is the parameter count, including the intercept, calculated as the
design-matrix rank. They differ when a group expands into several encoded columns.
With $n$ training cases and fitted training likelihood $\widehat{L}_g$:

$$
\mathrm{AIC}_g=2k_g-2\ln(\widehat{L}_g),\qquad
\mathrm{BIC}_g=k_g\ln(n)-2\ln(\widehat{L}_g).
$$

$$
D_g=-2\ln(\widehat{L}_g),\qquad
J_g=\mathrm{BIC}_g+D_g h_g
=k_g\ln(n)-2\ln(\widehat{L}_g)
+[-2\ln(\widehat{L}_g)]h_g.
$$

Here $h_g$ is the empirical first-order KS entropy rate in **bits per transition**:

$$
P_{uv}=\frac{w(u,v)}{\sum_z w(u,z)},\qquad
h_g=-\sum_u\pi_u\sum_{v:P_{uv}>0}P_{uv}\log_2 P_{uv}.
$$

The feature-only graph closes each path as START, $g$ ranked features, END, START.
Every state occurs once per case, so $\pi_u=1/(g+2)$. These are the same graphs as
the Task 3 feature-count comparison, not graphs containing Accepted/Rejected
outcome states. The factor 2 keeps the fit term on BIC's deviance scale. Zero KS
leaves **all of BIC** intact; it does not remove the predictive-fit penalty.

**Comparison criteria.** Minimize each score separately, resolving exact ties
with the smaller $g$:

| Criterion | Additional term beyond BIC | Purpose |
| --- | --- | --- |
| BIC | $0$ | Predictive baseline |
| BIC + h | $h_g$ | Additive coefficient-one reference |
| BIC + D h | $D_g h_g$ | Primary product-penalty proposal |
| BIC + KS path cost | $2(\ln 2)m(g+2)h_g$ | Empirical path information for $m=500$ cases |
| BIC + complete code | $2L_{\mathrm{complete},g}$ | Conditional Markov coding comparator |
| BIC + count-only penalty | $D_Gh_G(g-1)/(G-1)$ | Control using only count, matched at full count $G$ |

The complete code uses independent Dirichlet$(1/2)$ transition-row priors on
fixed legal successors, including unseen legal edges. It adds a feature header
$\ln G+\ln\binom{G}{g}$; case identities, cohort size, and the feature universe are
shared side information. The code concerns ordered paths, so no multinomial
coefficient is included. These two coding comparators are reconstructed here
from existing feature logs; this does not imply Tasks 7.2 or 7.3 were run here.

**How to read the four figures.**
1. Components separate training deviance, parameter penalty, KS, and their product.
2. Six panels show each score minus its own minimum. Zero marks its preferred $g$;
   vertical scales differ, so score differences cannot be compared across criteria.
3. Validation accuracy, ROC AUC, and log loss show the consequences of BIC and
   product-penalty selection. Higher is better for accuracy/AUC; lower for log loss.
4. Multiplier sensitivity compares $D_gh_g$, $h_g$, and $(D_g/n)h_g$; the heatmap
   shows selection frequencies from 500 paired, graph-only bootstrap samples.

Each bootstrap resamples the same case indices across all graphs. Fits, feature
order, SHAP values, and training likelihood stay fixed. Frequencies therefore
measure sensitivity to this explanation sample, not the probability of choosing
the best predictor. Exact multiplier intervals and score-scale checks appear in tables.
The plotted grid stops at $10^3$; the interval table covers all nonnegative values.

**Interpretation limits.** The product is an exploratory preference, not a derived
Bayesian information criterion or an established improvement. It still chooses
an implicit entropy weight $D_g$, which depends on the model and training size.
KS uses bits directly with coefficient one. Dividing only the extra penalty by $n$ changes the
criterion; dividing the entire score by $n$ does not change its selection.
At $g=1$, the ranking graph is deterministic even if prediction is weak.
Lower KS measures simpler first-order routing, not predictive correctness or
demonstrated human interpretability. Historical inspection of validation/test
results prevents treating this as pristine confirmatory evaluation. Task 7.3
chronological refit artifacts are unavailable for this dataset, so no chronological
panel or full-pipeline stability claim is included.

**Reproducibility.** The cell checks saved AIC/BIC, feature-log/GraphML agreement,
KS agreement with Tasks 3 and 7, and input checksums. Outputs are written to
`task7_4_fit_entropy_outputs/`. Legacy CSV fields `selected_k` and `BIC_choice_k`
mean feature count $g$; `design_rank_p` means parameter count $k_g$.
'''
    return text.replace("DATASET_TITLE", dataset_title).replace("GROUP_COUNT", str(groups))


NOTEBOOK_CODE = '''from pathlib import Path
from multidataset_task7_4 import run_task7_4

# Reads saved Tasks 3 and 7 artifacts; earlier training cells need not be rerun.
task7_4 = run_task7_4(root=Path.cwd(), bootstraps=500, seed=74027, show=True)
'''
