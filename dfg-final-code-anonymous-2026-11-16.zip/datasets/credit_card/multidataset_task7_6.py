"""Training-only likelihood/KS calibration for Credit Card and LendingClub."""
from dataclasses import replace
import hashlib
import json
from pathlib import Path
import platform

import matplotlib.pyplot as plt
from matplotlib.ticker import MaxNLocator, PercentFormatter
import numpy as np
import pandas as pd
from IPython.display import Markdown, display
from sklearn.model_selection import StratifiedKFold

from notebook_quality import load_config, load_prepared_cases, source_filename
from bpi_task7_6_likelihood_ks import (
    calibrate, cached_fit, fit_path, objective, select_count, envelope, sha256,
    OUTPUT_DIRECTORY, METRICS,
)
from bpi_task7_2_explanation_coding import _save_figure


def load_partitions(root):
    config = load_config(root)
    if config.dataset_key not in {"default_credit_card_clients", "lendingclub"}:
        raise ValueError("Use the original BPI entry point for BPI 2017.")
    data = load_prepared_cases(root, config)
    membership = pd.read_csv(root / config.cohort_manifest, keep_default_na=False)
    if data.CaseID.duplicated().any() or membership.CaseID.duplicated().any() or set(data.CaseID) != set(membership.CaseID):
        raise ValueError("Canonical case membership is not unique and aligned.")
    data = data.set_index("CaseID", drop=False)
    if not np.array_equal(data.loc[membership.CaseID, config.target_column], membership.outcome.astype(int)):
        raise ValueError("Outcomes disagree with pinned membership.")
    sizes = pd.read_csv(root / "study_protocol_partitions.csv").set_index("partition")
    partitions = {}
    for role in ("train", "validation"):
        ids = membership[membership.partition.eq(role)].sort_values("partition_position").CaseID
        partitions[role] = data.loc[ids].reset_index(drop=True).copy()
        if len(ids) != int(sizes.loc[role, "cases"]):
            raise ValueError("Saved partition sizes disagree.")
    return partitions["train"], partitions["validation"], config


def make_splits(train, config, folds, seed):
    if folds < 3:
        raise ValueError("At least three folds are needed for fold-omission sensitivity.")
    if config.split_mode == "stratified":
        splitter = StratifiedKFold(n_splits=folds, shuffle=True, random_state=seed)
        return [(train.iloc[a].copy(), train.iloc[b].copy()) for a, b in splitter.split(train, train[config.target_column])]
    ordered = train.sort_values([config.time_column, config.case_id_column]).reset_index(drop=True)
    edges = np.linspace(len(ordered) // 2, len(ordered), folds + 1, dtype=int)
    starts = [ordered.iloc[i][config.time_column] for i in edges[:-1]]
    if len(set(starts)) != folds:
        raise ValueError("Too few distinct chronological boundaries.")
    result = []
    for index, start in enumerate(starts):
        after = ordered[config.time_column].ge(start)
        if index + 1 < len(starts):
            after &= ordered[config.time_column].lt(starts[index + 1])
        past, heldout = ordered[ordered[config.time_column].lt(start)].copy(), ordered[after].copy()
        if past.empty or heldout.empty or past[config.time_column].max() >= heldout[config.time_column].min():
            raise ValueError("Invalid chronological fold.")
        result.append((past, heldout))
    return result


def fit_candidates(train, assessment, config, directory, seed, fold):
    # The common fitting helper exports a time column. Credit Card has no time:
    # this explicitly named row index is metadata, never a feature or split key.
    if config.time_column is None:
        train, assessment = train.copy(), assessment.copy()
        train["non_temporal_row_index"] = np.arange(len(train))
        assessment["non_temporal_row_index"] = np.arange(len(assessment))
        config = replace(config, time_column="non_temporal_row_index")
    return fit_path(train, assessment, config, directory, seed, fold)


def plot_results(calibration, folds, final, choices, selected, out, show, title):
    n = int(final.training_cases.iloc[0])
    x = calibration.alpha.to_numpy() * n
    best, primary = n * choices["minimum_loss_alpha"], n * choices["one_se_alpha"]
    colors = ["#777777", "#28688f", "#288068"]
    with plt.rc_context({"font.size": 10, "axes.spines.top": False, "axes.spines.right": False}):
        fig, axes = plt.subplots(1, 2, figsize=(13, 5), constrained_layout=True)
        axes[0].errorbar(x, calibration.mean_log_loss, yerr=calibration.log_loss_se, fmt="o-", capsize=3, color=colors[0])
        axes[0].axhline(choices["one_se_threshold"], color="#b36732", linestyle=":", label="Minimum mean + its fold SE")
        axes[0].set(title="Inner validation log loss", ylabel="Mean log loss with fold SE")
        axes[1].plot(x, calibration.mean_ks_bits, "o-", color=colors[0])
        axes[1].set(title="KS of the selected inner-fold models", ylabel="Mean KS (bits/transition)")
        for ax in axes:
            for value, color, label, style in [(best, colors[1], "Minimum loss", "--"), (primary, colors[2], "One-SE KS", ":")]:
                ax.axvline(value, color=color, linestyle=style, label=f"{label}: lambda={value:.3g}")
            ax.set_xscale("symlog", linthresh=.01)
            ax.set_xlim(0, max(1, float(x.max()) * 1.4))
            ax.set_xlabel("Lambda on final-training-size scale")
            ax.legend(fontsize=8)
            ax.grid(alpha=.2)
        fig.suptitle(f"{title}: training-only calibration (fold SE is a heuristic)")
        _save_figure(fig, out / "lambda_calibration.png", show)

        fig, ax = plt.subplots(figsize=(11, 5), constrained_layout=True)
        paths = [(f"Inner fold {int(f)}", envelope(group)) for f, group in folds.groupby("fold")]
        paths.append(("Final training", envelope(final)))
        right = max(1, float(x.max()) * 1.4, max(float(env.alpha_lower.max()) * n * 1.2 for _, env in paths))
        for label, env in paths:
            ax.step(np.r_[env.alpha_lower * n, right], np.r_[env.selected_feature_group_count, env.selected_feature_group_count.iloc[-1]],
                    where="post", label=label, linewidth=2.5 if label == "Final training" else 1.2)
        ax.axvline(primary, color=colors[2], linestyle=":", label="One-SE weight")
        ax.set_xscale("symlog", linthresh=.01)
        ax.set(xlim=(0, right), xlabel="Lambda on final-training-size scale", ylabel="Selected feature groups (g)",
               title="Exact selection intervals; boundary ties choose the smaller g")
        ax.yaxis.set_major_locator(MaxNLocator(integer=True))
        ax.legend(ncols=2, fontsize=9)
        ax.grid(alpha=.2)
        _save_figure(fig, out / "feature_count_selection_path.png", show)

        fig, axes = plt.subplots(2, 2, figsize=(12, 8), constrained_layout=True)
        g = final.feature_group_count
        for ax, values, heading, ylabel in zip(axes.flat[:3], [-final.training_log_likelihood, final.ks_bits, primary * final.ks_bits],
                ["Training negative log likelihood", "Training explanation-graph KS", "Penalty at one-SE lambda"],
                ["-ln(fitted likelihood)", "Bits per transition", "lambda * KS"]):
            ax.plot(g, values, "o-", color=colors[1])
            ax.set(title=heading, ylabel=ylabel)
        for weight, label, color, style in [(0., "lambda=0", colors[0], "--"), (best, "Minimum-loss weight", colors[1], "-"),
                                           (primary, "One-SE KS weight", colors[2], ":")]:
            score = objective(final.training_log_likelihood, final.ks_bits, weight)
            axes[1, 1].plot(g, score - score.min(), "o", linestyle=style, label=label, color=color)
        axes[1, 1].set(title="Objective relative to its own minimum", ylabel="Score difference")
        axes[1, 1].legend(fontsize=8)
        for ax in axes.flat:
            ax.set_xlabel("Feature groups (g)")
            ax.xaxis.set_major_locator(MaxNLocator(integer=True))
            ax.grid(alpha=.2)
        fig.suptitle("No BIC, parameter-count penalty, or factor of two")
        _save_figure(fig, out / "objective_components.png", show)

        fig, axes = plt.subplots(1, 3, figsize=(14, 5), constrained_layout=True)
        selected_counts = set(selected.selected_g.astype(int)) | {1, int(g.max())}
        for ax, metric, heading in zip(axes, METRICS, ("Validation accuracy", "Validation ROC AUC", "Validation log loss")):
            ax.plot(final.ks_bits, final[f"validation_{metric}"], "o-", color=colors[0], markersize=4)
            for i, row in enumerate(final[final.feature_group_count.isin(selected_counts)].itertuples()):
                value = getattr(row, f"validation_{metric}")
                formatted = f"{value:.2%}" if metric == "accuracy" else f"{value:.4f}"
                offsets = [(8, 12), (-70, -25), (-25, 23), (14, -40)]
                ax.annotate(f"g={row.feature_group_count}: {formatted}", (row.ks_bits, value),
                            xytext=offsets[i % len(offsets)], textcoords="offset points", fontsize=8,
                            arrowprops={"arrowstyle": "-", "color": "#999999", "linewidth": .7})
            chosen = final[final.feature_group_count.eq(int(selected.iloc[-1].selected_g))].iloc[0]
            ax.scatter([chosen.ks_bits], [chosen[f"validation_{metric}"]], s=120, facecolors="none", edgecolors=colors[2],
                       linewidths=2, label=f"One-SE choice: g={int(chosen.feature_group_count)}")
            ax.set(title=heading, xlabel="Training-graph KS (bits/transition)")
            if metric == "accuracy":
                ax.yaxis.set_major_formatter(PercentFormatter(1, decimals=1))
            ax.margins(x=.3, y=.3)
            ax.set_xlim(-.02 * max(1, float(final.ks_bits.max())), max(1, float(final.ks_bits.max())) * 1.55)
            ax.legend(fontsize=8)
            ax.grid(alpha=.2)
        fig.suptitle("Outer validation after calibration; no pristine-holdout claim")
        _save_figure(fig, out / "validation_complexity_tradeoff.png", show)


def run_task7_6(root=".", show=True, seed=76031, inner_folds=4):
    root = Path(root).resolve()
    train, validation, config = load_partitions(root)
    out = root / OUTPUT_DIRECTORY
    out.mkdir(exist_ok=True)
    input_names = [source_filename(config), "study_protocol_configuration.csv", "study_protocol_partitions.csv",
                   "study_cohort_membership.csv", "study_cohort_contract.json"]
    hashes = {name: sha256(root / name) for name in input_names}
    dependencies = [Path(__file__).name, "notebook_quality.py", "bpi_task7_6_likelihood_ks.py", "bpi_task7_3_validation.py",
                    "bpi_task7_2_explanation_coding.py", "multidataset_dfg_study.py", "multidataset_dfg_extensions.py"]
    implementation = {name: sha256(root / name) for name in dependencies}
    key = {"version": "multidataset-training-only-likelihood-ks-v1", "seed": seed, "inner_folds": inner_folds,
           "input_sha256": hashes, "implementation_sha256": implementation}
    chronological = config.split_mode == "chronological"
    if chronological and train[config.time_column].max() >= validation[config.time_column].min():
        raise ValueError("Training dates overlap outer validation.")
    results, members, manifests, category_rows = [], [], [], []
    id_columns = [config.case_id_column] + ([config.time_column] if config.time_column else [])
    for fold, (past, heldout) in enumerate(make_splits(train, config, inner_folds, seed), 1):
        print(f"{config.dataset_title}, fold {fold}/{inner_folds}: {len(past)} training, {len(heldout)} validation", flush=True)
        directory = out / f"inner_fold_{fold}"
        results.append(cached_fit({**key, "fold": fold}, directory,
                       lambda: fit_candidates(past, heldout, config, directory, seed + fold, fold)))
        if set(past.CaseID) & set(heldout.CaseID) or not (set(past.CaseID) | set(heldout.CaseID)) <= set(train.CaseID):
            raise AssertionError("Inner fold leakage.")
        for role, data in [("train", past), ("inner_validation", heldout)]:
            part = data[id_columns].copy()
            part.insert(0, "role", role)
            part.insert(0, "fold", fold)
            members.append(part)
        row = {"fold": fold, "training_cases": len(past), "validation_cases": len(heldout),
               "training_accepted_rate": past[config.target_column].mean(), "validation_accepted_rate": heldout[config.target_column].mean(),
               "all_inner_cases_within_original_training": True, "outer_validation_cases_used": False, "test_cases_used": False}
        if chronological:
            row.update(training_end=past[config.time_column].max(), validation_start=heldout[config.time_column].min(),
                       validation_end=heldout[config.time_column].max())
        manifests.append(row)
        for feature in config.categorical_features:
            unknown = heldout[feature].notna() & ~heldout[feature].astype(str).isin(past[feature].dropna().astype(str))
            category_rows.append({"partition": f"inner_fold_{fold}", "feature_group": feature, "unseen_category_cases": int(unknown.sum())})
    folds = pd.concat(results, ignore_index=True)
    calibration, fold_choices, choices = calibrate(folds)
    n = len(train)
    for source, target in [("alpha", "lambda_final_scale"), ("alpha_lower", "lambda_lower_final_scale"), ("alpha_upper", "lambda_upper_final_scale")]:
        calibration[target] = calibration[source] * n
    lock = {**choices, "final_training_cases": n, "lambda_minimum_loss": n * choices["minimum_loss_alpha"],
            "lambda_one_se": n * choices["one_se_alpha"], "outer_validation_used_for_calibration": False,
            "calibration_data_sha256": hashlib.sha256(folds.to_csv(index=False).encode()).hexdigest()}
    (out / "lambda_selection_locked.json").write_text(json.dumps(lock, indent=2), encoding="utf-8")
    print(f"Weights locked: minimum={lock['lambda_minimum_loss']:.6g}; one-SE={lock['lambda_one_se']:.6g}", flush=True)
    directory = out / "final_training"
    final = cached_fit({**key, "fold": "final"}, directory,
                       lambda: fit_candidates(train, validation, config, directory, seed, 0))
    for feature in config.categorical_features:
        unknown = validation[feature].notna() & ~validation[feature].astype(str).isin(train[feature].dropna().astype(str))
        category_rows.append({"partition": "outer_validation", "feature_group": feature, "unseen_category_cases": int(unknown.sum())})
    selected_rows = []
    for rule, weight in [("No KS penalty", 0.), ("Unit KS weight", 1.), ("Minimum inner log loss", lock["lambda_minimum_loss"]),
                         ("One-SE KS preference", lock["lambda_one_se"])]:
        chosen = select_count(final, weight / n)
        selected_rows.append({"rule": rule, "lambda": weight, "alpha": weight / n, "selected_g": int(chosen.feature_group_count),
                              "included_feature_groups": chosen.included_feature_groups, "negative_log_likelihood": -chosen.training_log_likelihood,
                              "ks_bits": chosen.ks_bits, "ks_penalty": weight * chosen.ks_bits,
                              "objective": -chosen.training_log_likelihood + weight * chosen.ks_bits,
                              "open_dfg_nodes": chosen.open_dfg_nodes, "open_dfg_edges": chosen.open_dfg_edges,
                              **{f"validation_{m}": chosen[f"validation_{m}"] for m in METRICS}})
    selected = pd.DataFrame(selected_rows)
    sensitivity = []
    for fold in sorted(folds.fold.unique()):
        _, _, omitted = calibrate(folds[folds.fold.ne(fold)])
        sensitivity.append({"omitted_fold": int(fold), "one_se_alpha": omitted["one_se_alpha"],
                            "lambda_final_scale": n * omitted["one_se_alpha"],
                            "final_training_selected_g": int(select_count(final, omitted["one_se_alpha"]).feature_group_count)})
    final["score_one_se"] = objective(final.training_log_likelihood, final.ks_bits, lock["lambda_one_se"])
    final["score_minimum_loss"] = objective(final.training_log_likelihood, final.ks_bits, lock["lambda_minimum_loss"])
    intervals = envelope(final)
    intervals["lambda_lower"], intervals["lambda_upper"] = intervals.alpha_lower * n, intervals.alpha_upper * n
    outputs = {"inner_candidate_results.csv": folds, "inner_fold_manifest.csv": pd.DataFrame(manifests),
               "inner_fold_membership.csv": pd.concat(members, ignore_index=True), "lambda_calibration.csv": calibration,
               "calibration_fold_choices.csv": fold_choices, "final_candidate_results.csv": final,
               "selection_comparison.csv": selected, "leave_one_fold_out_sensitivity.csv": pd.DataFrame(sensitivity),
               "final_exact_lambda_intervals.csv": intervals, "assessment_category_audit.csv": pd.DataFrame(category_rows),
               "final_training_membership.csv": train[id_columns]}
    for name, frame in outputs.items():
        frame.to_csv(out / name, index=False)
    plot_results(calibration, folds, final, choices, selected, out, show, config.dataset_title)
    primary = selected.iloc[-1]
    interval = calibration[calibration.one_se_ks_choice].iloc[0]
    findings = (f"Minimum-inner-loss reference: lambda={lock['lambda_minimum_loss']:.6g}, g={int(selected.iloc[2].selected_g)}. "
                f"One-SE KS preference: representative lambda={primary['lambda']:.6g}, g={int(primary.selected_g)}; "
                f"its inner-fold policy is unchanged for final-size-equivalent lambda in ({interval.lambda_lower_final_scale:.6g}, "
                f"{interval.lambda_upper_final_scale:.6g}), apart from boundary ties. "
                f"One-SE outer-validation accuracy={primary.validation_accuracy:.3%}, ROC AUC={primary.validation_roc_auc:.4f}, "
                f"log loss={primary.validation_log_loss:.4f}. {int(calibration.within_one_se.sum())}/{len(calibration)} policies "
                "meet the one-SE allowance. The interval is informative; its representative is not a uniquely optimal lambda. "
                "One-SE is a simplicity preference, not evidence of equivalent predictive performance.")
    (out / "findings.txt").write_text(findings + "\n", encoding="utf-8")
    protocol = {"task": "7.6", "dataset": config.dataset_key, "criterion": "-ln(L_hat_g) + lambda * KS_g_bits_per_transition",
                "no_bic_or_parameter_penalty": True, "split_mode": config.split_mode, "inner_folds": inner_folds, "seed": seed,
                "calibration": "Expanding chronological folds" if chronological else "Shuffled stratified K-fold",
                "transfer": "alpha=lambda/n_train; lambda_fold=alpha*n_fold; lambda_final=alpha*n_final",
                "selection_rule": "Lowest inner mean KS among policies within best mean log loss plus its fold SE; ties by mean g, loss, alpha",
                "reference_rule": "Minimum equal-fold mean log loss; ties by mean KS, mean g, alpha",
                "interval_representative": "Midpoint for finite open intervals; twice positive lower bound for unbounded tail (1 if lower=0); zero explicit",
                "boundary_convention": "Positive exact crossings not separately calibrated; score ties select smaller g",
                "final_training_cases": n, "outer_validation_cases": len(validation), "test_cases_used": False,
                "outer_validation_used_to_tune_lambda": False, "input_sha256": hashes, "implementation_sha256": implementation,
                "python": platform.python_version(), "explanation_cases": int(config.explanation_cases),
                "feature_order": "Fold-specific full-model training mean absolute grouped SHAP; then unpenalized nested LR fits",
                "graph": "Training-only feature-ranking paths START, g features, END, START; no outcome states",
                "endpoint_note": config.endpoint_note,
                "limits": ["Fold SE is a heuristic with overlapping training sets, not a confidence interval or equivalence test",
                           "KS measures first-order routing uncertainty, not demonstrated human comprehension or graph size",
                           "Previous validation/test inspection remains; no pristine evaluation claim",
                           "No test predictions; source and membership contracts are verified using existing metadata",
                           "Graph sample and SHAP sampling uncertainty are not quantified",
                           "Training explanation graphs and newly learned feature orders differ from Task 7.4",
                           "LendingClub decision-observation timestamps are unavailable: application-date ordering is not verified label-availability purging"
                           if chronological else "Credit Card has no case timeline: stratified folds do not measure future temporal generalization"]}
    if any(sha256(root / name) != value for name, value in hashes.items()):
        raise AssertionError("Source data changed during calibration.")
    (out / "analysis_protocol.json").write_text(json.dumps(protocol, indent=2), encoding="utf-8")
    if show:
        display(Markdown("**Task 7.6 findings.** " + findings))
        table_names = ["selection_comparison.csv", "inner_fold_manifest.csv", "lambda_calibration.csv",
                       "final_candidate_results.csv", "leave_one_fold_out_sensitivity.csv"]
        for name in table_names:
            display(Markdown(f"**{name.replace('_', ' ').replace('.csv', '')}.** [CSV]({OUTPUT_DIRECTORY}/{name})"))
            frame = outputs[name].copy()
            if name == "final_candidate_results.csv":
                frame = frame[["feature_group_count", "included_feature_groups", "training_log_likelihood", "ks_bits",
                               "open_dfg_nodes", "open_dfg_edges", "score_one_se", "score_minimum_loss", *[f"validation_{m}" for m in METRICS]]]
            numeric = frame.select_dtypes(include="number").columns
            frame[numeric] = frame[numeric].round(6)
            with pd.option_context("display.max_rows", 150, "display.max_columns", 25):
                display(frame)
    print(findings, flush=True)
    return outputs


if __name__ == "__main__":
    run_task7_6(show=False)
