"""Portable Tasks 8--8.2 on verified Credit Card and LendingClub artifacts."""
import json
from dataclasses import replace
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from IPython.display import Markdown, display

from bpi_task7_2_explanation_coding import load_saved_candidates, code_components, _save_figure
from bpi_task7_3_validation import ExplicitSplitStudy, _fit_checked, counts_from_artifact, cycle_entropy, probability_metrics
from bpi_task7_6_likelihood_ks import sha256
from bpi_task8_ks_replacement import score_candidates, selection_summary, marginal_table
from bpi_task8_followups import (evaluate_rules, PROXIES, RULES81, RULES82,
                                 COLORS, METRICS, show_table)
from multidataset_task7_6 import load_partitions, make_splits
from multidataset_task7_7 import load_candidates, INPUT

OUT8 = 'task8_ks_replacement_outputs'
OUT81 = 'task8_1_robustness_outputs'
OUT82 = 'task8_2_graph_replacement_outputs'


def inputs(root):
    folds, final, _, hashes, protocol = load_candidates(root)
    train, validation, config = load_partitions(root)
    pairs = make_splits(train, config, protocol['inner_folds'], protocol['seed'])
    membership_path = root/INPUT/'inner_fold_membership.csv'
    final_path = root/INPUT/'final_training_membership.csv'
    members = pd.read_csv(membership_path)
    hashes.update({str(p.relative_to(root)): sha256(p) for p in (membership_path, final_path)})
    data = pd.concat([folds, final], ignore_index=True)
    data['bits_per_closed_case'] = data.ks_bits*(data.feature_group_count+2)
    audit = []
    for fold, past, future in [(i, a, b) for i, (a, b) in enumerate(pairs, 1)]+[(0, train, validation)]:
        directory = root/INPUT/(f'inner_fold_{fold}' if fold else 'final_training')
        prediction = pd.read_csv(directory/'assessment_probabilities.csv')
        probes = pd.read_csv(directory/'training_explanation_case_ids.csv').CaseID
        saved_train = (members.loc[members.fold.eq(fold) & members.role.eq('train'), 'CaseID']
                       if fold else pd.read_csv(final_path).CaseID)
        if (not saved_train.is_unique or set(saved_train) != set(past.CaseID)
                or not probes.is_unique or not set(probes) <= set(past.CaseID)
                or not prediction.CaseID.is_unique or set(prediction.CaseID) != set(future.CaseID)
                or set(past.CaseID) & set(future.CaseID)):
            raise ValueError(f'Invalid membership in fold {fold}')
        if fold and set(members.loc[members.fold.eq(fold) & members.role.eq('inner_validation'), 'CaseID']) != set(future.CaseID):
            raise ValueError('Changed assessment membership')
        chronological = config.split_mode == 'chronological'
        if chronological and past[config.time_column].max() >= future[config.time_column].min():
            raise ValueError('Chronological overlap')
        y = future.set_index('CaseID').loc[prediction.CaseID, config.target_column].to_numpy()
        np.testing.assert_array_equal(y, prediction[config.target_column])
        for row in data[data.fold.eq(fold)].itertuples():
            assert (row.training_cases, row.assessment_cases, row.explanation_cases) == (len(past), len(future), len(probes))
            metrics = probability_metrics(y, prediction[f'accepted_probability_g_{row.feature_group_count}'])
            np.testing.assert_allclose([metrics[m.removeprefix('validation_')][0] for m in METRICS],
                                       [getattr(row, m) for m in METRICS], rtol=0, atol=1e-10)
        audit.append(dict(fold=fold, training_cases=len(past), assessment_cases=len(future),
                          training_explanation_cases=len(probes), split_mode=config.split_mode,
                          training_end=past[config.time_column].max() if chronological else None,
                          assessment_start=future[config.time_column].min() if chronological else None,
                          label_availability_purged=False))
    return data, pd.DataFrame(audit), hashes, (train, validation, config, protocol['seed'])


def save(root, out, exports, hashes, task, config, **details):
    if any(sha256(root/name) != digest for name, digest in hashes.items()):
        raise ValueError('Earlier artifacts changed during analysis')
    out.mkdir(exist_ok=True)
    for name, frame in exports.items():
        frame.to_csv(out/(name+'.csv'), index=False)
    names = [Path(__file__).name, 'bpi_task8_followups.py', 'bpi_task8_ks_replacement.py',
             'bpi_task7_2_explanation_coding.py', 'multidataset_task7_7.py']
    protocol = dict(task=task, dataset=config.dataset_key, split_mode=config.split_mode,
                    entropy_unit='bits per transition (log2)', test_cases_used=False, coefficient_tuned=False,
                    input_sha256=hashes, implementation_sha256={n:sha256(root/n) for n in names},
                    limits=['Prior validation/test inspection remains; no pristine evaluation claim',
                            'Entropy replacement is exploratory, not derived BIC',
                            'Graph resampling holds fits fixed; not full-pipeline uncertainty',
                            'Application-date chronology is not verified label-availability purging'
                            if config.split_mode == 'chronological' else 'Stratified folds do not measure temporal generalization'],
                    **details)
    (out/'analysis_protocol.json').write_text(json.dumps(protocol, indent=2), encoding='utf-8')


def run_task8(root='.', show=True):
    root = Path(root).resolve()
    data, audit, hashes, (train, _, config, _) = inputs(root)
    candidates, features, cases, saved_hashes = load_saved_candidates(root, None, None)
    hashes.update(saved_hashes)
    rows = []
    for c in candidates:
        model = c['model']
        h = code_components(c['counts'], len(features))[0]['ks_entropy_bits_per_transition']
        rows.append(dict(feature_group_count=c['k'], training_cases=len(train),
                         parameter_count_k=model['design_rank_p'], ks_bits=h,
                         training_log_likelihood=model['training_log_likelihood'],
                         included_feature_groups=model['included_feature_groups'], explanation_cases=len(cases),
                         open_dfg_nodes=model['open_dfg_nodes'], open_dfg_edges=model['open_dfg_edges'],
                         **{m:model[m] for m in METRICS}))
    original = score_candidates(pd.DataFrame(rows))
    training = score_candidates(data[data.fold.eq(0)])
    frames = {'original':original, 'training_graph':training}
    scores = pd.concat([f.assign(source=s) for s,f in frames.items()], ignore_index=True)
    choices = pd.concat([selection_summary(f,s) for s,f in frames.items()], ignore_index=True)
    marginal = pd.concat([marginal_table(f,s) for s,f in frames.items()], ignore_index=True)
    exports = dict(candidate_scores=scores, selection_comparison=choices, marginal_fit_and_penalty=marginal)
    out = root/OUT8
    save(root,out,exports,hashes,'8',config, formula='-2 ln(L_hat) + KS_bits ln(n)',
         graph_sources={'original':'Legacy validation explanations; not training-only',
                        'training_graph':'Training-only feature order and explanations from Task 7.6'})
    fig, axes = plt.subplots(2,2,figsize=(12,8),layout='constrained')
    for i,(source,frame) in enumerate(frames.items()):
        for criterion,label,color in [('BIC','BIC',COLORS['BIC']),('KS_replacement_bits','KS replacement',COLORS['KS'])]:
            axes[i,0].plot(frame.feature_group_count, frame['delta_'+criterion], 'o-', label=label,color=color,markersize=3)
        axes[i,0].set(title='Legacy validation graphs' if i == 0 else 'Training-only graphs',
                      ylabel='Score minus its own minimum', yscale='symlog', xlabel='Feature groups (g)')
        axes[i,0].legend()
        axes[i,1].plot(frame.feature_group_count,frame.bic_parameter_penalty,'s-',label='Parameter penalty',markersize=3)
        axes[i,1].plot(frame.feature_group_count,frame.ks_penalty_bits,'o-',label='KS penalty',markersize=3)
        axes[i,1].set(xlabel='Feature groups (g)',ylabel='Penalty',title='Same likelihood; different penalties')
        axes[i,1].legend()
    fig.suptitle(config.dataset_title+' - Task 8')
    _save_figure(fig,out/'criterion_comparison.png',show)
    if show:
        show_table('Selections (legacy and training-graph cohorts kept separate)',choices,
                   ['source','label','selected_g','parameter_count_k','ks_bits','open_dfg_edges','runner_up_gap',*METRICS])
    return exports


def precision_check(root,train,assessment,config):
    saved,order,cases,hashes = load_saved_candidates(root,None,None)
    study = ExplicitSplitStudy(train,assessment,config)
    rows,paths = [],{}
    for tolerance in (1e-4,1e-10):
        paths[tolerance] = []
        for c in saved:
            g = c['k']
            fit,_ = _fit_checked(study,order[:g],tolerance=tolerance)
            log = fit['feature_log'].copy()
            log['CaseID'] = log.CaseID.astype(str)
            counts = counts_from_artifact({'feature_log':log},order[:g],cases)
            paths[tolerance].append(counts)
            if tolerance == 1e-4:
                np.testing.assert_allclose(fit['BIC'],c['model']['BIC'],atol=1e-6,rtol=0)
                np.testing.assert_array_equal(counts,c['case_counts'])
            d = -2*fit['training_log_likelihood']
            h = cycle_entropy(counts.sum(axis=0))/(g+2)
            rows.append(dict(tolerance=tolerance,feature_group_count=g,training_deviance=d,ks_bits=h,
                             ks_penalty=h*np.log(len(train)),score=d+h*np.log(len(train)),
                             changed_rankings=np.any(counts!=c['case_counts'],axis=(1,2)).sum()))
    table = pd.DataFrame(rows)
    table['delta_score'] = table.score-table.groupby('tolerance').score.transform('min')
    penalty = table[table.tolerance.eq(1e-4)].set_index('feature_group_count').ks_penalty
    table['score_with_original_graph'] = table.training_deviance+table.feature_group_count.map(penalty)
    return table,paths[1e-10],hashes


def draws(counts,deviance,n,size,repeats,replacement,rng,pair):
    if len(counts)<2 or len(counts)!=len(deviance) or len({len(c) for c in counts})!=1 or repeats<1:
        raise ValueError('Aligned candidate paths and positive draw count required')
    rows=[]
    a,b=pair
    for i in range(repeats):
        draw=rng.choice(len(counts[0]),size=size,replace=replacement)
        h=np.array([cycle_entropy(c[draw].sum(axis=0))/c.shape[1] for c in counts])
        scores=deviance+h*np.log(n)
        rows.append(dict(draw=i+1,explanation_cases=size,selected_g=int(np.argmin(scores))+1,
                         reference_g=a,alternative_g=b,score_alternative_minus_reference=scores[b-1]-scores[a-1]))
    return pd.DataFrame(rows)


def expanded_pool(root,train,config,seed,final):
    """Never combine a reconstructed graph with a different fit's likelihood."""
    study=ExplicitSplitStudy(train,train,replace(config,random_state=seed))
    directory=root/INPUT/'final_training'
    order=pd.read_csv(directory/'feature_order.csv').feature_group.tolist()
    pool=np.random.default_rng(81001).choice(len(train),size=2000,replace=False)
    ids=study.train_data.iloc[pool].CaseID.to_numpy()
    arrays,diagnostics=[],[]
    for row in final.itertuples():
        g=row.feature_group_count
        fit,_=_fit_checked(study,order[:g],tolerance=1e-8)
        saved_log=pd.read_csv(directory/f'feature_count_{g:02d}_training_feature_log.csv',keep_default_na=False)
        baseline=counts_from_artifact(fit,order[:g],study.probe_case_ids)
        saved_counts=counts_from_artifact({'feature_log':saved_log},order[:g],study.probe_case_ids)
        diagnostics.append(dict(feature_group_count=g,training_log_likelihood=fit['training_log_likelihood'],
                                saved_training_log_likelihood=row.training_log_likelihood,
                                log_likelihood_difference=fit['training_log_likelihood']-row.training_log_likelihood,
                                saved_ks_bits=row.ks_bits,
                                reconstructed_ks_bits=cycle_entropy(baseline.sum(axis=0))/(g+2),
                                changed_rankings=np.any(baseline!=saved_counts,axis=(1,2)).sum()))
        shap=study._linear_grouped_shap(fit['model'],fit['indices'],study.X_train[pool],study.X_train[study.background_indices])
        log,*_=study._feature_log_and_traces(ids,study.y_train[pool],shap,included_features=order[:g])
        arrays.append(counts_from_artifact({'feature_log':log},order[:g],ids))
    return arrays,ids,pd.DataFrame(diagnostics)


def run_task8_1(root='.',show=True,repeats=400):
    root=Path(root).resolve()
    data,audit,hashes,(train,assessment,config,seed)=inputs(root)
    scores,selected=evaluate_rules(data)
    precision,legacy_counts,more=precision_check(root,train,assessment,config)
    hashes.update(more)
    old=precision[precision.tolerance.eq(1e-4)].sort_values(['score','feature_group_count'])
    pair=tuple(old.feature_group_count.iloc[:2].astype(int))
    tight=precision[precision.tolerance.eq(1e-10)]
    final=data[data.fold.eq(0)].sort_values('feature_group_count')
    arrays,ids,reconstruction=expanded_pool(root,train,config,seed,final)
    rng=np.random.default_rng(81002)
    samples=pd.concat([draws(arrays,-2*reconstruction.training_log_likelihood.to_numpy(),len(train),m,
                            repeats if m<len(ids) else 1,False,rng,pair)
                       for m in (100,250,500,1000,len(ids))],ignore_index=True)
    bootstrap=draws(legacy_counts,tight.training_deviance.to_numpy(),len(train),len(legacy_counts[0]),repeats,True,rng,pair)
    freq=samples.groupby(['explanation_cases','selected_g']).size().rename('draws_selecting_g').reset_index()
    freq['fraction']=freq.draws_selecting_g/freq.groupby('explanation_cases').draws_selecting_g.transform('sum')
    exports=dict(candidate_scores=scores,period_selections=selected,cohort_audit=audit,legacy_precision=precision,
                 legacy_paired_bootstrap=bootstrap,explanation_size_draws=samples,explanation_size_frequencies=freq,
                 explanation_pool_cases=pd.DataFrame({'CaseID':ids}),sample_pool_refit_audit=reconstruction)
    out=root/OUT81
    save(root,out,exports,hashes,'8.1',config,formula='-2 ln(L_hat) + KS_bits ln(n)',repeats=repeats,
         bootstrap_contrast='Original score runner-up minus original score winner; pair fixed before resampling',
         solver_tolerances=[1e-4,1e-10],seeds=[81001,81002],
         sample_pool='New same-cohort refits at 1e-8; likelihood and graphs from these same fits. Differences from saved candidates exported.')
    periods=sorted(selected.fold.unique(),key=lambda f:f or 99)
    fig,axes=plt.subplots(1,3,figsize=(14,4.5),layout='constrained')
    for rule,label in RULES81.items():
        part=selected[selected.rule.eq(rule)].set_index('fold').loc[periods]
        for ax,metric in zip(axes,['feature_group_count','validation_log_loss','edge_count']):
            ax.plot(range(len(periods)),part[metric],'o-',label=label,color=COLORS[rule])
    for ax,title in zip(axes,['Selected feature groups','Held-out log loss','Training DFG edges']):
        ax.set(title=title,xticks=range(len(periods)),xticklabels=['Final validation' if f==0 else f'Fold {f}' for f in periods])
        ax.tick_params(axis='x',rotation=25)
        ax.grid(alpha=.2)
    axes[0].legend(fontsize=8)
    fig.suptitle(config.dataset_title+' - '+config.split_mode+' assessment')
    _save_figure(fig,out/'fold_comparison.png',show)
    fig,axes=plt.subplots(1,2,figsize=(12,4.5),layout='constrained')
    freq.pivot(index='explanation_cases',columns='selected_g',values='fraction').fillna(0).plot.bar(stacked=True,ax=axes[0],rot=0,colormap='cividis')
    axes[0].set(title='Training-only graph sample sensitivity',ylabel='Fraction of draws',xlabel='Explanation cases')
    axes[0].legend(title='Selected g')
    axes[1].hist(bootstrap.score_alternative_minus_reference,bins=25,color=COLORS['BIC'])
    axes[1].axvline(0,color='#aa4c32',linestyle='--')
    for tol,part in precision.groupby('tolerance'):
        values=part.set_index('feature_group_count').score
        axes[1].axvline(values[pair[1]]-values[pair[0]],label=f'Tolerance {tol:g}',linestyle=':' if tol==1e-4 else '-')
    axes[1].set(title='Legacy paired case bootstrap, tighter fits',xlabel=f'Score(g={pair[1]}) minus score(g={pair[0]})',ylabel='Resamples')
    axes[1].legend(fontsize=8)
    _save_figure(fig,out/'score_stability.png',show)
    if show:
        old_g=int(old.iloc[0].feature_group_count)
        new_g=int(tight.sort_values(['score','feature_group_count']).iloc[0].feature_group_count)
        choices=selected[selected.fold.eq(0)].set_index('rule').feature_group_count
        display(Markdown(f'**Findings.** Training-only BIC selects **{choices["BIC"]}**, KS replacement **{choices["KS"]}** groups. '
                         f'On the legacy cohort, the solver audit changes the minimum from **{old_g} to {new_g}** groups. '
                         f'The tighter-fit winner is selected in **{bootstrap.selected_g.eq(new_g).mean():.1%}** of paired graph-bootstrap draws.'))
        show_table('Matched fold and final-validation choices',selected,['fold','rule','feature_group_count','edge_count','ks_bits','bits_per_closed_case',*METRICS])
        show_table('Legacy solver audit',precision,list(precision.columns))
        show_table('Expanded-pool refit audit (separate from saved main comparison)',reconstruction,list(reconstruction.columns))
    return exports


def run_task8_2(root='.',show=True):
    root=Path(root).resolve()
    data,audit,hashes,(_,_,config,_)=inputs(root)
    scores,selected=evaluate_rules(data,PROXIES)
    baseline=selected[selected.rule.eq('BIC')].set_index('fold')
    for metric in [*METRICS,'edge_count','ks_bits']:
        selected[metric+'_minus_BIC']=selected[metric]-selected.fold.map(baseline[metric])
    final=selected[selected.fold.eq(0)]
    means=selected[selected.fold.ne(0)].groupby('rule',sort=False)[['feature_group_count',*METRICS,'ks_bits','edge_count']].mean().reset_index()
    spans=scores[scores.fold.eq(0)].groupby('rule').penalty.agg(['min','max']).assign(penalty_span=lambda t:t['max']-t['min']).reset_index()
    exports=dict(candidate_scores=scores,period_selections=selected,final_comparison=final,
                 fold_mean_comparison=means,final_penalty_ranges=spans,cohort_audit=audit)
    out=root/OUT82
    save(root,out,exports,hashes,'8.2',config,formula='-2 ln(L_hat) + raw_graph_measure ln(n)',rescaled=False,
         measures=PROXIES,similarity_role='L1 distance to full DFG is a fidelity control, not simplicity')
    rules=list(RULES82)
    periods=sorted(selected.fold.unique(),key=lambda f:f or 99)
    table=selected.pivot(index='rule',columns='fold',values='feature_group_count').loc[rules,periods]
    maximum=int(data.feature_group_count.max())
    fig,axes=plt.subplots(1,2,figsize=(13,6.2),layout='constrained')
    axes[0].imshow(table.to_numpy(),aspect='auto',cmap='cividis',vmin=1,vmax=maximum)
    for (i,j),g in np.ndenumerate(table.to_numpy()):
        axes[0].text(j,i,f'{g:g}',ha='center',va='center',color='white' if g<(maximum+1)/2 else 'black')
    axes[0].set(title='Selected feature groups',yticks=range(len(rules)),yticklabels=[RULES82[r] for r in rules],
                xticks=range(len(periods)),xticklabels=['Final validation' if f==0 else f'Fold {f}' for f in periods])
    axes[0].tick_params(axis='x',rotation=25)
    span=spans.set_index('rule').loc[[r for r in rules if r!='Full']]
    axes[1].barh([RULES82[r] for r in span.index],span.penalty_span,color=COLORS['KS'])
    axes[1].invert_yaxis()
    axes[1].set(xscale='symlog',title='Raw penalty scale, final training',xlabel='Penalty range (symlog)')
    _save_figure(fig,out/'selection_and_penalty_scale.png',show)
    fig,axes=plt.subplots(1,3,figsize=(14,6),layout='constrained',sharey=True)
    ordered=final.set_index('rule').loc[rules]
    for ax,metric,title in zip(axes,METRICS,['Accuracy','ROC AUC','Log loss']):
        ax.barh([RULES82[r] for r in rules],ordered[metric+'_minus_BIC']*(100 if metric==METRICS[0] else 1),color='#7b888b')
        ax.axvline(0,color='#333333',linewidth=.8)
        ax.set(title=title,xlabel='Difference from BIC'+(' (percentage points)' if metric==METRICS[0] else ''))
        ax.grid(axis='x',alpha=.2)
    axes[0].invert_yaxis()
    _save_figure(fig,out/'validation_differences.png',show)
    if show:
        show_table('Final training selections, then validation assessment',final,['rule','feature_group_count','replacement_value','penalty','edge_count','ks_bits',*METRICS])
        show_table('Equal-fold mean assessment (not independent replications)',means,list(means.columns))
        show_table('Raw penalty ranges',spans,list(spans.columns))
    return exports


def write_manifest(root):
    from types import SimpleNamespace
    from multidataset_task7_7 import write_task77_manifest
    frame=write_task77_manifest(SimpleNamespace(root=root),show=False)
    rows=[dict(task=task,output_directory=folder,primary_file=file,available=(root/folder/file).exists())
          for task,folder,file in [('Task 8',OUT8,'selection_comparison.csv'),('Task 8.1',OUT81,'period_selections.csv'),('Task 8.2',OUT82,'final_comparison.csv')]]
    position=next((i for i,task in enumerate(frame.task) if task=='Final test report'),len(frame))
    frame=pd.concat([frame.iloc[:position],pd.DataFrame(rows),frame.iloc[position:]],ignore_index=True)
    frame.to_csv(root/'tasks_1_to_8_output_manifest.csv',index=False)
    return frame
