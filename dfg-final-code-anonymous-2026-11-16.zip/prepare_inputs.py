"""Recreate pinned split metadata from the exact externally supplied study CSV."""
import argparse
from dataclasses import replace
import hashlib
import json
from pathlib import Path
import shutil
import sys

ROOT=Path(__file__).resolve().parent
DATASETS={'bpi2017':'bpi2017-with-credit-score.ipynb',
          'credit_card':'CreditCard-tasks1-7.ipynb','lendingclub':'LendingClub-tasks1-7.ipynb'}


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--dataset',choices=DATASETS,required=True)
    parser.add_argument('--input',type=Path,required=True,help='Exact prepared study CSV; see DATA_REQUIREMENTS.md')
    parser.add_argument('--output-dir',type=Path,help='Optional fresh work folder instead of the packaged dataset folder')
    args=parser.parse_args()
    source_root=ROOT/'datasets'/args.dataset
    source=args.input.resolve()
    expected=json.loads((source_root/'expected_cohort.json').read_text())
    if digest(source)!=expected['source_sha256']:
        raise ValueError('Input differs from the published study input hash. Raw downloads may need preparation; see DATA_REQUIREMENTS.md. No replacement cohort will be silently created.')
    root=args.output_dir.resolve() if args.output_dir else source_root
    if args.output_dir:
        root.mkdir(parents=True,exist_ok=False)
        for file in source_root.iterdir():
            if file.is_file():
                shutil.copy2(file,root/file.name)
    target=root/expected['source_file']
    if source!=target:
        shutil.copyfile(source,target)
    sys.path.insert(0,str(root))
    import numpy as np
    import pandas as pd
    from sklearn.model_selection import train_test_split
    from multidataset_dfg_study import StudyConfig,DFGStudy
    from notebook_quality import load_prepared_cases
    config=StudyConfig(**json.loads((root/'configuration.json').read_text()))
    data=load_prepared_cases(root,config,verify_contract=False)
    excluded=data.iloc[0:0].copy()
    if args.dataset=='bpi2017':
        raw=pd.read_csv(target)
        historical=pd.to_datetime(raw[config.time_column],format='%Y-%m-%d %H:%M:%S.%f%z',errors='coerce',utc=True)
        excluded=data.loc[historical.isna()].copy()
        included=data.loc[historical.notna()].reset_index(drop=True)
    else:
        included=data.copy()
    if config.split_mode=='chronological':
        ordered=included.sort_values([config.time_column,config.case_id_column]).reset_index(drop=True)
        first=ordered.iloc[int(.6*len(ordered))][config.time_column]
        second=ordered.iloc[int(.8*len(ordered))][config.time_column]
        frames=[ordered[ordered[config.time_column]<first],
                ordered[(ordered[config.time_column]>=first)&(ordered[config.time_column]<second)],
                ordered[ordered[config.time_column]>=second]]
    else:
        train,rest=train_test_split(included,test_size=.4,random_state=config.random_state,stratify=included[config.target_column])
        val,test=train_test_split(rest,test_size=.5,random_state=config.random_state+1,stratify=rest[config.target_column])
        frames=[train,val,test]
    pieces=[]
    for name,frame in zip(['train','validation','test'],frames):
        pieces.append(pd.DataFrame({'CaseID':frame[config.case_id_column].astype(str).to_numpy(),
                                    'partition':name,'partition_position':np.arange(len(frame)),
                                    'outcome':frame[config.target_column].to_numpy(),'reason':''}))
    if len(excluded):
        pieces.append(pd.DataFrame({'CaseID':excluded.CaseID.to_numpy(),'partition':'excluded',
                                    'partition_position':-1,'outcome':excluded[config.target_column].to_numpy(),
                                    'reason':'Legacy fractional-second parser exclusion; retained for comparability'}))
    membership=pd.concat(pieces,ignore_index=True)
    path=root/'study_cohort_membership.csv'
    membership.to_csv(path,index=False)
    if digest(path)!=expected['membership_sha256']:
        raise ValueError('Regenerated split differs from the reference membership hash; check Python/package versions before running models.')
    (root/'study_cohort_contract.json').write_text(json.dumps(expected,indent=2),encoding='utf-8')
    DFGStudy(data,replace(config,cohort_manifest='study_cohort_membership.csv'),root=root)
    print('Verified input and regenerated exact study membership:',root)


if __name__=='__main__':
    main()
