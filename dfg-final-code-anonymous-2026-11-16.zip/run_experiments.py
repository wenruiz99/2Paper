"""Execute final study notebooks after external input preparation."""
import argparse
import copy
from pathlib import Path

from prepare_inputs import ROOT,DATASETS


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--dataset',choices=[*DATASETS,'all'],default='all')
    parser.add_argument('--kernel',default='dfg-reproduction')
    parser.add_argument('--timeout',type=int,default=28800,help='Seconds per cell')
    args=parser.parse_args()
    import nbformat
    from nbclient import NotebookClient
    for key in DATASETS if args.dataset=='all' else [args.dataset]:
        root=ROOT/'datasets'/key
        if not (root/'study_cohort_contract.json').exists():
            raise FileNotFoundError('Prepare external data first: python prepare_inputs.py --dataset '+key+' --input PATH_TO_STUDY_CSV')
        path=root/DATASETS[key]
        notebook=nbformat.read(path,as_version=4)
        output=root/(path.stem+'-executed.ipynb')
        if output.exists():
            raise FileExistsError('Move or rename the previous executed notebook before starting a new run: '+str(output))
        run=copy.deepcopy(notebook)
        client=NotebookClient(run,timeout=args.timeout,kernel_name=args.kernel,allow_errors=False,
                              resources={'metadata':{'path':str(root)}})
        print('Executing',key,'(full model fits and bootstraps)',flush=True)
        try:
            client.execute()
        finally:
            nbformat.write(run,output)
        print('Completed:',output,flush=True)


if __name__=='__main__':
    main()
