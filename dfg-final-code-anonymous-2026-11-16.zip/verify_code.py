"""Standard-library integrity, syntax and code-only contents checks."""
import ast
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parent

def main():
    manifest=json.loads((ROOT/'FILE_MANIFEST.json').read_text())
    notebooks=0
    modules=0
    for entry in manifest['files']:
        path=ROOT/entry['path']
        if hashlib.sha256(path.read_bytes()).hexdigest()!=entry['sha256']:
            raise ValueError('Checksum mismatch: '+entry['path'])
        if path.suffix in {'.csv','.xes','.graphml','.gz','.png','.pkl','.npz','.joblib'}:
            raise ValueError('A dataset or generated output is included: '+entry['path'])
        if path.suffix=='.py':
            ast.parse(path.read_text(encoding='utf-8'))
            modules+=1
        if path.suffix=='.ipynb':
            nb=json.loads(path.read_text(encoding='utf-8'))
            for cell in nb['cells']:
                if cell['cell_type']=='code':
                    ast.parse(''.join(cell['source']))
                    assert not cell.get('outputs')
                    assert cell.get('execution_count') is None
            notebooks+=1
    assert notebooks==3
    print(f'PASS: {len(manifest["files"])} files verified, {notebooks} output-free notebooks, {modules} Python modules; no datasets or generated results.')

if __name__=='__main__':
    main()
